import express from 'express';
import session from 'express-session';
import multer from 'multer';
import sharp from 'sharp';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';
import pool from './db.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();

// Configuration multer pour le stockage des images
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, join(__dirname, '../public/uploads'))
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    cb(null, uniqueSuffix + '-' + file.originalname)
  }
});

const upload = multer({ storage });

app.use(express.json());
app.use(session({
  secret: 'your_session_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: process.env.NODE_ENV === 'production' }
}));

// Middleware d'authentification
const requireAuth = (req, res, next) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'Non autorisé' });
  }
  next();
};

// Routes d'authentification
app.post('/api/login', async (req, res) => {
  try {
    const [users] = await pool.query(
      'SELECT * FROM users WHERE email = ?',
      [req.body.email]
    );

    const user = users[0];
    if (!user || !await bcrypt.compare(req.body.password, user.password)) {
      return res.status(401).json({ error: 'Identifiants invalides' });
    }

    req.session.userId = user.id;
    req.session.userRole = user.role;
    res.json({ id: user.id, email: user.email, role: user.role });
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// API pour les enfants
app.get('/api/children', async (req, res) => {
  try {
    const [children] = await pool.query('SELECT * FROM children');
    res.json(children);
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Upload d'images
app.post('/api/upload', requireAuth, upload.single('image'), async (req, res) => {
  try {
    const { filename } = req.file;
    
    // Redimensionnement et optimisation de l'image
    await sharp(req.file.path)
      .resize(800, 600, { fit: 'inside' })
      .jpeg({ quality: 80 })
      .toFile(join(__dirname, '../public/uploads/optimized', filename));

    res.json({ url: `/uploads/optimized/${filename}` });
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de l\'upload' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Serveur démarré sur le port ${PORT}`);
});