CREATE DATABASE IF NOT EXISTS touspourcuba;
USE touspourcuba;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin', 'sponsor') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE children (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  age INT NOT NULL,
  gender ENUM('M', 'F') NOT NULL,
  city VARCHAR(255) NOT NULL,
  needs TEXT NOT NULL,
  story TEXT NOT NULL,
  image_url VARCHAR(255) NOT NULL,
  is_sponsored BOOLEAN DEFAULT FALSE,
  sponsor_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (sponsor_id) REFERENCES users(id)
);

CREATE TABLE photos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  child_id INT NOT NULL,
  url VARCHAR(255) NOT NULL,
  caption TEXT,
  sponsor_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (child_id) REFERENCES children(id),
  FOREIGN KEY (sponsor_id) REFERENCES users(id)
);

CREATE TABLE testimonials (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sponsor_id INT NOT NULL,
  child_id INT NOT NULL,
  content TEXT NOT NULL,
  duration VARCHAR(50) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (sponsor_id) REFERENCES users(id),
  FOREIGN KEY (child_id) REFERENCES children(id)
);