import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Mail, User, Phone, Heart } from 'lucide-react';
import { useChildrenContext } from '../contexts/ChildrenContext';

interface SponsorshipFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  message: string;
}

export default function SponsorshipForm() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { sponsorChild } = useChildrenContext();
  const { register, handleSubmit, formState: { errors } } = useForm<SponsorshipFormData>();

  const onSubmit = (data: SponsorshipFormData) => {
    if (id) {
      sponsorChild(id);
      // Envoyer les données du formulaire au backend
      console.log(data);
      // Redirection vers une page de confirmation
      navigate('/confirmation');
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <Heart className="mx-auto h-12 w-12 text-rose-500" />
        <h1 className="mt-4 text-3xl font-extrabold text-gray-900">
          Formulaire de parrainage
        </h1>
        <p className="mt-2 text-gray-600">
          Remplissez ce formulaire pour recevoir toutes les informations nécessaires au parrainage
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Le reste du formulaire reste inchangé */}
        {/* ... */}
      </form>
    </div>
  );
}