import React from 'react';
import { BarChart3, Users, Image, Settings } from 'lucide-react';
import { Link } from 'react-router-dom';
import Stats from '../../components/Stats';

const stats = {
  availableChildren: 12,
  sponsoredChildren: 24,
  pageViews: 1543
};

export default function Dashboard() {
  return (
    <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
      <div className="md:flex md:items-center md:justify-between">
        <div className="flex-1 min-w-0">
          <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
            Tableau de bord
          </h2>
        </div>
      </div>

      <div className="mt-8">
        <Stats stats={stats} />
      </div>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Link
          to="/admin/enfants"
          className="relative group bg-white p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-rose-500 rounded-lg shadow-md hover:shadow-lg transition-shadow"
        >
          <div>
            <span className="rounded-lg inline-flex p-3 bg-rose-50 text-rose-700 ring-4 ring-white">
              <Users className="h-6 w-6" />
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-lg font-medium">
              <span className="absolute inset-0" aria-hidden="true" />
              Gestion des enfants
            </h3>
            <p className="mt-2 text-sm text-gray-500">
              Ajouter, modifier ou supprimer les profils des enfants
            </p>
          </div>
        </Link>

        <Link
          to="/admin/images"
          className="relative group bg-white p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-rose-500 rounded-lg shadow-md hover:shadow-lg transition-shadow"
        >
          <div>
            <span className="rounded-lg inline-flex p-3 bg-rose-50 text-rose-700 ring-4 ring-white">
              <Image className="h-6 w-6" />
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-lg font-medium">
              <span className="absolute inset-0" aria-hidden="true" />
              Gestion des images
            </h3>
            <p className="mt-2 text-sm text-gray-500">
              Gérer les photos des enfants et les médias du site
            </p>
          </div>
        </Link>
      </div>
    </div>
  );
}