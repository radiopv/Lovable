import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Settings as SettingsIcon, Save, User, MessageSquare, AlertCircle } from 'lucide-react';
import { useChildrenContext } from '../../contexts/ChildrenContext';

interface SponsorshipUpdate {
  childId: string;
  sponsorName: string;
  sponsorEmail: string;
  startDate: string;
  notes: string;
  isSponsored: boolean;
}

interface TestimonialForm {
  childId: string;
  content: string;
  sponsorName: string;
  date: string;
}

export default function Settings() {
  const [activeTab, setActiveTab] = useState('sponsorships');
  const [successMessage, setSuccessMessage] = useState('');
  const { children, updateChild, addTestimonial } = useChildrenContext();
  
  const { 
    register: registerSponsorship, 
    handleSubmit: handleSponsorshipSubmit,
    reset: resetSponsorship,
    watch: watchSponsorship
  } = useForm<SponsorshipUpdate>();

  const { 
    register: registerTestimonial, 
    handleSubmit: handleTestimonialSubmit,
    reset: resetTestimonial
  } = useForm<TestimonialForm>();

  const selectedChildId = watchSponsorship('childId');
  const selectedChild = children.find(child => child.id === selectedChildId);

  const onSponsorshipUpdate = async (data: SponsorshipUpdate) => {
    try {
      await updateChild(data.childId, {
        isSponsored: data.isSponsored,
        sponsorName: data.sponsorName,
        sponsorEmail: data.sponsorEmail,
        sponsorshipStartDate: data.startDate,
        notes: data.notes
      });
      setSuccessMessage('Parrainage mis à jour avec succès');
      resetSponsorship();
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (error) {
      console.error('Erreur lors de la mise à jour:', error);
    }
  };

  const onTestimonialAdd = async (data: TestimonialForm) => {
    try {
      await addTestimonial(data.childId, {
        content: data.content,
        sponsorName: data.sponsorName,
        date: data.date
      });
      setSuccessMessage('Témoignage ajouté avec succès');
      resetTestimonial();
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (error) {
      console.error('Erreur lors de l\'ajout du témoignage:', error);
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div className="flex-1 min-w-0">
          <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate flex items-center">
            <SettingsIcon className="h-8 w-8 mr-2 text-gray-500" />
            Paramètres
          </h2>
        </div>
      </div>

      {successMessage && (
        <div className="mb-4 p-4 rounded-md bg-green-50 text-green-700 flex items-center">
          <AlertCircle className="h-5 w-5 mr-2" />
          {successMessage}
        </div>
      )}

      <div className="bg-white shadow rounded-lg">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex">
            <button
              onClick={() => setActiveTab('sponsorships')}
              className={`${
                activeTab === 'sponsorships'
                  ? 'border-rose-500 text-rose-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } w-1/2 py-4 px-1 text-center border-b-2 font-medium text-sm`}
            >
              Gestion des Parrainages
            </button>
            <button
              onClick={() => setActiveTab('testimonials')}
              className={`${
                activeTab === 'testimonials'
                  ? 'border-rose-500 text-rose-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } w-1/2 py-4 px-1 text-center border-b-2 font-medium text-sm`}
            >
              Témoignages
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'sponsorships' ? (
            <form onSubmit={handleSponsorshipSubmit(onSponsorshipUpdate)} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Enfant
                </label>
                <select
                  {...registerSponsorship('childId', { required: 'Veuillez sélectionner un enfant' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
                >
                  <option value="">Sélectionner un enfant</option>
                  {children.map(child => (
                    <option key={child.id} value={child.id}>
                      {child.name} ({child.isSponsored ? 'Parrainé' : 'Non parrainé'})
                    </option>
                  ))}
                </select>
              </div>

              {selectedChild && (
                <>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      {...registerSponsorship('isSponsored')}
                      id="isSponsored"
                      className="h-4 w-4 text-rose-600 focus:ring-rose-500 border-gray-300 rounded"
                    />
                    <label htmlFor="isSponsored" className="text-sm font-medium text-gray-700">
                      Enfant parrainé
                    </label>
                  </div>

                  <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Nom du parrain/marraine
                      </label>
                      <input
                        type="text"
                        {...registerSponsorship('sponsorName')}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Email du parrain/marraine
                      </label>
                      <input
                        type="email"
                        {...registerSponsorship('sponsorEmail')}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Date de début du parrainage
                    </label>
                    <input
                      type="date"
                      {...registerSponsorship('startDate')}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Notes supplémentaires
                    </label>
                    <textarea
                      {...registerSponsorship('notes')}
                      rows={4}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
                    />
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-rose-500 hover:bg-rose-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-rose-500"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Enregistrer les modifications
                    </button>
                  </div>
                </>
              )}
            </form>
          ) : (
            <form onSubmit={handleTestimonialSubmit(onTestimonialAdd)} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Enfant concerné
                </label>
                <select
                  {...registerTestimonial('childId', { required: 'Veuillez sélectionner un enfant' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
                >
                  <option value="">Sélectionner un enfant</option>
                  {children.filter(child => child.isSponsored).map(child => (
                    <option key={child.id} value={child.id}>{child.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Nom du parrain/marraine
                </label>
                <input
                  type="text"
                  {...registerTestimonial('sponsorName', { required: 'Le nom est requis' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Témoignage
                </label>
                <textarea
                  {...registerTestimonial('content', { required: 'Le témoignage est requis' })}
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Date
                </label>
                <input
                  type="date"
                  {...registerTestimonial('date', { required: 'La date est requise' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
                />
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-rose-500 hover:bg-rose-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-rose-500"
                >
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Ajouter le témoignage
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}