import React, { useState } from 'react';
import { Upload, X } from 'lucide-react';

interface Image {
  id: string;
  url: string;
  name: string;
  size: string;
  uploadedAt: string;
}

const initialImages: Image[] = [
  {
    id: '1',
    url: 'https://images.unsplash.com/photo-1544727219-d62b56b3c8bf',
    name: 'marie-portrait.jpg',
    size: '1.2 MB',
    uploadedAt: '2024-03-15'
  }
];

export default function ImageManager() {
  const [images, setImages] = useState(initialImages);
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      // Ici, vous implémenteriez la logique d'upload
      console.log("File dropped:", e.dataTransfer.files[0]);
    }
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer cette image ?')) {
      setImages(images.filter(image => image.id !== id));
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
      <div className="md:flex md:items-center md:justify-between">
        <div className="flex-1 min-w-0">
          <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
            Gestion des images
          </h2>
        </div>
      </div>

      <div
        className={`mt-8 border-2 border-dashed rounded-lg p-8 text-center ${
          dragActive ? 'border-rose-500 bg-rose-50' : 'border-gray-300'
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <div className="space-y-4">
          <Upload className="mx-auto h-12 w-12 text-gray-400" />
          <div className="flex text-sm text-gray-600">
            <label
              htmlFor="file-upload"
              className="relative cursor-pointer rounded-md font-medium text-rose-600 hover:text-rose-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-rose-500"
            >
              <span>Télécharger un fichier</span>
              <input
                id="file-upload"
                name="file-upload"
                type="file"
                className="sr-only"
                accept="image/*"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    // Ici, vous implémenteriez la logique d'upload
                    console.log("File selected:", e.target.files[0]);
                  }
                }}
              />
            </label>
            <p className="pl-1">ou glisser-déposer</p>
          </div>
          <p className="text-xs text-gray-500">PNG, JPG jusqu'à 10MB</p>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {images.map((image) => (
          <div key={image.id} className="relative group">
            <div className="aspect-w-1 aspect-h-1 rounded-lg overflow-hidden bg-gray-100">
              <img
                src={image.url}
                alt={image.name}
                className="object-cover"
              />
              <button
                onClick={() => handleDelete(image.id)}
                className="absolute top-2 right-2 p-1 bg-white rounded-full shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X className="h-4 w-4 text-gray-500" />
              </button>
            </div>
            <div className="mt-2">
              <p className="text-sm font-medium text-gray-900">{image.name}</p>
              <p className="text-sm text-gray-500">{image.size}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}