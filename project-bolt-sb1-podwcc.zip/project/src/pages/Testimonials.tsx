import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Camera, Send } from 'lucide-react';
import type { Testimonial } from '../types';

const testimonials: Testimonial[] = [
  {
    id: '1',
    sponsorName: 'Marie D.',
    childName: 'Sofia',
    content: "Parrainer Sofia a été l'une des meilleures décisions de ma vie. Voir son évolution et sa passion pour l'art grandir est une joie immense.",
    date: '2024-03-15',
    duration: '2 ans',
    photos: ['https://images.unsplash.com/photo-1516942126524-95d455c396bf']
  }
];

interface TestimonialFormData {
  sponsorName: string;
  childName: string;
  content: string;
  duration: string;
  photos: FileList;
}

export default function Testimonials() {
  const [showForm, setShowForm] = useState(false);
  const { register, handleSubmit, formState: { errors } } = useForm<TestimonialFormData>();

  const onSubmit = (data: TestimonialFormData) => {
    // Ici, vous implémenteriez la logique d'envoi au backend
    console.log(data);
    setShowForm(false);
  };

  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
          Témoignages
        </h1>
        <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
          Découvrez les histoires inspirantes de nos parrains et marraines
        </p>
        <button
          onClick={() => setShowForm(true)}
          className="mt-6 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-rose-500 hover:bg-rose-600"
        >
          Partager mon témoignage
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full p-6">
            <h2 className="text-2xl font-bold mb-6">Partagez votre expérience</h2>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Votre nom</label>
                <input
                  type="text"
                  {...register('sponsorName', { required: 'Le nom est requis' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Nom de l'enfant</label>
                <input
                  type="text"
                  {...register('childName', { required: 'Le nom de l\'enfant est requis' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Votre témoignage</label>
                <textarea
                  {...register('content', { required: 'Le témoignage est requis' })}
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Durée du parrainage</label>
                <input
                  type="text"
                  {...register('duration', { required: 'La durée est requise' })}
                  placeholder="ex: 2 ans"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Photos</label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                  <div className="space-y-1 text-center">
                    <Camera className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600">
                      <label className="relative cursor-pointer rounded-md font-medium text-rose-600 hover:text-rose-500">
                        <span>Télécharger des photos</span>
                        <input
                          type="file"
                          multiple
                          accept="image/*"
                          {...register('photos')}
                          className="sr-only"
                        />
                      </label>
                    </div>
                    <p className="text-xs text-gray-500">PNG, JPG jusqu'à 10MB</p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-rose-500 hover:bg-rose-600"
                >
                  <Send className="h-4 w-4 mr-2 inline-block" />
                  Envoyer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="grid gap-8 md:grid-cols-2">
        {testimonials.map((testimonial) => (
          <div key={testimonial.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            {testimonial.photos.length > 0 && (
              <div className="relative h-48">
                <img
                  src={testimonial.photos[0]}
                  alt={`Photo de ${testimonial.childName}`}
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            <div className="p-6">
              <p className="text-gray-600 italic mb-4">{testimonial.content}</p>
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium text-gray-900">{testimonial.sponsorName}</p>
                  <p className="text-sm text-gray-500">
                    Parrain/Marraine de {testimonial.childName} depuis {testimonial.duration}
                  </p>
                </div>
                <p className="text-sm text-gray-500">
                  {new Date(testimonial.date).toLocaleDateString()}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* AdSense */}
      <div className="mt-12 bg-gray-50 p-4 rounded-lg">
        <div className="h-[250px] flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
          <p className="text-gray-500">Espace publicitaire AdSense</p>
        </div>
      </div>
    </div>
  );
}