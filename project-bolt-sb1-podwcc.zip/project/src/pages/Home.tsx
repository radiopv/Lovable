import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Users, ArrowRight } from 'lucide-react';

export default function Home() {
  return (
    <div className="bg-white">
      <div className="relative">
        <div className="absolute inset-0">
          <img
            className="w-full h-full object-cover"
            src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2340&q=80"
            alt="Enfants heureux"
          />
          <div className="absolute inset-0 bg-gray-500 mix-blend-multiply" />
        </div>
        <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
            Changez une vie, parrainez un enfant
          </h1>
          <p className="mt-6 text-xl text-gray-100 max-w-3xl">
            Donnez l'opportunité à un enfant d'avoir un avenir meilleur. Votre parrainage peut faire
            toute la différence dans sa vie.
          </p>
          <div className="mt-10">
            <Link
              to="/enfants"
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-rose-500 hover:bg-rose-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-rose-500"
            >
              Découvrir les enfants à parrainer
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:py-24 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">Comment ça marche ?</h2>
          <p className="mt-4 text-lg text-gray-500">
            Le parrainage est un engagement qui change des vies. Voici comment vous pouvez aider.
          </p>
        </div>
        <dl className="mt-12 space-y-10 sm:space-y-0 sm:grid sm:grid-cols-3 sm:gap-8">
          <div className="flex flex-col items-center">
            <div className="flex items-center justify-center h-12 w-12 rounded-md bg-rose-500 text-white">
              <Users className="h-6 w-6" />
            </div>
            <dt className="mt-5 text-lg leading-6 font-medium text-gray-900">1. Choisissez un enfant</dt>
            <dd className="mt-2 text-base text-gray-500 text-center">
              Parcourez les profils des enfants en attente de parrainage et choisissez celui que vous
              souhaitez aider.
            </dd>
          </div>

          <div className="flex flex-col items-center">
            <div className="flex items-center justify-center h-12 w-12 rounded-md bg-rose-500 text-white">
              <Heart className="h-6 w-6" />
            </div>
            <dt className="mt-5 text-lg leading-6 font-medium text-gray-900">2. Engagez-vous</dt>
            <dd className="mt-2 text-base text-gray-500 text-center">
              Remplissez le formulaire de parrainage et recevez toutes les informations nécessaires
              pour commencer votre engagement.
            </dd>
          </div>

          <div className="flex flex-col items-center">
            <div className="flex items-center justify-center h-12 w-12 rounded-md bg-rose-500 text-white">
              <ArrowRight className="h-6 w-6" />
            </div>
            <dt className="mt-5 text-lg leading-6 font-medium text-gray-900">3. Suivez son évolution</dt>
            <dd className="mt-2 text-base text-gray-500 text-center">
              Recevez régulièrement des nouvelles de votre filleul et suivez son développement grâce à
              nos mises à jour.
            </dd>
          </div>
        </dl>
      </div>

      {/* Section AdSense */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="bg-gray-50 p-4 rounded-lg">
          {/* Emplacement pour la publicité AdSense */}
          <div className="h-[250px] flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
            <p className="text-gray-500">Espace publicitaire AdSense</p>
          </div>
        </div>
      </div>
    </div>
  );
}