import React from 'react';
import Stats from '../components/Stats';

const stats = {
  availableChildren: 12,
  sponsoredChildren: 24,
  pageViews: 1543
};

export default function Statistics() {
  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
          Statistiques du Programme
        </h1>
        <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
          Découvrez l'impact de notre programme de parrainage
        </p>
      </div>

      <Stats stats={stats} />

      <div className="mt-16">
        <h2 className="text-2xl font-bold text-gray-900 mb-8">Impact du Programme</h2>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Éducation</h3>
            <p className="text-gray-600">
              90% des enfants parrainés ont pu poursuivre leurs études et améliorer leurs résultats scolaires.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Santé</h3>
            <p className="text-gray-600">
              Tous les enfants parrainés bénéficient d'un suivi médical régulier et d'une alimentation équilibrée.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Développement Personnel</h3>
            <p className="text-gray-600">
              Les activités extra-scolaires permettent aux enfants de développer leurs talents et leur confiance en eux.
            </p>
          </div>
        </div>
      </div>

      {/* AdSense */}
      <div className="mt-12 bg-gray-50 p-4 rounded-lg">
        <div className="h-[250px] flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
          <p className="text-gray-500">Espace publicitaire AdSense</p>
        </div>
      </div>
    </div>
  );
}