import React from 'react';
import ChildCard from '../components/ChildCard';
import { Child } from '../types';

// Données de démonstration
const children: Child[] = [
  {
    id: '1',
    name: 'Marie',
    age: 8,
    gender: 'F',
    city: 'Dakar',
    needs: 'Aide pour l\'éducation et les fournitures scolaires',
    imageUrl: 'https://images.unsplash.com/photo-1544727219-d62b56b3c8bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60',
    isSponsored: false,
    story: 'Marie rêve de devenir médecin pour aider sa communauté.'
  },
  {
    id: '2',
    name: 'Thomas',
    age: 6,
    gender: 'M',
    city: 'Abidjan',
    needs: 'Soutien nutritionnel et matériel scolaire',
    imageUrl: 'https://images.unsplash.com/photo-1548869206-93b036288d7e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60',
    isSponsored: false,
    story: 'Thomas est passionné par le dessin et adore l\'école.'
  }
];

export default function ChildrenList() {
  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
          Enfants en attente de parrainage
        </h1>
        <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
          Chaque enfant mérite une chance de réaliser ses rêves. Votre parrainage peut faire la différence.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {children.map((child) => (
          <ChildCard key={child.id} child={child} />
        ))}
      </div>

      {/* AdSense */}
      <div className="mt-12 bg-gray-50 p-4 rounded-lg">
        <div className="h-[250px] flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
          <p className="text-gray-500">Espace publicitaire AdSense</p>
        </div>
      </div>
    </div>
  );
}