import React from 'react';
import ChildCard from '../components/ChildCard';
import { Child } from '../types';

// Données de démonstration pour les enfants parrainés
const sponsoredChildren: Child[] = [
  {
    id: '3',
    name: 'Lucas',
    age: 7,
    gender: 'M',
    city: 'Santiago',
    needs: 'A reçu une aide pour son éducation et ses activités sportives',
    imageUrl: 'https://images.unsplash.com/photo-1545558014-8692077e9b5c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60',
    isSponsored: true,
    story: 'Lucas adore le football et rêve de devenir professeur.'
  },
  {
    id: '4',
    name: 'Sofia',
    age: 9,
    gender: 'F',
    city: 'La Havane',
    needs: 'Reçoit un soutien pour ses études artistiques',
    imageUrl: 'https://images.unsplash.com/photo-1516942126524-95d455c396bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60',
    isSponsored: true,
    story: 'Sofia est passionnée par la peinture et excelle dans ses études.'
  }
];

export default function SponsoredChildren() {
  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
          Nos enfants parrainés
        </h1>
        <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
          Découvrez les enfants qui ont déjà trouvé un parrain ou une marraine et comment leur vie a changé.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {sponsoredChildren.map((child) => (
          <ChildCard key={child.id} child={child} />
        ))}
      </div>

      {/* Section de témoignages */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">
          Témoignages de parrains et marraines
        </h2>
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <p className="text-gray-600 italic">
              "Parrainer Sofia a été l'une des meilleures décisions de ma vie. Voir son évolution et
              sa passion pour l'art grandir est une joie immense."
            </p>
            <p className="mt-4 font-medium text-gray-900">Marie D.</p>
            <p className="text-sm text-gray-500">Marraine depuis 2 ans</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <p className="text-gray-600 italic">
              "Le sourire de Lucas quand il m'a montré ses progrès en football valait tout l'or du
              monde. Cette expérience est enrichissante pour nous deux."
            </p>
            <p className="mt-4 font-medium text-gray-900">Pierre M.</p>
            <p className="text-sm text-gray-500">Parrain depuis 1 an</p>
          </div>
        </div>
      </div>

      {/* AdSense */}
      <div className="mt-12 bg-gray-50 p-4 rounded-lg">
        <div className="h-[250px] flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
          <p className="text-gray-500">Espace publicitaire AdSense</p>
        </div>
      </div>
    </div>
  );
}