import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Heart, Mail, MapPin } from 'lucide-react';
import { Child, ChildPhoto } from '../types';
import PhotoGallery from '../components/PhotoGallery';

// Données de démonstration
const children: Record<string, Child> = {
  '1': {
    id: '1',
    name: 'Marie',
    age: 8,
    gender: 'F',
    city: 'Dakar',
    needs: 'Aide pour l\'éducation et les fournitures scolaires',
    imageUrl: 'https://images.unsplash.com/photo-1544727219-d62b56b3c8bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60',
    isSponsored: true,
    story: 'Marie rêve de devenir médecin pour aider sa communauté. Elle est très studieuse et obtient d\'excellents résultats à l\'école malgré les difficultés. Elle aime aussi beaucoup dessiner et jouer avec ses amis.',
    photos: [
      {
        id: '1',
        url: 'https://images.unsplash.com/photo-1516942126524-95d455c396bf',
        caption: 'Marie à son cours de dessin',
        date: '2024-02-15',
        sponsorName: 'Pierre M.'
      },
      {
        id: '2',
        url: 'https://images.unsplash.com/photo-1548869206-93b036288d7e',
        caption: 'Remise des prix scolaires',
        date: '2024-03-01',
        sponsorName: 'Pierre M.'
      }
    ]
  }
};

export default function ChildDetail() {
  const { id } = useParams<{ id: string }>();
  const child = id ? children[id] : null;

  const handleAddPhoto = (photo: Omit<ChildPhoto, 'id' | 'date'>) => {
    // Dans un vrai projet, cette fonction enverrait la photo au backend
    console.log('Nouvelle photo à ajouter:', photo);
  };

  if (!child) {
    return (
      <div className="max-w-7xl mx-auto py-12 px-4 text-center">
        <p className="text-xl text-gray-600">Enfant non trouvé</p>
        <Link to="/enfants" className="mt-4 text-rose-500 hover:text-rose-600">
          Retour à la liste
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <Link
        to="/enfants"
        className="inline-flex items-center text-rose-500 hover:text-rose-600 mb-8"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Retour à la liste
      </Link>

      <div className="bg-white shadow-xl rounded-lg overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2">
          <div className="relative h-96 lg:h-auto">
            <img
              src={child.imageUrl}
              alt={child.name}
              className="absolute inset-0 w-full h-full object-cover"
            />
          </div>
          <div className="p-8">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-bold text-gray-900">{child.name}</h1>
              <span className="px-4 py-2 rounded-full text-sm font-medium bg-rose-100 text-rose-800">
                {child.age} ans
              </span>
            </div>

            <div className="mt-4 flex items-center text-gray-600">
              <MapPin className="h-5 w-5 mr-2" />
              {child.city}
            </div>

            <div className="mt-6">
              <h2 className="text-xl font-semibold text-gray-900">Son histoire</h2>
              <p className="mt-2 text-gray-600">{child.story}</p>
            </div>

            <div className="mt-6">
              <h2 className="text-xl font-semibold text-gray-900">Ses besoins</h2>
              <p className="mt-2 text-gray-600">{child.needs}</p>
            </div>

            <div className="mt-8">
              {!child.isSponsored ? (
                <Link
                  to={`/parrainer/${child.id}`}
                  className="inline-flex items-center justify-center w-full px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-rose-500 hover:bg-rose-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-rose-500"
                >
                  <Heart className="h-5 w-5 mr-2" />
                  Je souhaite parrainer {child.name}
                </Link>
              ) : (
                <div className="text-center p-4 bg-green-50 rounded-md">
                  <p className="text-green-800">
                    {child.name} est déjà parrainé(e) ! Découvrez d'autres enfants qui attendent votre aide.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Galerie photos */}
      {child.photos && (
        <div className="mt-12 bg-white shadow-xl rounded-lg p-8">
          <PhotoGallery
            photos={child.photos}
            childName={child.name}
            onAddPhoto={handleAddPhoto}
            canAdd={child.isSponsored} // Seuls les parrains peuvent ajouter des photos
          />
        </div>
      )}

      {/* AdSense */}
      <div className="mt-12 bg-gray-50 p-4 rounded-lg">
        <div className="h-[250px] flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
          <p className="text-gray-500">Espace publicitaire AdSense</p>
        </div>
      </div>
    </div>
  );
}