const API_BASE_URL = '/api';

export async function login(email: string, password: string) {
  const response = await fetch(`${API_BASE_URL}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
    credentials: 'include'
  });

  if (!response.ok) {
    throw new Error('Erreur de connexion');
  }

  return response.json();
}

export async function uploadImage(file: File, path: string) {
  const formData = new FormData();
  formData.append('image', file);
  formData.append('path', path);

  const response = await fetch(`${API_BASE_URL}/upload`, {
    method: 'POST',
    body: formData,
    credentials: 'include'
  });

  if (!response.ok) {
    throw new Error('Erreur lors de l\'upload');
  }

  return response.json();
}