import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Supabase credentials are missing');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseKey);

// API Functions
export const api = {
  // Auth
  async signIn(email: string, password: string) {
    return supabase.auth.signInWithPassword({ email, password });
  },

  async signOut() {
    return supabase.auth.signOut();
  },

  // Children
  async getChildren() {
    return supabase
      .from('children')
      .select('*')
      .order('created_at', { ascending: false });
  },

  async getChild(id: string) {
    return supabase
      .from('children')
      .select(`
        *,
        photos (
          id,
          url,
          caption,
          created_at,
          profiles (name)
        )
      `)
      .eq('id', id)
      .single();
  },

  async createChild(data: Omit<Child, 'id' | 'created_at'>) {
    return supabase
      .from('children')
      .insert(data)
      .select()
      .single();
  },

  async updateChild(id: string, data: Partial<Child>) {
    return supabase
      .from('children')
      .update(data)
      .eq('id', id)
      .select()
      .single();
  },

  // Photos
  async uploadPhoto(file: File, path: string) {
    const fileExt = file.name.split('.').pop();
    const fileName = `${Math.random()}.${fileExt}`;
    const filePath = `${path}/${fileName}`;

    const { data, error } = await supabase.storage
      .from('photos')
      .upload(filePath, file);

    if (error) throw error;

    const { data: { publicUrl } } = supabase.storage
      .from('photos')
      .getPublicUrl(filePath);

    return publicUrl;
  },

  async addChildPhoto(childId: string, data: { url: string; caption: string }) {
    return supabase
      .from('photos')
      .insert({
        child_id: childId,
        ...data,
        profile_id: (await supabase.auth.getUser()).data.user?.id
      })
      .select()
      .single();
  },

  // Testimonials
  async getTestimonials() {
    return supabase
      .from('testimonials')
      .select(`
        *,
        profiles (name),
        children (name)
      `)
      .order('created_at', { ascending: false });
  },

  async addTestimonial(data: Omit<Testimonial, 'id' | 'created_at'>) {
    return supabase
      .from('testimonials')
      .insert(data)
      .select()
      .single();
  }
};

// Types
export type { Database };