export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      children: {
        Row: {
          id: string
          name: string
          age: number
          gender: 'M' | 'F'
          city: string
          needs: string
          story: string
          image_url: string
          is_sponsored: boolean
          sponsor_id: string | null
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['children']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['children']['Row']>
      }
      photos: {
        Row: {
          id: string
          child_id: string
          url: string
          caption: string
          profile_id: string
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['photos']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['photos']['Row']>
      }
      profiles: {
        Row: {
          id: string
          name: string
          email: string
          role: 'admin' | 'sponsor'
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['profiles']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['profiles']['Row']>
      }
      testimonials: {
        Row: {
          id: string
          profile_id: string
          child_id: string
          content: string
          duration: string
          photos: string[]
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['testimonials']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['testimonials']['Row']>
      }
    }
  }
}