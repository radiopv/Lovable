import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useAuthStore } from './stores/authStore';
import ProtectedRoute from './components/ProtectedRoute';
import LoginForm from './components/Auth/LoginForm';
import Header from './components/Header';
import Home from './pages/Home';
import ChildrenList from './pages/ChildrenList';
import ChildDetail from './pages/ChildDetail';
import SponsorshipForm from './pages/SponsorshipForm';
import SponsoredChildren from './pages/SponsoredChildren';
import Statistics from './pages/Statistics';
import Testimonials from './pages/Testimonials';
import AdminLayout from './components/Admin/AdminLayout';
import Dashboard from './pages/Admin/Dashboard';
import ChildrenManager from './pages/Admin/ChildrenManager';
import ImageManager from './pages/Admin/ImageManager';
import Settings from './pages/Admin/Settings';
import { ChildrenProvider } from './contexts/ChildrenContext';

function App() {
  const checkAuth = useAuthStore((state) => state.checkAuth);

  React.useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  return (
    <ChildrenProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<LoginForm />} />

          {/* Routes d'administration protégées */}
          <Route
            path="/admin"
            element={
              <ProtectedRoute requiredRole="admin">
                <AdminLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<Dashboard />} />
            <Route path="enfants" element={<ChildrenManager />} />
            <Route path="images" element={<ImageManager />} />
            <Route path="parametres" element={<Settings />} />
          </Route>

          {/* Routes publiques avec Header */}
          <Route element={<Header />}>
            <Route index element={<Home />} />
            <Route path="enfants" element={<ChildrenList />} />
            <Route path="parraines" element={<SponsoredChildren />} />
            <Route path="statistiques" element={<Statistics />} />
            <Route path="temoignages" element={<Testimonials />} />
            <Route path="enfant/:id" element={<ChildDetail />} />
            <Route
              path="parrainer/:id"
              element={
                <ProtectedRoute>
                  <SponsorshipForm />
                </ProtectedRoute>
              }
            />
          </Route>
        </Routes>
      </Router>
    </ChildrenProvider>
  );
}