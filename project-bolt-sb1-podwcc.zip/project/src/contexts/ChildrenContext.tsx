import React, { createContext, useContext, useState } from 'react';
import type { Child, Testimonial } from '../types';

interface ChildrenContextType {
  children: Child[];
  updateChild: (id: string, updates: Partial<Child>) => Promise<void>;
  sponsorChild: (id: string) => void;
  addTestimonial: (childId: string, testimonial: Omit<Testimonial, 'id' | 'photos'>) => Promise<void>;
}

const ChildrenContext = createContext<ChildrenContextType | undefined>(undefined);

export function ChildrenProvider({ children: childrenProp }: { children: React.ReactNode }) {
  const [children, setChildren] = useState<Child[]>([
    {
      id: '1',
      name: 'Marie',
      age: 8,
      gender: 'F',
      city: 'Dakar',
      needs: 'Aide pour l\'éducation et les fournitures scolaires',
      imageUrl: 'https://images.unsplash.com/photo-1544727219-d62b56b3c8bf',
      isSponsored: false,
      story: 'Marie rêve de devenir médecin pour aider sa communauté.',
      sponsorName: '',
      sponsorEmail: '',
      sponsorshipStartDate: '',
      notes: ''
    }
  ]);

  const updateChild = async (id: string, updates: Partial<Child>) => {
    setChildren(prevChildren =>
      prevChildren.map(child =>
        child.id === id ? { ...child, ...updates } : child
      )
    );
  };

  const sponsorChild = (id: string) => {
    setChildren(prevChildren =>
      prevChildren.map(child =>
        child.id === id ? { ...child, isSponsored: true } : child
      )
    );
  };

  const addTestimonial = async (childId: string, testimonial: Omit<Testimonial, 'id' | 'photos'>) => {
    // In a real application, this would make an API call
    console.log('Adding testimonial for child:', childId, testimonial);
  };

  const value = {
    children,
    updateChild,
    sponsorChild,
    addTestimonial
  };

  return (
    <ChildrenContext.Provider value={value}>
      {childrenProp}
    </ChildrenContext.Provider>
  );
}

export function useChildrenContext() {
  const context = useContext(ChildrenContext);
  if (context === undefined) {
    throw new Error('useChildrenContext must be used within a ChildrenProvider');
  }
  return context;
}