import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
  id: string;
  email: string;
  role: 'admin' | 'sponsor';
  sponsoredChildId?: string;
}

interface AuthState {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  checkAuth: () => Promise<void>;
}

// Simulated user data for development
const ADMIN_USER = {
  id: '1',
  email: 'admin@passionvadero.com',
  role: 'admin' as const,
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      loading: true,
      
      signIn: async (email: string, password: string) => {
        // For development, check against hardcoded credentials
        if (email === 'admin@passionvadero.com' && password === 'Lechef400..') {
          set({ user: ADMIN_USER });
          return;
        }
        throw new Error('Identifiants invalides');
      },

      signOut: async () => {
        set({ user: null });
      },

      checkAuth: async () => {
        try {
          set({ loading: false });
        } catch (error) {
          console.error('Erreur lors de la vérification de l\'authentification:', error);
          set({ loading: false });
        }
      },
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ user: state.user }),
    }
  )
);