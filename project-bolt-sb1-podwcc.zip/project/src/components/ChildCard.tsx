import React from 'react';
import { Heart } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Child } from '../types';

interface ChildCardProps {
  child: Child;
}

export default function ChildCard({ child }: ChildCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
      <div className="relative h-48">
        <img
          src={child.imageUrl}
          alt={`Photo de ${child.name}`}
          className="w-full h-full object-cover"
        />
        {child.isSponsored && (
          <div className="absolute top-2 right-2 bg-rose-500 text-white px-3 py-1 rounded-full text-sm">
            Parrainé
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900">{child.name}</h3>
        <div className="mt-2 text-sm text-gray-600">
          <p>{child.age} ans • {child.city}</p>
          <p className="mt-1 line-clamp-2">{child.needs}</p>
        </div>
        <Link
          to={`/enfant/${child.id}`}
          className="mt-4 inline-flex items-center justify-center w-full px-4 py-2 text-sm font-medium text-white bg-rose-500 rounded-md hover:bg-rose-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-rose-500"
        >
          <Heart className="w-4 h-4 mr-2" />
          {child.isSponsored ? 'Voir le profil' : 'Parrainer'}
        </Link>
      </div>
    </div>
  );
}