import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import type { Stats } from '../types';

interface StatsProps {
  stats: Stats;
}

export default function Stats({ stats }: StatsProps) {
  const data = [
    {
      name: 'Enfants disponibles',
      value: stats.availableChildren,
    },
    {
      name: 'Enfants parrainés',
      value: stats.sponsoredChildren,
    },
  ];

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Statistiques du Programme</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-rose-50 p-4 rounded-lg">
          <p className="text-rose-600 text-sm font-medium">Enfants disponibles</p>
          <p className="text-3xl font-bold text-rose-700">{stats.availableChildren}</p>
        </div>
        <div className="bg-green-50 p-4 rounded-lg">
          <p className="text-green-600 text-sm font-medium">Enfants parrainés</p>
          <p className="text-3xl font-bold text-green-700">{stats.sponsoredChildren}</p>
        </div>
        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-blue-600 text-sm font-medium">Vues totales</p>
          <p className="text-3xl font-bold text-blue-700">{stats.pageViews}</p>
        </div>
      </div>
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="value" fill="#f43f5e" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}