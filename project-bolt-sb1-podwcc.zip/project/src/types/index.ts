export interface Child {
  id: string;
  name: string;
  age: number;
  gender: 'M' | 'F';
  city: string;
  needs: string;
  imageUrl: string;
  isSponsored: boolean;
  story: string;
  sponsorName?: string;
  sponsorEmail?: string;
  sponsorshipStartDate?: string;
  notes?: string;
  photos?: ChildPhoto[];
}

export interface ChildPhoto {
  id: string;
  url: string;
  caption: string;
  date: string;
  sponsorName: string;
}

export interface Stats {
  availableChildren: number;
  sponsoredChildren: number;
  pageViews: number;
}

export interface Testimonial {
  id: string;
  sponsorName: string;
  childName: string;
  content: string;
  date: string;
  duration?: string;
  photos?: string[];
}