import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { Toaster } from 'sonner';
import App from './App';
import './index.css';
import './i18n';
import { initSupabase } from './lib/supabase';

const container = document.getElementById('root');
if (!container) throw new Error('Failed to find the root element');

const root = createRoot(container);

// Initialize Supabase before rendering
initSupabase().then(() => {
  root.render(
    <React.StrictMode>
      <BrowserRouter>
        <App />
        <Toaster position="top-center" />
      </BrowserRouter>
    </React.StrictMode>
  );
}).catch(error => {
  console.error('Failed to initialize application:', error);
  root.render(
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full text-center">
        <h1 className="text-2xl font-bold text-red-600 mb-4">
          Erreur de connexion
        </h1>
        <p className="text-gray-600 mb-6">
          Une erreur est survenue lors de la connexion à la base de données. 
          Veuillez réessayer plus tard.
        </p>
        <button
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
        >
          Réessayer
        </button>
      </div>
    </div>
  );
});