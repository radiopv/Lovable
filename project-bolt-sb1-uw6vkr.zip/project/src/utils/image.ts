/**
 * Charge une image et retourne une promesse qui se résout avec les dimensions de l'image
 */
export const loadImage = (src: string): Promise<HTMLImageElement> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Erreur lors du chargement de l\'image'));
    img.src = src;
  });
};

/**
 * Vérifie si un fichier est une image valide
 */
export const validateImage = async (file: File): Promise<boolean> => {
  if (!file.type.startsWith('image/')) {
    throw new Error('Le fichier doit être une image');
  }

  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => resolve(true);
      img.onerror = () => resolve(false);
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  });
};

/**
 * Redimensionne une image aux dimensions spécifiées
 */
export const resizeImage = async (
  file: File,
  maxWidth: number,
  maxHeight: number
): Promise<Blob> => {
  const img = await loadImage(URL.createObjectURL(file));
  
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('Impossible de créer le contexte canvas');
  }

  let width = img.width;
  let height = img.height;

  if (width > maxWidth) {
    height = (height * maxWidth) / width;
    width = maxWidth;
  }

  if (height > maxHeight) {
    width = (width * maxHeight) / height;
    height = maxHeight;
  }

  canvas.width = width;
  canvas.height = height;

  ctx.drawImage(img, 0, 0, width, height);

  return new Promise((resolve) => {
    canvas.toBlob((blob) => {
      if (blob) {
        resolve(blob);
      } else {
        throw new Error('Erreur lors du redimensionnement de l\'image');
      }
    }, file.type);
  });
};