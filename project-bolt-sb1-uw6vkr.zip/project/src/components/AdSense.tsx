import React, { useEffect, useRef } from 'react';

interface AdSenseProps {
  client: string;
  slot: string;
  format?: 'auto' | 'fluid' | 'rectangle' | 'vertical' | 'horizontal';
  responsive?: boolean;
  style?: React.CSSProperties;
  className?: string;
}

const AdSense: React.FC<AdSenseProps> = ({
  client,
  slot,
  format = 'auto',
  responsive = true,
  style = {},
  className = ''
}) => {
  const advertRef = useRef<HTMLModElement>(null);
  const isLoaded = useRef(false);

  useEffect(() => {
    // Lazy load ads when they become visible
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && !isLoaded.current) {
          loadAd();
          isLoaded.current = true;
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '50px'
    });

    if (advertRef.current) {
      observer.observe(advertRef.current);
    }

    return () => {
      observer.disconnect();
    };
  }, []);

  const loadAd = () => {
    try {
      const adsbygoogle = (window as any).adsbygoogle || [];
      adsbygoogle.push({});
    } catch (error) {
      console.error('AdSense error:', error);
    }
  };

  return (
    <div className={`adsbygoogle-container ${className}`}>
      <ins
        ref={advertRef}
        className="adsbygoogle"
        style={{
          display: 'block',
          textAlign: 'center',
          minHeight: '280px',
          ...style
        }}
        data-ad-client={client}
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive={responsive}
        data-ad-layout="in-article"
      />
    </div>
  );
};

export default AdSense;