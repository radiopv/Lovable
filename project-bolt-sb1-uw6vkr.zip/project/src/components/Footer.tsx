import React from 'react';
import { Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t py-8">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-center">
          <Heart className="w-5 h-5 text-red-500 mr-2" />
          <p className="text-gray-600">
            © {new Date().getFullYear()} Parrainage Cuba. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;