import React, { useState, useRef } from 'react';
import { X, Upload } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import type { Child } from '../types';
import Button from './Button';
import ErrorMessage from './ErrorMessage';

interface AddAdminMemoryModalProps {
  child: Child;
  onClose: () => void;
  onSuccess: () => void;
}

const AddAdminMemoryModal: React.FC<AddAdminMemoryModalProps> = ({
  child,
  onClose,
  onSuccess
}) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [description, setDescription] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error(t('errors.file_too_large', { size: '5MB' }));
      return;
    }

    if (!file.type.startsWith('image/')) {
      toast.error(t('errors.invalid_image_type'));
      return;
    }

    setImageFile(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!imageFile) {
      setError(t('errors.image_required'));
      return;
    }

    setLoading(true);

    try {
      const fileExt = imageFile.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `memories/${child.id}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('media')
        .upload(filePath, imageFile);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('media')
        .getPublicUrl(filePath);

      const { error: insertError } = await supabase
        .from('memories')
        .insert({
          child_id: child.id,
          sponsor_id: child.sponsor_id,
          image_url: publicUrl,
          description: description.trim() || null,
          is_public: true,
          created_at: new Date().toISOString()
        });

      if (insertError) {
        // If memory creation fails, delete the uploaded image
        await supabase.storage
          .from('media')
          .remove([filePath]);
        throw insertError;
      }

      toast.success(t('success.memory_added'));
      onSuccess();
    } catch (err) {
      console.error('Error:', err);
      setError(t('errors.unknown'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-lg w-full p-6 relative">
        <Button
          variant="secondary"
          size="sm"
          icon={X}
          onClick={onClose}
          className="absolute top-4 right-4"
        />

        <h2 className="text-2xl font-bold mb-6">
          {t('memories.add.title', { name: child.name })}
        </h2>

        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex justify-center">
            <div className="relative">
              <img
                src={imagePreview || 'https://via.placeholder.com/300x200?text=Select+an+image'}
                alt={t('memories.preview')}
                className="w-full h-48 object-cover rounded-lg"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-2 right-2 bg-white p-2 rounded-full shadow-md hover:bg-gray-100"
                disabled={loading}
              >
                <Upload className="w-5 h-5 text-gray-600" />
              </button>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImageChange}
                accept="image/*"
                className="hidden"
                disabled={loading}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('memories.description')}
            </label>
            <textarea
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={t('memories.description_placeholder')}
              disabled={loading}
            />
          </div>

          <div className="flex justify-end space-x-4">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
              disabled={loading}
            >
              {t('common.buttons.cancel')}
            </Button>
            <Button
              type="submit"
              variant="primary"
              loading={loading}
              disabled={!imageFile}
            >
              {t('common.buttons.save')}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddAdminMemoryModal;