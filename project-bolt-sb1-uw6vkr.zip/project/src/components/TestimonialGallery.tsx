import React, { useState } from 'react';
import { Search, Filter } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import TestimonialCard from './TestimonialCard';
import Button from './Button';

interface TestimonialGalleryProps {
  testimonials: any[];
  onFilter: (category: string) => void;
  onSearch: (term: string) => void;
}

const TestimonialGallery: React.FC<TestimonialGalleryProps> = ({
  testimonials,
  onFilter,
  onSearch
}) => {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value;
    setSearchTerm(term);
    onSearch(term);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative flex-1 w-full sm:max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder={t('testimonials.filters.search')}
            className="w-full pl-10 pr-4 py-2 border rounded-lg"
            value={searchTerm}
            onChange={handleSearch}
          />
        </div>
        <Button
          variant="secondary"
          icon={Filter}
          onClick={() => setShowFilters(!showFilters)}
        >
          {t('testimonials.filters.filter')}
        </Button>
      </div>

      {showFilters && (
        <div className="bg-white p-4 rounded-lg shadow-md">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
            {Object.entries(t('testimonials.categories', { returnObjects: true })).map(([key, label]) => (
              <button
                key={key}
                onClick={() => onFilter(key)}
                className="px-4 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                {label as string}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {testimonials.map((testimonial) => (
          <TestimonialCard
            key={testimonial.id}
            testimonial={testimonial}
            onLike={() => {}}
            onComment={() => {}}
          />
        ))}
      </div>

      {testimonials.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          {t('testimonials.noResults')}
        </div>
      )}
    </div>
  );
};

export default TestimonialGallery;