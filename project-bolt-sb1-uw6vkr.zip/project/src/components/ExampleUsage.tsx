import React, { useState } from 'react';
import RichTextEditor from './RichTextEditor';

const ExampleUsage: React.FC = () => {
  const [content, setContent] = useState('<p>Commencez à écrire ici...</p>');

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h2 className="text-2xl font-bold mb-4">Éditeur de texte riche</h2>
      
      <RichTextEditor
        content={content}
        onChange={setContent}
      />

      <div className="mt-8">
        <h3 className="text-lg font-semibold mb-2">Aperçu en lecture seule :</h3>
        <RichTextEditor
          content={content}
          onChange={() => {}}
          readOnly
        />
      </div>
    </div>
  );
};

export default ExampleUsage;