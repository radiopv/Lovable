import React from 'react';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  message?: string;
  fullScreen?: boolean;
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ 
  size = 'md',
  className = '',
  message = 'Chargement...',
  fullScreen = false
}) => {
  const sizeStyles = {
    sm: 'h-8 w-8 border-2',
    md: 'h-12 w-12 border-3',
    lg: 'h-16 w-16 border-4'
  };

  const containerStyles = fullScreen 
    ? 'fixed inset-0 bg-white bg-opacity-75 z-50' 
    : 'p-4';

  return (
    <div className={`flex flex-col items-center justify-center ${containerStyles} ${className}`}>
      <div 
        className={`animate-spin rounded-full border-gray-200 border-b-red-600 ${sizeStyles[size]}`}
        role="status"
        aria-label="Chargement"
      />
      {message && (
        <p className="mt-4 text-gray-600 text-center">{message}</p>
      )}
    </div>
  );
};

export default LoadingSpinner;