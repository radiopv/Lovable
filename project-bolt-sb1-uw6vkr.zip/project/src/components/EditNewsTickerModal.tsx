import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, Link as LinkIcon } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import Button from './Button';

interface NewsItem {
  text: string;
  url?: string;
}

interface EditNewsTickerModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

const EditNewsTickerModal: React.FC<EditNewsTickerModalProps> = ({
  onClose,
  onSuccess
}) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [newsItems, setNewsItems] = useState<NewsItem[]>([]);

  useEffect(() => {
    fetchCurrentNews();
  }, []);

  const fetchCurrentNews = async () => {
    try {
      const { data, error } = await supabase
        .from('home_content')
        .select('news_items')
        .eq('section', 'news_ticker')
        .single();

      if (error) throw error;
      if (data?.news_items) {
        setNewsItems(data.news_items);
      }
    } catch (error) {
      console.error('Error fetching news:', error);
      toast.error(t('errors.loading'));
    }
  };

  const handleAddItem = () => {
    setNewsItems([...newsItems, { text: '' }]);
  };

  const handleRemoveItem = (index: number) => {
    setNewsItems(newsItems.filter((_, i) => i !== index));
  };

  const handleUpdateItem = (index: number, field: keyof NewsItem, value: string) => {
    const updatedItems = [...newsItems];
    updatedItems[index] = { ...updatedItems[index], [field]: value };
    setNewsItems(updatedItems);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase
        .from('home_content')
        .update({ news_items: newsItems })
        .eq('section', 'news_ticker');

      if (error) throw error;

      toast.success('Actualités mises à jour avec succès');
      onSuccess();
    } catch (error) {
      console.error('Error:', error);
      toast.error(t('errors.unknown_error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full p-6 relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
          disabled={loading}
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-bold mb-6">Gérer les actualités défilantes</h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            {newsItems.map((item, index) => (
              <div key={index} className="flex gap-4 items-start">
                <div className="flex-1 space-y-2">
                  <input
                    type="text"
                    value={item.text}
                    onChange={(e) => handleUpdateItem(index, 'text', e.target.value)}
                    placeholder="Texte de l'actualité"
                    className="w-full px-3 py-2 border rounded-lg"
                    required
                  />
                  <div className="flex items-center gap-2">
                    <LinkIcon className="w-4 h-4 text-gray-400" />
                    <input
                      type="text"
                      value={item.url || ''}
                      onChange={(e) => handleUpdateItem(index, 'url', e.target.value)}
                      placeholder="URL (optionnel)"
                      className="flex-1 px-3 py-2 border rounded-lg"
                    />
                  </div>
                </div>
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  icon={Trash2}
                  onClick={() => handleRemoveItem(index)}
                  className="mt-2"
                />
              </div>
            ))}
          </div>

          <Button
            type="button"
            variant="secondary"
            icon={Plus}
            onClick={handleAddItem}
            fullWidth
          >
            Ajouter une actualité
          </Button>

          <div className="flex justify-end space-x-4">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
              disabled={loading}
            >
              Annuler
            </Button>
            <Button
              type="submit"
              variant="primary"
              disabled={loading}
            >
              {loading ? 'Enregistrement...' : 'Enregistrer'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditNewsTickerModal;