import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users,
  LogOut 
} from 'lucide-react';
import Button from './Button';

const AssistantNavigation: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  const menuItems = [
    { path: '/assistant', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/assistant/enfants', icon: Users, label: 'Enfants' }
  ];

  const handleLogout = () => {
    localStorage.removeItem('assistantAuthenticated');
    navigate('/assistant/login');
  };

  return (
    <nav className="bg-white shadow-lg p-4">
      <div className="flex flex-col space-y-2">
        {menuItems.map(({ path, icon: Icon, label }) => (
          <Button
            key={path}
            variant={isActive(path) ? "primary" : "secondary"}
            icon={Icon}
            onClick={() => navigate(path)}
            fullWidth
          >
            {label}
          </Button>
        ))}
        <hr className="my-2" />
        <Button
          variant="secondary"
          icon={LogOut}
          onClick={handleLogout}
          fullWidth
        >
          Déconnexion
        </Button>
      </div>
    </nav>
  );
};

export default AssistantNavigation;