import React from 'react';

const AdSenseCompliance: React.FC = () => {
  return (
    <div className="text-sm text-gray-600 space-y-2">
      <p>
        Ce site utilise Google AdSense, un service de publicité tiers.
      </p>
      <p>
        En utilisant ce site, vous acceptez l'utilisation de cookies pour la publicité personnalisée.
        Pour plus d'informations, consultez notre politique de confidentialité.
      </p>
    </div>
  );
};

export default AdSenseCompliance;