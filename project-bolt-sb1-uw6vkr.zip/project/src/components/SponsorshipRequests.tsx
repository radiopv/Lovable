import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import { sendSponsorshipEmail } from '../lib/email';
import Button from './Button';
import LoadingSpinner from './LoadingSpinner';
import ErrorMessage from './ErrorMessage';

interface SponsorshipRequest {
  id: string;
  child_id: string;
  sponsor_id: string;
  status: string;
  message: string;
  created_at: string;
  child: {
    name: string;
    age: number;
    city: string;
  };
  sponsor: {
    name: string;
    email: string;
    is_anonymous: boolean;
  };
}

interface SponsorshipRequestsProps {
  onUpdate: () => void;
}

const SponsorshipRequests: React.FC<SponsorshipRequestsProps> = ({ onUpdate }) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [requests, setRequests] = useState<SponsorshipRequest[]>([]);
  const [processingId, setProcessingId] = useState<string | null>(null);

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    try {
      const { data, error } = await supabase
        .from('sponsorship_requests')
        .select(`
          *,
          child:children(name, age, city),
          sponsor:sponsors(name, email, is_anonymous)
        `)
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRequests(data || []);
    } catch (err) {
      console.error('Error:', err);
      setError(t('errors.loading'));
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (request: SponsorshipRequest) => {
    setProcessingId(request.id);
    try {
      // Update request status
      const { error: requestError } = await supabase
        .from('sponsorship_requests')
        .update({
          status: 'approved',
          updated_at: new Date().toISOString()
        })
        .eq('id', request.id);

      if (requestError) throw requestError;

      // Update child's sponsor
      const { error: childError } = await supabase
        .from('children')
        .update({
          sponsor_id: request.sponsor_id,
          is_sponsored: true,
          updated_at: new Date().toISOString()
        })
        .eq('id', request.child_id);

      if (childError) throw childError;

      // Update sponsor's children list
      const { data: sponsor, error: sponsorFetchError } = await supabase
        .from('sponsors')
        .select('children_sponsored')
        .eq('id', request.sponsor_id)
        .single();

      if (sponsorFetchError) throw sponsorFetchError;

      const children_sponsored = [...(sponsor.children_sponsored || []), request.child_id];

      const { error: sponsorUpdateError } = await supabase
        .from('sponsors')
        .update({
          children_sponsored,
          updated_at: new Date().toISOString()
        })
        .eq('id', request.sponsor_id);

      if (sponsorUpdateError) throw sponsorUpdateError;

      // Send confirmation email
      await sendSponsorshipEmail(
        request.sponsor.email,
        request.child.name,
        request.sponsor.name
      );

      toast.success(t('sponsor.requests.approve_success'));
      fetchRequests();
      onUpdate();
    } catch (err) {
      console.error('Error:', err);
      toast.error(t('sponsor.requests.approve_error'));
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (request: SponsorshipRequest) => {
    setProcessingId(request.id);
    try {
      const { error } = await supabase
        .from('sponsorship_requests')
        .update({
          status: 'rejected',
          updated_at: new Date().toISOString()
        })
        .eq('id', request.id);

      if (error) throw error;

      toast.success(t('sponsor.requests.reject_success'));
      fetchRequests();
    } catch (err) {
      console.error('Error:', err);
      toast.error(t('sponsor.requests.reject_error'));
    } finally {
      setProcessingId(null);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  if (requests.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        {t('sponsor.requests.no_pending')}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {requests.map((request) => (
        <div key={request.id} className="bg-white border rounded-lg p-4">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-semibold">
                {t('sponsor.requests.request_for', { name: request.child.name })}
              </h3>
              <p className="text-sm text-gray-600">
                {request.child.age} {t('children.details.age')} - {request.child.city}
              </p>
              <p className="text-sm text-gray-600">
                {t('sponsor.requests.by')}: {request.sponsor.is_anonymous ? t('sponsor.anonymous') : request.sponsor.name}
                <br />
                {t('sponsor.requests.email')}: {request.sponsor.email}
              </p>
              {request.message && (
                <div className="mt-2">
                  <p className="text-sm text-gray-700">{request.message}</p>
                </div>
              )}
              <p className="text-xs text-gray-500 mt-2">
                {t('sponsor.requests.received_on', { 
                  date: new Date(request.created_at).toLocaleDateString() 
                })}
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={() => handleApprove(request)}
                className="text-green-600"
                disabled={processingId === request.id}
                loading={processingId === request.id}
              >
                {t('sponsor.requests.approve')}
              </Button>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => handleReject(request)}
                className="text-red-600"
                disabled={processingId === request.id}
                loading={processingId === request.id}
              >
                {t('sponsor.requests.reject')}
              </Button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SponsorshipRequests;