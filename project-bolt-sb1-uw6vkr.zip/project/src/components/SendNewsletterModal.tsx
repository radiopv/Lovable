import React, { useState } from 'react';
import { X } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import ErrorMessage from './ErrorMessage';

interface SendNewsletterModalProps {
  onClose: () => void;
}

const SendNewsletterModal: React.FC<SendNewsletterModalProps> = ({ onClose }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [subject, setSubject] = useState('');
  const [content, setContent] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // Récupérer tous les emails de la mailing list
      const { data: subscribers, error: fetchError } = await supabase
        .from('mailing_list')
        .select('email');

      if (fetchError) throw fetchError;

      const emails = subscribers?.map(s => s.email) || [];

      if (emails.length === 0) {
        throw new Error('Aucun abonné dans la liste de diffusion');
      }

      // Enregistrer l'email dans les logs
      const { error: logError } = await supabase
        .from('email_logs')
        .insert([{
          subject,
          content,
          sent_to: emails
        }]);

      if (logError) throw logError;

      // Simuler l'envoi d'email (à remplacer par votre service d'emails)
      console.log('Newsletter envoyée à:', emails, {
        subject,
        content
      });

      toast.success('Newsletter envoyée avec succès !');
      onClose();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erreur lors de l\'envoi';
      setError(message);
      toast.error(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
          disabled={loading}
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-bold mb-4">
          Envoyer une newsletter
        </h2>

        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Sujet
            </label>
            <input
              type="text"
              required
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Contenu
            </label>
            <textarea
              required
              rows={10}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              disabled={loading}
            />
          </div>

          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border rounded-lg hover:bg-gray-50"
              disabled={loading}
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 flex items-center justify-center"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Envoi en cours...
                </>
              ) : (
                'Envoyer'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SendNewsletterModal;