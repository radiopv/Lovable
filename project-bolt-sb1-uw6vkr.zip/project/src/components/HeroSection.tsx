import React from 'react';
import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';
import Button from './Button';

const HeroSection: React.FC = () => {
  return (
    <section className="relative h-[600px] flex items-center">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1500759285222-a95626b934cb"
          alt="Enfants cubains jouant"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent" />
      </div>
      
      <div className="container mx-auto px-4 relative">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-2xl text-white"
        >
          <h1 className="text-5xl font-bold mb-6">
            Donnez le sourire à un enfant cubain
          </h1>
          <p className="text-xl mb-8 text-gray-100">
            Transformez la vie d'un enfant grâce à notre programme de parrainage
          </p>
          
          <div className="flex flex-wrap gap-4">
            <Button
              to="/enfants"
              variant="primary"
              size="lg"
              icon={Heart}
            >
              Parrainer un enfant
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;