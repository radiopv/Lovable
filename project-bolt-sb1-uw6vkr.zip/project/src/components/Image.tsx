import React from 'react';

interface ImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  priority?: boolean;
  objectFit?: 'contain' | 'cover' | 'fill' | 'none' | 'scale-down';
  objectPosition?: string;
}

const Image: React.FC<ImageProps> = ({
  priority,
  objectFit = 'cover',
  objectPosition = 'center',
  alt = '',
  className = '',
  ...props
}) => {
  return (
    <img
      {...props}
      alt={alt}
      loading={priority ? "eager" : "lazy"}
      className={`${className} ${objectFit ? `object-${objectFit}` : ''}`}
      style={{
        ...props.style,
        objectPosition
      }}
    />
  );
};

export default Image;