import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Heart, Menu, X, LogOut, Settings, Users, BookOpen } from 'lucide-react';
import { isAdminAuthenticated, isSponsorAuthenticated } from '../lib/auth';
import Button from './Button';

const Navbar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const isAdmin = isAdminAuthenticated();
  const isSponsor = isSponsorAuthenticated();

  const mainNavLinks = [
    { to: '/enfants', label: 'Enfants à parrainer', icon: Heart },
    { to: '/parraines', label: 'Enfants parrainés', icon: Users },
    { to: '/temoignages', label: 'Témoignages', icon: BookOpen }
  ];

  const handleLogout = () => {
    if (isAdmin) {
      localStorage.removeItem('adminAuthenticated');
      navigate('/admin/login');
    } else if (isSponsor) {
      localStorage.removeItem('sponsor');
      navigate('/parrain/connexion');
    }
  };

  return (
    <nav className="bg-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Heart className="w-8 h-8 text-red-500" />
            <span className="text-xl font-bold text-gray-800">
              Parrainage Cuba
            </span>
          </Link>
          
          <div className="hidden md:flex items-center space-x-4">
            {mainNavLinks.map((link) => (
              <Button
                key={link.to}
                to={link.to}
                variant={location.pathname === link.to ? "primary" : "secondary"}
                icon={link.icon}
              >
                {link.label}
              </Button>
            ))}

            {isSponsor ? (
              <>
                <Button 
                  to="/parrain/tableau-de-bord" 
                  variant="primary"
                  icon={Heart}
                >
                  Mon espace parrain
                </Button>
                <Button
                  variant="secondary"
                  icon={LogOut}
                  onClick={handleLogout}
                >
                  Déconnexion
                </Button>
              </>
            ) : isAdmin ? (
              <>
                <Button 
                  to="/admin" 
                  variant="primary"
                  icon={Settings}
                >
                  Administration
                </Button>
                <Button
                  variant="secondary"
                  icon={LogOut}
                  onClick={handleLogout}
                >
                  Déconnexion
                </Button>
              </>
            ) : (
              <>
                <Button 
                  to="/parrain/connexion" 
                  variant="primary"
                  icon={Heart}
                >
                  Espace parrain
                </Button>
                <Button 
                  to="/admin/login" 
                  variant="secondary"
                  icon={Settings}
                >
                  Administration
                </Button>
              </>
            )}
          </div>

          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-2">
            {mainNavLinks.map((link) => (
              <Button
                key={link.to}
                to={link.to}
                variant={location.pathname === link.to ? "primary" : "secondary"}
                icon={link.icon}
                fullWidth
              >
                {link.label}
              </Button>
            ))}

            {isSponsor ? (
              <>
                <Button 
                  to="/parrain/tableau-de-bord" 
                  variant="primary"
                  icon={Heart}
                  fullWidth
                >
                  Mon espace parrain
                </Button>
                <Button
                  variant="secondary"
                  icon={LogOut}
                  onClick={handleLogout}
                  fullWidth
                >
                  Déconnexion
                </Button>
              </>
            ) : isAdmin ? (
              <>
                <Button 
                  to="/admin" 
                  variant="primary"
                  icon={Settings}
                  fullWidth
                >
                  Administration
                </Button>
                <Button
                  variant="secondary"
                  icon={LogOut}
                  onClick={handleLogout}
                  fullWidth
                >
                  Déconnexion
                </Button>
              </>
            ) : (
              <>
                <Button 
                  to="/parrain/connexion" 
                  variant="primary"
                  icon={Heart}
                  fullWidth
                >
                  Espace parrain
                </Button>
                <Button 
                  to="/admin/login" 
                  variant="secondary"
                  icon={Settings}
                  fullWidth
                >
                  Administration
                </Button>
              </>
            )}
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;