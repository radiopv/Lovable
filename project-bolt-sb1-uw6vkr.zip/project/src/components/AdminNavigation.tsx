import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Image, 
  BarChart, 
  Archive,
  LogOut,
  Globe 
} from 'lucide-react';
import Button from './Button';

const AdminNavigation: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  const menuItems = [
    { path: '/admin', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/admin/enfants', icon: Users, label: 'Enfants' },
    { path: '/admin/parrains', icon: Users, label: 'Parrains' },
    { path: '/admin/souvenirs', icon: Image, label: 'Souvenirs' },
    { path: '/admin/statistiques', icon: BarChart, label: 'Stats' },
    { path: '/admin/archives', icon: Archive, label: 'Archives' },
    { path: '/admin/traductions', icon: Globe, label: 'Traductions' }
  ];

  const handleLogout = () => {
    localStorage.removeItem('adminAuthenticated');
    localStorage.removeItem('adminEmail');
    navigate('/admin/login');
  };

  return (
    <div className="bg-white shadow-lg mb-6 py-2 px-4 flex items-center justify-between">
      <div className="flex items-center space-x-2">
        {menuItems.map(({ path, icon: Icon, label }) => (
          <Button
            key={path}
            variant={isActive(path) ? "primary" : "secondary"}
            icon={Icon}
            onClick={() => navigate(path)}
            size="sm"
          >
            {label}
          </Button>
        ))}
      </div>
      
      <Button
        variant="secondary"
        icon={LogOut}
        onClick={handleLogout}
        size="sm"
      >
        Déconnexion
      </Button>
    </div>
  );
};

export default AdminNavigation;