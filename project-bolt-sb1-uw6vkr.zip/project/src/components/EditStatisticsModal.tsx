import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import Button from './Button';
import ErrorMessage from './ErrorMessage';

interface Statistics {
  total_children: number;
  sponsored_children: number;
  active_sponsors: number;
  total_memories: number;
}

interface EditStatisticsModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

const EditStatisticsModal: React.FC<EditStatisticsModalProps> = ({
  onClose,
  onSuccess
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<Statistics>({
    total_children: 0,
    sponsored_children: 0,
    active_sponsors: 0,
    total_memories: 0
  });

  useEffect(() => {
    fetchStatistics();
  }, []);

  const fetchStatistics = async () => {
    try {
      const { data, error } = await supabase
        .from('statistics')
        .select('*')
        .single();

      if (error) throw error;
      if (data) {
        setStats(data);
      }
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des statistiques');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase
        .from('statistics')
        .upsert({
          ...stats,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      toast.success('Statistiques mises à jour avec succès');
      onSuccess();
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors de la mise à jour des statistiques');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-md w-full p-6 relative">
        <Button
          variant="secondary"
          size="sm"
          icon={X}
          onClick={onClose}
          className="absolute top-4 right-4"
        />

        <h2 className="text-2xl font-bold mb-6">
          Modifier les statistiques
        </h2>

        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Nombre total d'enfants
            </label>
            <input
              type="number"
              min="0"
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={stats.total_children}
              onChange={(e) => setStats(prev => ({ ...prev, total_children: parseInt(e.target.value) || 0 }))}
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Enfants parrainés
            </label>
            <input
              type="number"
              min="0"
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={stats.sponsored_children}
              onChange={(e) => setStats(prev => ({ ...prev, sponsored_children: parseInt(e.target.value) || 0 }))}
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Parrains actifs
            </label>
            <input
              type="number"
              min="0"
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={stats.active_sponsors}
              onChange={(e) => setStats(prev => ({ ...prev, active_sponsors: parseInt(e.target.value) || 0 }))}
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Souvenirs partagés
            </label>
            <input
              type="number"
              min="0"
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={stats.total_memories}
              onChange={(e) => setStats(prev => ({ ...prev, total_memories: parseInt(e.target.value) || 0 }))}
              disabled={loading}
            />
          </div>

          <div className="flex justify-end space-x-4">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
              disabled={loading}
            >
              Annuler
            </Button>
            <Button
              type="submit"
              variant="primary"
              loading={loading}
            >
              Enregistrer
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditStatisticsModal;