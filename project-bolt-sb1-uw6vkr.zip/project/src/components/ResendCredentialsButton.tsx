import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { toast } from 'sonner';
import { resendCredentials } from '../lib/email';

interface ResendCredentialsButtonProps {
  sponsorId: string;
  sponsorName: string;
}

const ResendCredentialsButton: React.FC<ResendCredentialsButtonProps> = ({
  sponsorId,
  sponsorName
}) => {
  const [loading, setLoading] = useState(false);

  const handleResend = async () => {
    if (!confirm(`Renvoyer les identifiants à ${sponsorName} ?`)) return;
    
    setLoading(true);
    try {
      await resendCredentials(sponsorId);
      toast.success('Identifiants renvoyés avec succès');
    } catch (error) {
      console.error('Erreur:', error);
      toast.error('Erreur lors du renvoi des identifiants');
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      onClick={handleResend}
      disabled={loading}
      className="inline-flex items-center px-3 py-1 text-sm bg-red-100 text-red-700 rounded-md hover:bg-red-200"
    >
      {loading ? (
        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-700"></div>
      ) : (
        <>
          <Send className="w-4 h-4 mr-1" />
          Renvoyer les identifiants
        </>
      )}
    </button>
  );
};

export default ResendCredentialsButton;