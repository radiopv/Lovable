import React, { useState, useRef } from 'react';
import { Upload, X } from 'lucide-react';
import { toast } from 'sonner';
import { supabase, ensureBucket } from '../lib/supabase';
import Button from './Button';

interface PhotoUploadProps {
  onUpload: (url: string) => void;
  maxSize?: number;
  aspectRatio?: number;
  folder?: string;
  className?: string;
}

const PhotoUpload: React.FC<PhotoUploadProps> = ({
  onUpload,
  maxSize = 5,
  aspectRatio,
  folder = 'media',
  className = ''
}) => {
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file size (in MB)
    if (file.size > maxSize * 1024 * 1024) {
      toast.error(`File must not exceed ${maxSize}MB`);
      return;
    }

    // Check file type
    if (!file.type.startsWith('image/')) {
      toast.error('Only images are accepted');
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(file);

    // Check aspect ratio if specified
    if (aspectRatio) {
      const img = new Image();
      img.onload = () => {
        const imageRatio = img.width / img.height;
        if (Math.abs(imageRatio - aspectRatio) > 0.1) {
          toast.error('Image aspect ratio is incorrect');
          setPreview(null);
          if (fileInputRef.current) {
            fileInputRef.current.value = '';
          }
          return;
        }
      };
      img.src = URL.createObjectURL(file);
    }

    try {
      setUploading(true);

      // Ensure bucket exists before upload
      const bucketExists = await ensureBucket(folder);
      if (!bucketExists) {
        throw new Error('Storage not available');
      }

      // Generate unique filename
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `${folder}/${fileName}`;

      // Upload file
      const { error: uploadError } = await supabase.storage
        .from(folder)
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from(folder)
        .getPublicUrl(filePath);

      onUpload(publicUrl);
      toast.success('Image uploaded successfully');
    } catch (error) {
      console.error('Error uploading file:', error);
      toast.error('Error uploading file. Please try again.');
      // Reset preview and input
      setPreview(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className={`relative ${className}`}>
      {preview ? (
        <div className="relative">
          <img
            src={preview}
            alt="Preview"
            className="w-full h-48 object-cover rounded-lg"
          />
          <Button
            variant="secondary"
            size="sm"
            icon={X}
            onClick={() => {
              setPreview(null);
              if (fileInputRef.current) {
                fileInputRef.current.value = '';
              }
            }}
            className="absolute top-2 right-2"
          >
            Remove
          </Button>
        </div>
      ) : (
        <div
          className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-red-500 transition-colors"
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">
            Click or drop an image here
            <br />
            <span className="text-sm text-gray-500">
              {aspectRatio 
                ? `${aspectRatio}:1 ratio recommended, `
                : ''}
              Maximum {maxSize}MB
            </span>
          </p>
        </div>
      )}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelect}
        accept="image/*"
        className="hidden"
        disabled={uploading}
      />
      {uploading && (
        <div className="absolute inset-0 bg-white bg-opacity-75 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600"></div>
        </div>
      )}
    </div>
  );
};

export default PhotoUpload;