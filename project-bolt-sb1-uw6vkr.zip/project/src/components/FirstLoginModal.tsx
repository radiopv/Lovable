import React, { useState } from 'react';
import { X, Eye, EyeOff, Facebook } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import type { Sponsor } from '../types';

interface FirstLoginModalProps {
  sponsor: Sponsor;
  onClose: () => void;
  onSuccess: () => void;
}

const FirstLoginModal: React.FC<FirstLoginModalProps> = ({
  sponsor,
  onClose,
  onSuccess
}) => {
  const [loading, setLoading] = useState(false);
  const [isAnonymous, setIsAnonymous] = useState(true);
  const [facebookUrl, setFacebookUrl] = useState('');
  const [currentStep, setCurrentStep] = useState(1);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase
        .from('sponsors')
        .update({
          is_anonymous: isAnonymous,
          has_chosen_visibility: true,
          facebook_url: facebookUrl || null
        })
        .eq('id', sponsor.id);

      if (error) throw error;

      // Mettre à jour les données du sponsor dans le localStorage
      const updatedSponsor = {
        ...sponsor,
        is_anonymous: isAnonymous,
        has_chosen_visibility: true,
        facebook_url: facebookUrl || null
      };
      localStorage.setItem('sponsor', JSON.stringify(updatedSponsor));

      toast.success('Préférences mises à jour avec succès');
      onSuccess();
    } catch (error) {
      console.error('Erreur:', error);
      toast.error('Erreur lors de la mise à jour des préférences');
    } finally {
      setLoading(false);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Bienvenue sur la plateforme de parrainage !</h3>
            <p className="text-gray-600">
              Nous allons vous guider dans la configuration de votre compte en quelques étapes simples.
            </p>
            <Button
              onClick={() => setCurrentStep(2)}
              variant="primary"
              fullWidth
            >
              Commencer
            </Button>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Visibilité de votre profil</h3>
            <p className="text-gray-600">
              Choisissez comment vous souhaitez apparaître sur la plateforme. Votre choix pourra être modifié plus tard dans les paramètres.
            </p>
            <div className="space-y-4">
              <label className="flex items-center space-x-3 p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  checked={!isAnonymous}
                  onChange={() => setIsAnonymous(false)}
                  className="h-4 w-4 text-red-600"
                />
                <div className="flex items-center">
                  <Eye className="w-5 h-5 text-gray-400 mr-2" />
                  <div>
                    <p className="font-medium">Afficher mon nom</p>
                    <p className="text-sm text-gray-500">
                      Votre nom sera visible sur la page de l'enfant que vous parrainez
                    </p>
                  </div>
                </div>
              </label>

              <label className="flex items-center space-x-3 p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  checked={isAnonymous}
                  onChange={() => setIsAnonymous(true)}
                  className="h-4 w-4 text-red-600"
                />
                <div className="flex items-center">
                  <EyeOff className="w-5 h-5 text-gray-400 mr-2" />
                  <div>
                    <p className="font-medium">Rester anonyme</p>
                    <p className="text-sm text-gray-500">
                      Votre nom ne sera pas affiché publiquement
                    </p>
                  </div>
                </div>
              </label>
            </div>
            <Button
              onClick={() => setCurrentStep(3)}
              variant="primary"
              fullWidth
            >
              Continuer
            </Button>
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Profil Facebook</h3>
            <p className="text-gray-600">
              Ajoutez votre profil Facebook pour faciliter la communication avec les autres parrains.
              Cette information est optionnelle et peut être modifiée plus tard.
            </p>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                URL de votre profil Facebook
              </label>
              <div className="flex items-center space-x-2">
                <Facebook className="w-5 h-5 text-blue-600" />
                <input
                  type="url"
                  value={facebookUrl}
                  onChange={(e) => setFacebookUrl(e.target.value)}
                  placeholder="https://facebook.com/votre.profil"
                  className="flex-1 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                />
              </div>
            </div>
            <Button
              onClick={handleSubmit}
              variant="primary"
              fullWidth
              disabled={loading}
            >
              Terminer la configuration
            </Button>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-md w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
          disabled={loading}
        >
          <X className="w-6 h-6" />
        </button>

        {renderStep()}
      </div>
    </div>
  );
};

export default FirstLoginModal;