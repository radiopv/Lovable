import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { Memory } from '../types';
import Button from './Button';

interface MemoryCarouselProps {
  memories: Memory[];
  autoPlayInterval?: number;
}

const MemoryCarousel: React.FC<MemoryCarouselProps> = ({
  memories,
  autoPlayInterval = 5000
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  useEffect(() => {
    if (!isPlaying || memories.length <= 1) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % memories.length);
    }, autoPlayInterval);

    return () => clearInterval(interval);
  }, [isPlaying, memories.length, autoPlayInterval]);

  const handlePrevious = () => {
    setIsPlaying(false);
    setCurrentIndex((prev) => (prev - 1 + memories.length) % memories.length);
  };

  const handleNext = () => {
    setIsPlaying(false);
    setCurrentIndex((prev) => (prev + 1) % memories.length);
  };

  if (memories.length === 0) return null;

  return (
    <div className="relative w-full aspect-video bg-gray-900 rounded-lg overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="absolute inset-0"
        >
          {memories[currentIndex].media_type === 'image' ? (
            <img
              src={memories[currentIndex].media_url}
              alt={memories[currentIndex].description || 'Memory'}
              className="w-full h-full object-cover"
            />
          ) : (
            <video
              src={memories[currentIndex].media_url}
              className="w-full h-full object-cover"
              autoPlay
              muted
              loop
            />
          )}
          
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-4">
            {memories[currentIndex].description && (
              <p className="text-white text-sm md:text-base">
                {memories[currentIndex].description}
              </p>
            )}
          </div>
        </motion.div>
      </AnimatePresence>

      {memories.length > 1 && (
        <>
          <Button
            variant="secondary"
            size="sm"
            icon={ChevronLeft}
            onClick={handlePrevious}
            className="absolute left-4 top-1/2 transform -translate-y-1/2"
          />
          <Button
            variant="secondary"
            size="sm"
            icon={ChevronRight}
            onClick={handleNext}
            className="absolute right-4 top-1/2 transform -translate-y-1/2"
          />

          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
            {memories.map((_, index) => (
              <button
                key={index}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentIndex ? 'bg-white' : 'bg-white/50'
                }`}
                onClick={() => {
                  setIsPlaying(false);
                  setCurrentIndex(index);
                }}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default MemoryCarousel;