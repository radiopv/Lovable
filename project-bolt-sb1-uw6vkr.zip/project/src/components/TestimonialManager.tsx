import React, { useState, useEffect } from 'react';
import { Check, X, Trash2, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import Button from './Button';
import LoadingSpinner from './LoadingSpinner';
import ErrorMessage from './ErrorMessage';

interface Testimonial {
  id: string;
  sponsor_id: string;
  child_id: string;
  message: string;
  is_approved: boolean;
  is_published: boolean;
  is_hidden: boolean;
  created_at: string;
  sponsor: {
    name: string;
  };
  child: {
    name: string;
  };
}

const TestimonialManager: React.FC = () => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [actionInProgress, setActionInProgress] = useState<string | null>(null);

  useEffect(() => {
    fetchTestimonials();
  }, []);

  const fetchTestimonials = async () => {
    try {
      const { data, error } = await supabase
        .from('testimonials')
        .select(`
          *,
          sponsor:sponsors(name),
          child:children(name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTestimonials(data || []);
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des témoignages');
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (id: string, approve: boolean) => {
    try {
      setActionInProgress(id);
      const { error } = await supabase
        .from('testimonials')
        .update({
          is_approved: approve,
          is_published: approve,
          is_hidden: false
        })
        .eq('id', id);

      if (error) throw error;

      setTestimonials(prev => prev.map(testimonial => 
        testimonial.id === id 
          ? { ...testimonial, is_approved: approve, is_published: approve, is_hidden: false }
          : testimonial
      ));

      toast.success(approve ? 'Témoignage approuvé' : 'Témoignage rejeté');
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de la mise à jour du témoignage');
    } finally {
      setActionInProgress(null);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce témoignage ? Cette action est irréversible.')) {
      return;
    }

    try {
      setActionInProgress(id);
      const { error } = await supabase
        .from('testimonials')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setTestimonials(prev => prev.filter(testimonial => testimonial.id !== id));
      toast.success('Témoignage supprimé avec succès');
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de la suppression du témoignage');
    } finally {
      setActionInProgress(null);
    }
  };

  const handleHideToggle = async (id: string, hide: boolean) => {
    try {
      setActionInProgress(id);
      const { error } = await supabase
        .from('testimonials')
        .update({ is_hidden: hide })
        .eq('id', id);

      if (error) throw error;

      setTestimonials(prev => prev.map(testimonial => 
        testimonial.id === id 
          ? { ...testimonial, is_hidden: hide }
          : testimonial
      ));

      toast.success(hide ? 'Témoignage masqué' : 'Témoignage visible');
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de la mise à jour du témoignage');
    } finally {
      setActionInProgress(null);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  const pendingTestimonials = testimonials.filter(t => !t.is_approved && !t.is_published);
  const approvedTestimonials = testimonials.filter(t => t.is_approved && t.is_published);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-4">Témoignages en attente</h2>
        {pendingTestimonials.length === 0 ? (
          <p className="text-gray-500">Aucun témoignage en attente</p>
        ) : (
          <div className="space-y-4">
            {pendingTestimonials.map((testimonial) => (
              <div key={testimonial.id} className="bg-white p-4 rounded-lg shadow">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-semibold">{testimonial.sponsor.name}</p>
                    <p className="text-sm text-gray-500">
                      Pour {testimonial.child.name} - {new Date(testimonial.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      icon={Check}
                      onClick={() => handleApprove(testimonial.id, true)}
                      className="text-green-600"
                      disabled={actionInProgress === testimonial.id}
                    >
                      Approuver
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      icon={X}
                      onClick={() => handleApprove(testimonial.id, false)}
                      className="text-red-600"
                      disabled={actionInProgress === testimonial.id}
                    >
                      Rejeter
                    </Button>
                  </div>
                </div>
                <p className="text-gray-700">{testimonial.message}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4">Témoignages approuvés</h2>
        <div className="space-y-4">
          {approvedTestimonials.map((testimonial) => (
            <div key={testimonial.id} className={`bg-white p-4 rounded-lg shadow ${testimonial.is_hidden ? 'opacity-50' : ''}`}>
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="font-semibold">{testimonial.sponsor.name}</p>
                  <p className="text-sm text-gray-500">
                    Pour {testimonial.child.name} - {new Date(testimonial.created_at).toLocaleDateString()}
                  </p>
                  {testimonial.is_hidden && (
                    <p className="text-sm text-red-600 mt-1">
                      Ce témoignage est masqué de la page principale
                    </p>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    icon={testimonial.is_hidden ? Eye : EyeOff}
                    onClick={() => handleHideToggle(testimonial.id, !testimonial.is_hidden)}
                    className={testimonial.is_hidden ? "text-green-600" : "text-yellow-600"}
                    disabled={actionInProgress === testimonial.id}
                  >
                    {testimonial.is_hidden ? 'Rendre visible' : 'Masquer'}
                  </Button>
                  <Button
                    variant="secondary"
                    size="sm"
                    icon={Trash2}
                    onClick={() => handleDelete(testimonial.id)}
                    className="text-red-600"
                    disabled={actionInProgress === testimonial.id}
                  >
                    Supprimer
                  </Button>
                </div>
              </div>
              <p className="text-gray-700">{testimonial.message}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TestimonialManager;