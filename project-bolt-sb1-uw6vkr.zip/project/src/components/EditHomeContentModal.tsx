import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import Button from './Button';
import RichTextEditor from './RichTextEditor';
import ColorPicker from './ColorPicker';

interface EditHomeContentModalProps {
  section: string;
  onClose: () => void;
  onSuccess: () => void;
}

interface NewsItem {
  text: string;
  url?: string;
}

interface HomeContent {
  title: string;
  content: string;
  image_url: string;
  background_color: string;
  text_color: string;
  button_text: string;
  button_url: string;
  custom_html: string;
  is_html_enabled: boolean;
  news_items: NewsItem[];
}

const EditHomeContentModal: React.FC<EditHomeContentModalProps> = ({
  section,
  onClose,
  onSuccess
}) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [content, setContent] = useState<HomeContent>({
    title: '',
    content: '',
    image_url: '',
    background_color: '#ffffff',
    text_color: '#000000',
    button_text: '',
    button_url: '',
    custom_html: '',
    is_html_enabled: false,
    news_items: []
  });

  useEffect(() => {
    fetchContent();
  }, [section]);

  const fetchContent = async () => {
    try {
      const { data, error } = await supabase
        .from('home_content')
        .select('*')
        .eq('section', section)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      
      if (data) {
        setContent({
          title: data.title || '',
          content: data.content || '',
          image_url: data.image_url || '',
          background_color: data.background_color || '#ffffff',
          text_color: data.text_color || '#000000',
          button_text: data.button_text || '',
          button_url: data.button_url || '',
          custom_html: data.custom_html || '',
          is_html_enabled: data.is_html_enabled || false,
          news_items: Array.isArray(data.news_items) ? data.news_items : []
        });
      }
    } catch (err) {
      console.error('Error fetching content:', err);
      toast.error(t('admin.dashboard.content.errors.loading'));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase
        .from('home_content')
        .upsert({
          section,
          ...content,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      toast.success(t('admin.dashboard.content.success'));
      onSuccess();
    } catch (err) {
      console.error('Error saving content:', err);
      toast.error(t('admin.dashboard.content.errors.save'));
    } finally {
      setLoading(false);
    }
  };

  const handleNewsItemChange = (index: number, field: keyof NewsItem, value: string) => {
    const updatedItems = [...content.news_items];
    updatedItems[index] = { ...updatedItems[index], [field]: value };
    setContent(prev => ({ ...prev, news_items: updatedItems }));
  };

  const addNewsItem = () => {
    setContent(prev => ({
      ...prev,
      news_items: [...prev.news_items, { text: '' }]
    }));
  };

  const removeNewsItem = (index: number) => {
    setContent(prev => ({
      ...prev,
      news_items: prev.news_items.filter((_, i) => i !== index)
    }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full p-6 relative max-h-[90vh] overflow-y-auto">
        <Button
          variant="secondary"
          size="sm"
          icon={X}
          onClick={onClose}
          className="absolute top-4 right-4"
        />

        <h2 className="text-2xl font-bold mb-6">
          {t('admin.dashboard.content.edit')} - {section}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          {section === 'news_ticker' ? (
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-sm font-medium text-gray-700">
                  {t('admin.dashboard.content.news_items')}
                </label>
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  icon={Plus}
                  onClick={addNewsItem}
                  disabled={loading}
                >
                  {t('admin.dashboard.content.add_news')}
                </Button>
              </div>
              <div className="space-y-2">
                {content.news_items.map((item, index) => (
                  <div key={index} className="flex gap-2">
                    <input
                      type="text"
                      className="flex-1 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                      value={item.text}
                      onChange={(e) => handleNewsItemChange(index, 'text', e.target.value)}
                      placeholder={t('admin.dashboard.content.news_text')}
                      disabled={loading}
                    />
                    <input
                      type="text"
                      className="flex-1 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                      value={item.url || ''}
                      onChange={(e) => handleNewsItemChange(index, 'url', e.target.value)}
                      placeholder={t('admin.dashboard.content.news_url')}
                      disabled={loading}
                    />
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      icon={Trash2}
                      onClick={() => removeNewsItem(index)}
                      disabled={loading}
                    />
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('admin.dashboard.content.title')}
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                  value={content.title}
                  onChange={(e) => setContent(prev => ({ ...prev, title: e.target.value }))}
                  disabled={loading}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('admin.dashboard.content.image')}
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                  value={content.image_url}
                  onChange={(e) => setContent(prev => ({ ...prev, image_url: e.target.value }))}
                  disabled={loading}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('admin.dashboard.content.background_color')}
                  </label>
                  <ColorPicker
                    color={content.background_color}
                    onChange={(color) => setContent(prev => ({ ...prev, background_color: color }))}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('admin.dashboard.content.text_color')}
                  </label>
                  <ColorPicker
                    color={content.text_color}
                    onChange={(color) => setContent(prev => ({ ...prev, text_color: color }))}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('admin.dashboard.content.content')}
                </label>
                <RichTextEditor
                  value={content.content}
                  onChange={(value) => setContent(prev => ({ ...prev, content: value }))}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('admin.dashboard.content.button_text')}
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                    value={content.button_text}
                    onChange={(e) => setContent(prev => ({ ...prev, button_text: e.target.value }))}
                    disabled={loading}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('admin.dashboard.content.button_url')}
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                    value={content.button_url}
                    onChange={(e) => setContent(prev => ({ ...prev, button_url: e.target.value }))}
                    disabled={loading}
                  />
                </div>
              </div>
            </>
          )}

          <div className="flex justify-end space-x-4">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
              disabled={loading}
            >
              {t('common.buttons.cancel')}
            </Button>
            <Button
              type="submit"
              variant="primary"
              loading={loading}
            >
              {t('common.buttons.save')}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditHomeContentModal;