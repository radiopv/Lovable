import React, { useState, useRef } from 'react';
import { X, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import type { Child, Need } from '../types';
import { ChildSchema, NeedSchema } from '../types';
import Button from './Button';
import ErrorMessage from './ErrorMessage';

interface AddEditChildModalProps {
  child?: Child | null;
  onClose: () => void;
  onSuccess: () => void;
}

const NEED_CATEGORIES = [
  { value: 'essential', label: 'Besoins essentiels' },
  { value: 'healthcare', label: 'Santé' },
  { value: 'education', label: 'Éducation' },
  { value: 'clothing', label: 'Vêtements' },
  { value: 'development', label: 'Développement' },
  { value: 'emergency', label: 'Urgences' }
] as const;

const AddEditChildModal: React.FC<AddEditChildModalProps> = ({
  child,
  onClose,
  onSuccess
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<Child>>({
    name: child?.name || '',
    age: child?.age || 0,
    gender: child?.gender || 'male',
    city: child?.city || '',
    birthday: child?.birthday || '',
    is_sponsored: child?.is_sponsored || false,
    private_notes: child?.private_notes || '',
    image_url: child?.image_url
  });

  const [needs, setNeeds] = useState<Partial<Need>[]>([]);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    if (child?.id) {
      fetchNeeds(child.id);
    }
  }, [child?.id]);

  const fetchNeeds = async (childId: string) => {
    try {
      const { data, error } = await supabase
        .from('needs')
        .select('*')
        .eq('child_id', childId);

      if (error) throw error;
      setNeeds(data || []);
    } catch (err) {
      console.error('Error fetching needs:', err);
      toast.error('Error loading child needs');
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image must not exceed 5MB');
      return;
    }

    setImageFile(file);
  };

  const addNeed = () => {
    setNeeds(prev => [...prev, {
      category: 'essential',
      description: '',
      priority: 'medium',
      status: 'pending',
      is_urgent: false
    }]);
  };

  const removeNeed = (index: number) => {
    setNeeds(prev => prev.filter((_, i) => i !== index));
  };

  const updateNeed = (index: number, field: keyof Need, value: any) => {
    setNeeds(prev => prev.map((need, i) => 
      i === index ? { ...need, [field]: value } : need
    ));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      // Validate child data
      const validationResult = ChildSchema.safeParse(formData);
      if (!validationResult.success) {
        const errors = validationResult.error.errors.map(err => `${err.path.join('.')}: ${err.message}`);
        throw new Error(`Validation failed:\n${errors.join('\n')}`);
      }

      // Validate needs
      const needsValidation = needs.map(need => NeedSchema.safeParse(need));
      const invalidNeeds = needsValidation.filter(result => !result.success);
      if (invalidNeeds.length > 0) {
        const errors = invalidNeeds.flatMap(result => 
          !result.success ? result.error.errors.map(err => `${err.path.join('.')}: ${err.message}`) : []
        );
        throw new Error(`Needs validation failed:\n${errors.join('\n')}`);
      }

      setLoading(true);

      let image_url = child?.image_url;

      if (imageFile) {
        const fileExt = imageFile.name.split('.').pop();
        const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
        const filePath = `children/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('media')
          .upload(filePath, imageFile);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('media')
          .getPublicUrl(filePath);

        image_url = publicUrl;
      }

      const validatedChild = validationResult.data;
      const validatedNeeds = needsValidation
        .filter((result): result is { success: true; data: Need } => result.success)
        .map(result => result.data);

      if (child?.id) {
        // Update existing child
        const { error: updateError } = await supabase
          .from('children')
          .update({ ...validatedChild, image_url })
          .eq('id', child.id);

        if (updateError) throw updateError;

        // Update needs
        const { error: deleteNeedsError } = await supabase
          .from('needs')
          .delete()
          .eq('child_id', child.id);

        if (deleteNeedsError) throw deleteNeedsError;

        if (validatedNeeds.length > 0) {
          const { error: insertNeedsError } = await supabase
            .from('needs')
            .insert(validatedNeeds.map(need => ({
              ...need,
              child_id: child.id
            })));

          if (insertNeedsError) throw insertNeedsError;
        }
      } else {
        // Create new child
        const { data: newChild, error: insertError } = await supabase
          .from('children')
          .insert([{ ...validatedChild, image_url }])
          .select()
          .single();

        if (insertError) throw insertError;

        // Create needs for new child
        if (validatedNeeds.length > 0 && newChild) {
          const { error: insertNeedsError } = await supabase
            .from('needs')
            .insert(validatedNeeds.map(need => ({
              ...need,
              child_id: newChild.id
            })));

          if (insertNeedsError) throw insertNeedsError;
        }
      }

      toast.success(child ? 'Child updated successfully' : 'Child added successfully');
      onSuccess();
    } catch (err) {
      console.error('Error:', err);
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full p-6 relative max-h-[90vh] overflow-y-auto">
        <Button
          variant="secondary"
          size="sm"
          icon={X}
          onClick={onClose}
          className="absolute top-4 right-4"
        />

        <h2 className="text-2xl font-bold mb-6">
          {child ? 'Edit Child' : 'Add Child'}
        </h2>

        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Name
              </label>
              <input
                type="text"
                required
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                disabled={loading}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Age
              </label>
              <input
                type="number"
                required
                min="0"
                max="18"
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                value={formData.age}
                onChange={(e) => setFormData(prev => ({ ...prev, age: parseInt(e.target.value) }))}
                disabled={loading}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Gender
              </label>
              <select
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                value={formData.gender}
                onChange={(e) => setFormData(prev => ({ ...prev, gender: e.target.value as 'male' | 'female' }))}
                disabled={loading}
              >
                <option value="male">Boy</option>
                <option value="female">Girl</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                City
              </label>
              <input
                type="text"
                required
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                value={formData.city}
                onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                disabled={loading}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Birthday
              </label>
              <input
                type="date"
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                value={formData.birthday || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, birthday: e.target.value }))}
                disabled={loading}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Photo
              </label>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImageChange}
                accept="image/*"
                className="w-full"
                disabled={loading}
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Needs
              </label>
              <Button
                type="button"
                variant="secondary"
                size="sm"
                icon={Plus}
                onClick={addNeed}
                disabled={loading}
              >
                Add Need
              </Button>
            </div>

            <div className="space-y-4">
              {needs.map((need, index) => (
                <div key={index} className="flex gap-4 items-start">
                  <select
                    className="flex-1 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                    value={need.category}
                    onChange={(e) => updateNeed(index, 'category', e.target.value)}
                    disabled={loading}
                  >
                    {NEED_CATEGORIES.map(category => (
                      <option key={category.value} value={category.value}>
                        {category.label}
                      </option>
                    ))}
                  </select>

                  <input
                    type="text"
                    placeholder="Description"
                    className="flex-2 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                    value={need.description}
                    onChange={(e) => updateNeed(index, 'description', e.target.value)}
                    disabled={loading}
                  />

                  <select
                    className="px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                    value={need.priority}
                    onChange={(e) => updateNeed(index, 'priority', e.target.value)}
                    disabled={loading}
                  >
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>

                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      checked={need.is_urgent}
                      onChange={(e) => updateNeed(index, 'is_urgent', e.target.checked)}
                      className="rounded border-gray-300 text-red-600 focus:ring-red-500"
                      disabled={loading}
                    />
                    <span className="ml-2 text-sm">Urgent</span>
                  </div>

                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    icon={Trash2}
                    onClick={() => removeNeed(index)}
                    disabled={loading}
                  />
                </div>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Private Notes
            </label>
            <textarea
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              rows={4}
              value={formData.private_notes || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, private_notes: e.target.value }))}
              placeholder="Private notes (visible only to administrators)"
              disabled={loading}
            />
          </div>

          <div className="flex justify-end space-x-4">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              loading={loading}
            >
              {child ? 'Update' : 'Create'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddEditChildModal;