import React, { useState } from 'react';
import { Heart, MessageSquare, Share2, ThumbsUp, Download, Globe } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import Button from './Button';

interface TestimonialCardProps {
  testimonial: {
    id: string;
    message: string;
    category: string;
    language: string;
    likes: number;
    helpful_count: number;
    media_urls: string[];
    sponsor: {
      name: string;
      is_anonymous: boolean;
    };
    child: {
      name: string;
    };
    created_at: string;
  };
  onLike?: () => void;
  onComment?: () => void;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({
  testimonial,
  onLike,
  onComment
}) => {
  const { t } = useTranslation();
  const [isTranslating, setIsTranslating] = useState(false);

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: `Témoignage de parrainage - ${testimonial.child.name}`,
          text: testimonial.message,
          url: window.location.href
        });
      } else {
        await navigator.clipboard.writeText(testimonial.message);
        toast.success('Témoignage copié dans le presse-papier');
      }
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };

  const handleTranslate = async () => {
    setIsTranslating(true);
    try {
      // Implement translation logic here
      toast.success('Traduction effectuée');
    } catch (error) {
      console.error('Error translating:', error);
      toast.error('Erreur lors de la traduction');
    } finally {
      setIsTranslating(false);
    }
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([testimonial.message], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `temoignage-${testimonial.child.name}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div>
          <p className="font-semibold text-lg">
            {testimonial.sponsor.is_anonymous ? 'Parrain anonyme' : testimonial.sponsor.name}
          </p>
          <p className="text-sm text-gray-500">
            Parrain de {testimonial.child.name}
          </p>
          <p className="text-xs text-gray-400">
            {new Date(testimonial.created_at).toLocaleDateString()}
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="secondary"
            size="sm"
            icon={Globe}
            onClick={handleTranslate}
            disabled={isTranslating}
          >
            {t('testimonials.actions.translate')}
          </Button>
          <Button
            variant="secondary"
            size="sm"
            icon={Download}
            onClick={handleDownload}
          >
            {t('testimonials.actions.download')}
          </Button>
        </div>
      </div>

      <blockquote className="text-gray-700 italic mb-4">
        "{testimonial.message}"
      </blockquote>

      {testimonial.media_urls && testimonial.media_urls.length > 0 && (
        <div className="grid grid-cols-2 gap-2 mb-4">
          {testimonial.media_urls.map((url, index) => (
            <img
              key={index}
              src={url}
              alt={`Photo ${index + 1}`}
              className="w-full h-32 object-cover rounded-lg"
            />
          ))}
        </div>
      )}

      <div className="flex items-center justify-between pt-4 border-t">
        <div className="flex gap-4">
          <Button
            variant="secondary"
            size="sm"
            icon={Heart}
            onClick={onLike}
          >
            {testimonial.likes}
          </Button>
          <Button
            variant="secondary"
            size="sm"
            icon={ThumbsUp}
            onClick={onLike}
          >
            {testimonial.helpful_count}
          </Button>
          <Button
            variant="secondary"
            size="sm"
            icon={MessageSquare}
            onClick={onComment}
          >
            {t('testimonials.actions.comment')}
          </Button>
        </div>
        <Button
          variant="secondary"
          size="sm"
          icon={Share2}
          onClick={handleShare}
        >
          {t('testimonials.actions.share')}
        </Button>
      </div>
    </div>
  );
};

export default TestimonialCard;