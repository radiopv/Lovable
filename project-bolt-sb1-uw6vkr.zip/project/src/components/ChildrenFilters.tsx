import React from 'react';
import { X } from 'lucide-react';
import Button from './Button';

interface FiltersState {
  city: string;
  minAge: string;
  maxAge: string;
  gender: string;
  isSponsored: string;
}

interface ChildrenFiltersProps {
  filters: FiltersState;
  onFilterChange: (filters: FiltersState) => void;
  onReset: () => void;
  cities: string[];
}

const ChildrenFilters: React.FC<ChildrenFiltersProps> = ({
  filters,
  onFilterChange,
  onReset,
  cities
}) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Filtres</h2>
        <Button
          variant="secondary"
          size="sm"
          icon={X}
          onClick={onReset}
        >
          Réinitialiser
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Ville
          </label>
          <select
            className="w-full px-3 py-2 border rounded-lg"
            value={filters.city}
            onChange={(e) => onFilterChange({ ...filters, city: e.target.value })}
          >
            <option value="">Toutes les villes</option>
            {cities.map(city => (
              <option key={city} value={city}>{city}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Âge minimum
          </label>
          <input
            type="number"
            min="0"
            max="18"
            className="w-full px-3 py-2 border rounded-lg"
            value={filters.minAge}
            onChange={(e) => onFilterChange({ ...filters, minAge: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Âge maximum
          </label>
          <input
            type="number"
            min="0"
            max="18"
            className="w-full px-3 py-2 border rounded-lg"
            value={filters.maxAge}
            onChange={(e) => onFilterChange({ ...filters, maxAge: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Genre
          </label>
          <select
            className="w-full px-3 py-2 border rounded-lg"
            value={filters.gender}
            onChange={(e) => onFilterChange({ ...filters, gender: e.target.value })}
          >
            <option value="">Tous</option>
            <option value="male">Garçon</option>
            <option value="female">Fille</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Statut
          </label>
          <select
            className="w-full px-3 py-2 border rounded-lg"
            value={filters.isSponsored}
            onChange={(e) => onFilterChange({ ...filters, isSponsored: e.target.value })}
          >
            <option value="">Tous</option>
            <option value="true">Parrainé</option>
            <option value="false">Non parrainé</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default ChildrenFilters;