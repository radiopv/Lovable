import React, { useState } from 'react';
import { X } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import ErrorMessage from './ErrorMessage';

interface NewTravelAnnouncementModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

const NewTravelAnnouncementModal: React.FC<NewTravelAnnouncementModalProps> = ({
  onClose,
  onSuccess
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    departure_date: '',
    return_date: '',
    destination: '',
    available_space: '',
    notes: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const sponsorData = localStorage.getItem('sponsor');
      if (!sponsorData) {
        throw new Error('Vous devez être connecté pour créer une annonce');
      }

      const sponsor = JSON.parse(sponsorData);
      const { error: insertError } = await supabase
        .from('travel_announcements')
        .insert({
          sponsor_id: sponsor.id,
          departure_date: formData.departure_date,
          return_date: formData.return_date,
          destination: formData.destination.trim(),
          available_space: formData.available_space.trim(),
          notes: formData.notes.trim() || null
        });

      if (insertError) throw insertError;

      // Notifier tous les parrains
      const { data: sponsors, error: sponsorsError } = await supabase
        .from('sponsors')
        .select('email, name')
        .neq('id', sponsor.id);

      if (sponsorsError) throw sponsorsError;

      // Simuler l'envoi d'emails (à implémenter avec votre service d'emails)
      sponsors?.forEach(recipient => {
        console.log('Email envoyé à:', recipient.email, {
          subject: 'Nouveau voyage à Cuba annoncé',
          content: `
            ${sponsor.name} a annoncé un voyage à ${formData.destination} 
            du ${new Date(formData.departure_date).toLocaleDateString()} 
            au ${new Date(formData.return_date).toLocaleDateString()}.
            
            Espace disponible : ${formData.available_space}
            
            Connectez-vous au forum pour faire une demande de transport.
          `
        });
      });

      toast.success('Annonce créée avec succès');
      onSuccess();
    } catch (err) {
      console.error('Erreur:', err);
      setError(err instanceof Error ? err.message : 'Erreur lors de la création de l\'annonce');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
          disabled={loading}
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-bold mb-4">
          Annoncer un voyage à Cuba
        </h2>

        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date de départ
              </label>
              <input
                type="date"
                required
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                value={formData.departure_date}
                onChange={(e) => setFormData(prev => ({ ...prev, departure_date: e.target.value }))}
                min={new Date().toISOString().split('T')[0]}
                disabled={loading}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date de retour
              </label>
              <input
                type="date"
                required
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                value={formData.return_date}
                onChange={(e) => setFormData(prev => ({ ...prev, return_date: e.target.value }))}
                min={formData.departure_date}
                disabled={loading}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Destination à Cuba
            </label>
            <input
              type="text"
              required
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={formData.destination}
              onChange={(e) => setFormData(prev => ({ ...prev, destination: e.target.value }))}
              placeholder="Ex: Varadero, La Havane..."
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Espace disponible
            </label>
            <input
              type="text"
              required
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={formData.available_space}
              onChange={(e) => setFormData(prev => ({ ...prev, available_space: e.target.value }))}
              placeholder="Ex: Une valise de 20kg, petit sac..."
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes supplémentaires (optionnel)
            </label>
            <textarea
              rows={4}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Précisions sur les conditions de transport..."
              disabled={loading}
            />
          </div>

          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border rounded-lg hover:bg-gray-50"
              disabled={loading}
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 flex items-center justify-center"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Création en cours...
                </>
              ) : (
                'Créer l\'annonce'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewTravelAnnouncementModal;