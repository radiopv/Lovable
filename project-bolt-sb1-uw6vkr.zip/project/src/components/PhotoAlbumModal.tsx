import React, { useState } from 'react';
import { X, Upload, Trash2, Eye } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import type { Child, Memory } from '../types';
import Button from './Button';
import { formatDate } from '../utils/date';

interface PhotoAlbumModalProps {
  child: Child;
  photos: Memory[];
  onClose: () => void;
  onPhotoAdded: () => void;
}

const PhotoAlbumModal: React.FC<PhotoAlbumModalProps> = ({
  child,
  photos,
  onClose,
  onPhotoAdded
}) => {
  const { t, i18n } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState<Memory | null>(null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error(t('sponsor.dashboard.photos.size_error'));
      return;
    }

    setUploadingPhoto(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `memories/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('images')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('images')
        .getPublicUrl(filePath);

      const { error: insertError } = await supabase
        .from('memories')
        .insert({
          child_id: child.id,
          sponsor_id: child.sponsor_id,
          image_url: publicUrl,
          is_public: false
        });

      if (insertError) throw insertError;

      toast.success(t('sponsor.dashboard.photos.upload_success'));
      onPhotoAdded();
    } catch (err) {
      console.error('Error:', err);
      toast.error(t('sponsor.dashboard.photos.upload_error'));
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleDeletePhoto = async (photoId: string) => {
    if (!confirm(t('sponsor.dashboard.photos.delete_confirm'))) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('memories')
        .delete()
        .eq('id', photoId);

      if (error) throw error;

      toast.success(t('sponsor.dashboard.photos.delete_success'));
      onPhotoAdded();
    } catch (err) {
      console.error('Error:', err);
      toast.error(t('sponsor.dashboard.photos.delete_error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full p-6 relative max-h-[90vh] overflow-y-auto">
        <Button
          variant="secondary"
          size="sm"
          icon={X}
          onClick={onClose}
          className="absolute top-4 right-4"
        />

        <h2 className="text-2xl font-bold mb-6">
          {t('sponsor.dashboard.photos.album_title', { name: child.name })}
        </h2>

        <div className="mb-6">
          <Button
            variant="primary"
            icon={Upload}
            onClick={() => fileInputRef.current?.click()}
            loading={uploadingPhoto}
          >
            {t('sponsor.dashboard.photos.add')}
          </Button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handlePhotoUpload}
            accept="image/*"
            className="hidden"
          />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {photos.map((photo) => (
            <div key={photo.id} className="relative group">
              <img
                src={photo.image_url}
                alt={t('sponsor.dashboard.photos.memory_alt', { date: formatDate(photo.created_at, i18n.language) })}
                className="w-full h-48 object-cover rounded-lg"
              />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-opacity flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100">
                <Button
                  variant="secondary"
                  size="sm"
                  icon={Eye}
                  onClick={() => setSelectedPhoto(photo)}
                >
                  {t('sponsor.dashboard.photos.view')}
                </Button>
                <Button
                  variant="danger"
                  size="sm"
                  icon={Trash2}
                  onClick={() => handleDeletePhoto(photo.id)}
                  loading={loading}
                >
                  {t('sponsor.dashboard.photos.delete')}
                </Button>
              </div>
            </div>
          ))}
        </div>

        {photos.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            {t('sponsor.dashboard.photos.no_photos')}
          </div>
        )}

        {selectedPhoto && (
          <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center p-4 z-50">
            <div className="relative max-w-4xl w-full">
              <Button
                variant="secondary"
                size="sm"
                icon={X}
                onClick={() => setSelectedPhoto(null)}
                className="absolute top-4 right-4"
              />
              <img
                src={selectedPhoto.image_url}
                alt={t('sponsor.dashboard.photos.memory_alt', { 
                  date: formatDate(selectedPhoto.created_at, i18n.language)
                })}
                className="w-full h-auto max-h-[80vh] object-contain"
              />
              {selectedPhoto.description && (
                <p className="text-white mt-4 text-center">
                  {selectedPhoto.description}
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PhotoAlbumModal;