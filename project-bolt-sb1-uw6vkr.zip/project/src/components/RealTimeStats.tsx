import React, { useState, useEffect } from 'react';
import { TrendingUp, Users, Heart, Clock, BookOpen } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { formatDate } from '../utils/date';
import LoadingSpinner from './LoadingSpinner';
import ErrorMessage from './ErrorMessage';

const RealTimeStats: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const { data: children, error: childrenError } = await supabase
        .from('children')
        .select('*');

      if (childrenError) throw childrenError;

      const { data: sponsors, error: sponsorsError } = await supabase
        .from('sponsors')
        .select('*');

      if (sponsorsError) throw sponsorsError;

      const { data: memories, error: memoriesError } = await supabase
        .from('memories')
        .select('*');

      if (memoriesError) throw memoriesError;

      setStats({
        totalChildren: children?.length || 0,
        sponsoredChildren: children?.filter(c => c.is_sponsored).length || 0,
        activeSponsors: sponsors?.filter(s => s.children_sponsored?.length > 0).length || 0,
        totalMemories: memories?.length || 0,
        firstSponsorshipDate: sponsors?.[0]?.created_at || new Date().toISOString()
      });
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des statistiques');
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;
  if (!stats) return null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-gray-600 text-sm">Enfants aidés</p>
            <p className="text-3xl font-bold mt-1">{stats.sponsoredChildren}</p>
          </div>
          <Heart className="w-8 h-8 text-red-500" />
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-gray-600 text-sm">Premier parrainage</p>
            <p className="text-3xl font-bold mt-1">{formatDate(stats.firstSponsorshipDate)}</p>
          </div>
          <Clock className="w-8 h-8 text-red-500" />
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-gray-600 text-sm">Parrains actifs</p>
            <p className="text-3xl font-bold mt-1">{stats.activeSponsors}</p>
          </div>
          <Users className="w-8 h-8 text-red-500" />
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-gray-600 text-sm">Souvenirs partagés</p>
            <p className="text-3xl font-bold mt-1">{stats.totalMemories}</p>
          </div>
          <BookOpen className="w-8 h-8 text-red-500" />
        </div>
      </div>
    </div>
  );
};

export default RealTimeStats;