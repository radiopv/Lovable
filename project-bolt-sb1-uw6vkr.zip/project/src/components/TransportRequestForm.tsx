import React, { useState } from 'react';
import { Package, MapPin, Calendar, Info } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import ErrorMessage from './ErrorMessage';
import type { Child } from '../types';

interface TransportRequestFormProps {
  sponsorId: string;
  sponsoredChildren: Child[];
}

const TransportRequestForm: React.FC<TransportRequestFormProps> = ({
  sponsorId,
  sponsoredChildren
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    items: '',
    pickup_location: '',
    delivery_location: '',
    preferred_dates: '',
    notes: '',
    selectedChildren: [] as string[]
  });

  const handleChildSelection = (childId: string) => {
    setFormData(prev => ({
      ...prev,
      selectedChildren: prev.selectedChildren.includes(childId)
        ? prev.selectedChildren.filter(id => id !== childId)
        : [...prev.selectedChildren, childId]
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (formData.selectedChildren.length === 0) {
      setError('Veuillez sélectionner au moins un enfant');
      setLoading(false);
      return;
    }

    try {
      // Créer une demande de transport pour chaque enfant sélectionné
      const requests = formData.selectedChildren.map(childId => ({
        sponsor_id: sponsorId,
        child_id: childId,
        items: formData.items.trim(),
        pickup_location: formData.pickup_location.trim(),
        delivery_location: formData.delivery_location.trim(),
        preferred_dates: formData.preferred_dates.trim(),
        notes: formData.notes.trim() || null
      }));

      const { error: requestError } = await supabase
        .from('transport_requests')
        .insert(requests);

      if (requestError) throw requestError;

      toast.success('Demande de transport enregistrée avec succès');
      
      // Réinitialiser le formulaire
      setFormData({
        items: '',
        pickup_location: '',
        delivery_location: '',
        preferred_dates: '',
        notes: '',
        selectedChildren: []
      });
    } catch (err) {
      console.error('Erreur:', err);
      setError(err instanceof Error ? err.message : 'Erreur lors de l\'enregistrement de la demande');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4 flex items-center">
        <Package className="w-6 h-6 mr-2 text-red-600" />
        Demande de Transport
      </h2>

      {error && <ErrorMessage message={error} />}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="bg-gray-50 p-4 rounded-lg">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Sélectionnez les enfants concernés *
          </label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {sponsoredChildren.map(child => (
              <label
                key={child.id}
                className={`flex items-center p-2 rounded-lg cursor-pointer transition-colors ${
                  formData.selectedChildren.includes(child.id)
                    ? 'bg-red-50 border-red-200'
                    : 'bg-white border-gray-200'
                } border`}
              >
                <input
                  type="checkbox"
                  checked={formData.selectedChildren.includes(child.id)}
                  onChange={() => handleChildSelection(child.id)}
                  className="rounded border-gray-300 text-red-600 focus:ring-red-500 mr-2"
                  disabled={loading}
                />
                <span className="text-sm">{child.name}</span>
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Articles à transporter *
          </label>
          <textarea
            required
            rows={3}
            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
            value={formData.items}
            onChange={(e) => setFormData(prev => ({ ...prev, items: e.target.value }))}
            placeholder="Décrivez les articles que vous souhaitez faire transporter (type, taille, poids approximatif)"
            disabled={loading}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <MapPin className="w-4 h-4 inline mr-1" />
              Lieu de ramassage *
            </label>
            <input
              type="text"
              required
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={formData.pickup_location}
              onChange={(e) => setFormData(prev => ({ ...prev, pickup_location: e.target.value }))}
              placeholder="Ville, région"
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <MapPin className="w-4 h-4 inline mr-1" />
              Lieu de livraison à Cuba *
            </label>
            <input
              type="text"
              required
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={formData.delivery_location}
              onChange={(e) => setFormData(prev => ({ ...prev, delivery_location: e.target.value }))}
              placeholder="Ville, région"
              disabled={loading}
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <Calendar className="w-4 h-4 inline mr-1" />
            Dates préférées
          </label>
          <input
            type="text"
            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
            value={formData.preferred_dates}
            onChange={(e) => setFormData(prev => ({ ...prev, preferred_dates: e.target.value }))}
            placeholder="Ex: Entre juin et août 2024"
            disabled={loading}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <Info className="w-4 h-4 inline mr-1" />
            Notes supplémentaires
          </label>
          <textarea
            rows={3}
            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
            value={formData.notes}
            onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
            placeholder="Informations complémentaires, contraintes particulières..."
            disabled={loading}
          />
        </div>

        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 text-sm text-yellow-700">
          <p>
            <strong>Note importante :</strong> Cette demande sera visible par les parrains qui voyagent 
            à Cuba. Ils pourront vous contacter s'ils peuvent transporter vos articles.
          </p>
        </div>

        <button
          type="submit"
          disabled={loading || formData.selectedChildren.length === 0}
          className="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 flex items-center justify-center"
        >
          {loading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Enregistrement...
            </>
          ) : (
            'Enregistrer la demande'
          )}
        </button>
      </form>
    </div>
  );
};

export default TransportRequestForm;