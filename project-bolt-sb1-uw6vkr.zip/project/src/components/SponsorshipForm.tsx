import React, { useState } from 'react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import type { Child } from '../types';
import Button from './Button';
import ErrorMessage from './ErrorMessage';

interface SponsorshipFormProps {
  child: Child;
  onClose: () => void;
  onSuccess: () => void;
}

const SponsorshipForm: React.FC<SponsorshipFormProps> = ({
  child,
  onClose,
  onSuccess
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
    is_anonymous: false
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.name.trim() || !formData.email.trim()) {
      setError('Le nom et l\'email sont requis');
      return;
    }

    setLoading(true);

    try {
      // First create or get the sponsor
      const { data: existingSponsor } = await supabase
        .from('sponsors')
        .select('*')
        .eq('email', formData.email.toLowerCase().trim())
        .maybeSingle();

      let sponsorId: string;

      if (existingSponsor) {
        // Update existing sponsor
        sponsorId = existingSponsor.id;
        const { error: updateError } = await supabase
          .from('sponsors')
          .update({
            name: formData.name.trim(),
            is_anonymous: formData.is_anonymous,
            updated_at: new Date().toISOString()
          })
          .eq('id', sponsorId);

        if (updateError) throw updateError;

        if (existingSponsor.children_sponsored?.length > 0) {
          toast.info('Vous parrainez déjà un ou plusieurs enfants. Votre nouveau parrainage sera ajouté à votre compte.');
        }
      } else {
        // Create new sponsor
        const { data: newSponsor, error: insertError } = await supabase
          .from('sponsors')
          .insert({
            name: formData.name.trim(),
            email: formData.email.toLowerCase().trim(),
            is_anonymous: formData.is_anonymous,
            children_sponsored: []
          })
          .select()
          .single();

        if (insertError) throw insertError;
        if (!newSponsor) throw new Error('Failed to create sponsor');
        
        sponsorId = newSponsor.id;
      }

      // Create sponsorship request
      const { error: requestError } = await supabase
        .from('sponsorship_requests')
        .insert({
          child_id: child.id,
          sponsor_id: sponsorId,
          message: formData.message.trim() || null,
          status: 'pending'
        });

      if (requestError) throw requestError;

      toast.success('Votre demande de parrainage a été envoyée avec succès !');
      onSuccess();
    } catch (err) {
      console.error('Error:', err);
      setError('Une erreur est survenue lors de la demande de parrainage');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg max-w-md w-full p-6 relative">
      <h2 className="text-2xl font-bold mb-6">
        Parrainer {child.name}
      </h2>

      {error && <ErrorMessage message={error} />}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Votre nom
          </label>
          <input
            type="text"
            required
            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            disabled={loading}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Votre email
          </label>
          <input
            type="email"
            required
            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
            value={formData.email}
            onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
            disabled={loading}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Message (optionnel)
          </label>
          <textarea
            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
            rows={4}
            value={formData.message}
            onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
            placeholder="Pourquoi souhaitez-vous parrainer cet enfant ?"
            disabled={loading}
          />
        </div>

        <div className="flex items-center">
          <input
            type="checkbox"
            id="is_anonymous"
            className="rounded border-gray-300 text-red-600 focus:ring-red-500"
            checked={formData.is_anonymous}
            onChange={(e) => setFormData(prev => ({ ...prev, is_anonymous: e.target.checked }))}
            disabled={loading}
          />
          <label htmlFor="is_anonymous" className="ml-2 text-sm text-gray-700">
            Je souhaite rester anonyme
          </label>
        </div>

        <div className="flex justify-end space-x-4">
          <Button
            type="button"
            variant="secondary"
            onClick={onClose}
            disabled={loading}
          >
            Annuler
          </Button>
          <Button
            type="submit"
            variant="primary"
            loading={loading}
          >
            Envoyer la demande
          </Button>
        </div>
      </form>
    </div>
  );
};

export default SponsorshipForm;