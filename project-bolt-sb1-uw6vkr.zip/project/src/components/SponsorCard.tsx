import React from 'react';
import { Facebook, Heart } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { Sponsor } from '../types';
import { formatDate } from '../utils/date';

interface SponsorCardProps {
  sponsor: Sponsor;
  onEdit?: () => void;
  onDelete?: () => void;
}

const SponsorCard: React.FC<SponsorCardProps> = ({ sponsor, onEdit, onDelete }) => {
  const { t, i18n } = useTranslation();

  return (
    <div className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-semibold text-lg flex items-center gap-2">
            {sponsor.display_name}
            {sponsor.is_anonymous && (
              <span className="text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded-full">
                {t('sponsor.anonymous')}
              </span>
            )}
          </h3>
          <p className="text-sm text-gray-600">{sponsor.email}</p>
          <p className="text-sm text-gray-500">
            {t('sponsor.since', { 
              date: formatDate(sponsor.created_at, i18n.language) 
            })}
          </p>
        </div>

        {sponsor.facebook_url && (
          <a
            href={sponsor.facebook_url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-600 hover:text-blue-800"
            aria-label={t('sponsor.facebook_profile')}
          >
            <Facebook className="w-5 h-5" />
          </a>
        )}
      </div>

      <div className="mt-4">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Heart className="w-4 h-4 text-red-500" />
          <span>
            {t('sponsor.children_count', { 
              count: sponsor.children_sponsored.length 
            })}
          </span>
        </div>
      </div>
    </div>
  );
};

export default SponsorCard;