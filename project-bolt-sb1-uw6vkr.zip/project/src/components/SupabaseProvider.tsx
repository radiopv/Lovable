import React, { createContext, useContext, ReactNode } from 'react';
import { supabase } from '../lib/supabase';

const SupabaseContext = createContext(supabase);

interface SupabaseProviderProps {
  children: ReactNode;
}

export const SupabaseProvider: React.FC<SupabaseProviderProps> = ({ children }) => {
  return (
    <SupabaseContext.Provider value={supabase}>
      {children}
    </SupabaseContext.Provider>
  );
};

export const useSupabase = () => {
  const context = useContext(SupabaseContext);
  if (!context) {
    throw new Error('useSupabase doit être utilisé dans un SupabaseProvider');
  }
  return context;
};