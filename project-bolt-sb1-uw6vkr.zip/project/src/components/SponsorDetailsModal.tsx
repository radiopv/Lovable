import React, { useState } from 'react';
import { X, Calendar, Mail, Clock, AlertTriangle, Facebook } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import type { Sponsor, Child } from '../types';
import Button from './Button';

interface SponsorDetailsModalProps {
  sponsor: Sponsor & { children: Child[] };
  onClose: () => void;
  onSponsorshipUpdate: () => void;
}

const SponsorDetailsModal: React.FC<SponsorDetailsModalProps> = ({
  sponsor,
  onClose,
  onSponsorshipUpdate
}) => {
  const [loading, setLoading] = useState(false);

  const handleRemoveSponsorship = async (childId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce parrainage ?')) return;

    setLoading(true);
    try {
      // Update child record
      const { error: childError } = await supabase
        .from('children')
        .update({
          is_sponsored: false,
          sponsor_id: null
        })
        .eq('id', childId);

      if (childError) throw childError;

      // Update sponsor's children list
      const { error: sponsorError } = await supabase
        .from('sponsors')
        .update({
          children_sponsored: sponsor.children_sponsored.filter(id => id !== childId)
        })
        .eq('id', sponsor.id);

      if (sponsorError) throw sponsorError;

      toast.success('Parrainage supprimé avec succès');
      onSponsorshipUpdate();
    } catch (error) {
      console.error('Error:', error);
      toast.error('Erreur lors de la suppression du parrainage');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full p-6 relative max-h-[90vh] overflow-y-auto">
        <Button
          variant="secondary"
          size="sm"
          icon={X}
          onClick={onClose}
          className="absolute top-4 right-4"
        />

        <h2 className="text-2xl font-bold mb-6">
          Détails du parrain
        </h2>

        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm font-medium text-gray-500">Nom</h3>
              <p className="mt-1 text-lg flex items-center gap-2">
                {sponsor.display_name}
                {sponsor.is_anonymous && (
                  <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
                    Anonyme
                  </span>
                )}
                {sponsor.facebook_url && (
                  <a 
                    href={sponsor.facebook_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-800"
                  >
                    <Facebook className="w-5 h-5" />
                  </a>
                )}
              </p>
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-500">Email</h3>
              <p className="mt-1 text-lg">{sponsor.email}</p>
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-500">Date d'inscription</h3>
              <p className="mt-1 text-lg">
                {new Date(sponsor.created_at).toLocaleDateString()}
              </p>
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-500">Dernière connexion</h3>
              <p className="mt-1 text-lg">
                {sponsor.last_login ? 
                  new Date(sponsor.last_login).toLocaleDateString() : 
                  'Jamais connecté'}
              </p>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Enfants parrainés</h3>
            <div className="space-y-4">
              {sponsor.children.map((child) => (
                <div key={child.id} className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-semibold">{child.name}</h4>
                      <p className="text-sm text-gray-600">
                        {child.age} ans - {child.city}
                      </p>
                    </div>
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => handleRemoveSponsorship(child.id)}
                      disabled={loading}
                    >
                      Supprimer le parrainage
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SponsorDetailsModal;