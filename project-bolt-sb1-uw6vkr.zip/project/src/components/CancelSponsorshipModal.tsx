import React, { useState } from 'react';
import { X, Calendar } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import type { Child } from '../types';
import Button from './Button';
import ErrorMessage from './ErrorMessage';

interface CancelSponsorshipModalProps {
  child: Child;
  onClose: () => void;
  onSuccess: () => void;
}

const CancelSponsorshipModal: React.FC<CancelSponsorshipModalProps> = ({
  child,
  onClose,
  onSuccess
}) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [endDate, setEndDate] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!endDate) {
      setError('Veuillez sélectionner une date de fin de parrainage');
      return;
    }

    const selectedDate = new Date(endDate);
    const today = new Date();
    if (selectedDate <= today) {
      setError('La date de fin doit être dans le futur');
      return;
    }

    setLoading(true);

    try {
      const { error: updateError } = await supabase
        .from('children')
        .update({
          sponsorship_end_date: endDate,
          updated_at: new Date().toISOString()
        })
        .eq('id', child.id);

      if (updateError) throw updateError;

      toast.success(`Le parrainage se terminera le ${new Date(endDate).toLocaleDateString()}`);
      onSuccess();
    } catch (err) {
      console.error('Error:', err);
      setError('Une erreur est survenue lors de la planification de la fin du parrainage');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-md w-full p-6 relative">
        <Button
          variant="secondary"
          size="sm"
          icon={X}
          onClick={onClose}
          className="absolute top-4 right-4"
        />

        <div className="flex items-center space-x-3 mb-6">
          <Calendar className="w-8 h-8 text-red-500" />
          <h2 className="text-2xl font-bold">Planifier la fin du parrainage</h2>
        </div>

        <p className="text-gray-600 mb-6">
          Vous pouvez définir une date de fin pour votre parrainage de {child.name}.
          À cette date, l'enfant redeviendra disponible pour un nouveau parrainage.
        </p>

        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Date de fin du parrainage
            </label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="date"
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                min={new Date(Date.now() + 86400000).toISOString().split('T')[0]}
                required
                disabled={loading}
              />
            </div>
          </div>

          <div className="flex justify-end space-x-4">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
              disabled={loading}
            >
              {t('common.buttons.cancel')}
            </Button>
            <Button
              type="submit"
              variant="primary"
              loading={loading}
            >
              Confirmer la date de fin
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CancelSponsorshipModal;