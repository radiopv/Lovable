import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Calendar, DollarSign, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import type { Need, NeedCategory } from '../types';
import Button from './Button';
import LoadingSpinner from './LoadingSpinner';
import ErrorMessage from './ErrorMessage';

interface NeedsManagerProps {
  childId: string;
  onUpdate?: () => void;
}

const CATEGORIES: Record<NeedCategory, string> = {
  essential: 'Besoins essentiels',
  healthcare: 'Santé',
  education: 'Éducation',
  clothing: 'Vêtements',
  development: 'Développement',
  emergency: 'Urgences'
};

const SUBCATEGORIES = {
  essential: ['Nourriture', 'Eau', 'Logement'],
  healthcare: ['Médicaments', 'Vaccins', 'Consultations'],
  education: ['Livres', 'Uniformes', 'Fournitures', 'Frais'],
  clothing: ['Vêtements de saison', 'Chaussures', 'Uniformes'],
  development: ['Équipement sportif', 'Matériel pédagogique'],
  emergency: ['Urgence médicale', 'Autre']
};

const NeedsManager: React.FC<NeedsManagerProps> = ({ childId, onUpdate }) => {
  const [needs, setNeeds] = useState<Need[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedNeed, setSelectedNeed] = useState<Need | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [filters, setFilters] = useState({
    category: 'all',
    status: 'all',
    priority: 'all'
  });

  useEffect(() => {
    fetchNeeds();
  }, [childId]);

  const fetchNeeds = async () => {
    try {
      const { data, error } = await supabase
        .from('needs')
        .select('*')
        .eq('child_id', childId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setNeeds(data || []);
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des besoins');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (needId: string, status: Need['status']) => {
    try {
      const { error } = await supabase
        .from('needs')
        .update({ status })
        .eq('id', needId);

      if (error) throw error;
      fetchNeeds();
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de la mise à jour du statut');
    }
  };

  const handleDelete = async (needId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce besoin ?')) return;

    try {
      const { error } = await supabase
        .from('needs')
        .delete()
        .eq('id', needId);

      if (error) throw error;
      toast.success('Besoin supprimé avec succès');
      fetchNeeds();
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de la suppression');
    }
  };

  const filteredNeeds = needs.filter(need => {
    const matchesCategory = filters.category === 'all' || need.category === filters.category;
    const matchesStatus = filters.status === 'all' || need.status === filters.status;
    const matchesPriority = filters.priority === 'all' || need.priority === filters.priority;
    return matchesCategory && matchesStatus && matchesPriority;
  });

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Besoins</h2>
        <Button
          variant="primary"
          icon={Plus}
          onClick={() => setShowAddModal(true)}
        >
          Ajouter un besoin
        </Button>
      </div>

      <div className="flex flex-wrap gap-4">
        <select
          className="px-3 py-2 border rounded-lg"
          value={filters.category}
          onChange={(e) => setFilters(prev => ({ ...prev, category: e.target.value }))}
        >
          <option value="all">Toutes les catégories</option>
          {Object.entries(CATEGORIES).map(([key, label]) => (
            <option key={key} value={key}>{label}</option>
          ))}
        </select>

        <select
          className="px-3 py-2 border rounded-lg"
          value={filters.status}
          onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
        >
          <option value="all">Tous les statuts</option>
          <option value="pending">En attente</option>
          <option value="in_progress">En cours</option>
          <option value="fulfilled">Réalisé</option>
        </select>

        <select
          className="px-3 py-2 border rounded-lg"
          value={filters.priority}
          onChange={(e) => setFilters(prev => ({ ...prev, priority: e.target.value }))}
        >
          <option value="all">Toutes les priorités</option>
          <option value="high">Haute</option>
          <option value="medium">Moyenne</option>
          <option value="low">Basse</option>
        </select>
      </div>

      <div className="grid gap-6">
        {filteredNeeds.map((need) => (
          <div 
            key={need.id} 
            className={`bg-white rounded-lg shadow-md p-6 ${
              need.is_urgent ? 'border-l-4 border-red-500' : ''
            }`}
          >
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-semibold">
                    {CATEGORIES[need.category as NeedCategory]}
                    {need.subcategory && ` - ${need.subcategory}`}
                  </h3>
                  {need.is_urgent && (
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                      <AlertTriangle className="w-3 h-3 mr-1" />
                      Urgent
                    </span>
                  )}
                </div>
                <p className="text-gray-600 mt-1">{need.description}</p>
                
                <div className="mt-4 flex flex-wrap gap-4">
                  {need.target_date && (
                    <div className="flex items-center text-sm text-gray-500">
                      <Calendar className="w-4 h-4 mr-1" />
                      Date cible: {new Date(need.target_date).toLocaleDateString()}
                    </div>
                  )}
                  
                  {need.estimated_cost && (
                    <div className="flex items-center text-sm text-gray-500">
                      <DollarSign className="w-4 h-4 mr-1" />
                      Coût estimé: {need.estimated_cost}€
                    </div>
                  )}

                  <div className="flex items-center text-sm text-gray-500">
                    Quantité: {need.quantity}
                  </div>
                </div>

                {need.specifications && (
                  <p className="mt-2 text-sm text-gray-600">
                    Spécifications: {need.specifications}
                  </p>
                )}

                {need.notes && (
                  <p className="mt-2 text-sm text-gray-600">
                    Notes: {need.notes}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-2">
                <select
                  className="px-3 py-2 border rounded-lg"
                  value={need.status}
                  onChange={(e) => handleStatusChange(need.id, e.target.value as Need['status'])}
                >
                  <option value="pending">En attente</option>
                  <option value="in_progress">En cours</option>
                  <option value="fulfilled">Réalisé</option>
                </select>

                <Button
                  variant="secondary"
                  size="sm"
                  icon={Edit2}
                  onClick={() => {
                    setSelectedNeed(need);
                    setShowAddModal(true);
                  }}
                >
                  Modifier
                </Button>

                <Button
                  variant="danger"
                  size="sm"
                  icon={Trash2}
                  onClick={() => handleDelete(need.id)}
                >
                  Supprimer
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredNeeds.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <p className="text-gray-500">Aucun besoin trouvé</p>
        </div>
      )}

      {/* Add/Edit Need Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full p-6 relative">
            <Button
              variant="secondary"
              size="sm"
              icon={X}
              onClick={() => {
                setShowAddModal(false);
                setSelectedNeed(null);
              }}
              className="absolute top-4 right-4"
            />

            <h2 className="text-2xl font-bold mb-6">
              {selectedNeed ? 'Modifier le besoin' : 'Ajouter un besoin'}
            </h2>

            {/* Add/Edit form goes here */}
          </div>
        </div>
      )}
    </div>
  );
};

export default NeedsManager;