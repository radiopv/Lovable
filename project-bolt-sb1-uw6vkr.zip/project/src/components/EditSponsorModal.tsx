import React, { useState } from 'react';
import { X, Facebook, Mail, Calendar, User } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import type { Sponsor } from '../types';
import Button from './Button';
import ErrorMessage from './ErrorMessage';

interface EditSponsorModalProps {
  sponsor: Sponsor;
  onClose: () => void;
  onSuccess: () => void;
}

const EditSponsorModal: React.FC<EditSponsorModalProps> = ({
  sponsor,
  onClose,
  onSuccess
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: sponsor.name,
    email: sponsor.email,
    facebook_url: sponsor.facebook_url || '',
    is_anonymous: sponsor.is_anonymous,
    contact_preferences: {
      email: true,
      facebook: false,
      ...sponsor.contact_preferences
    }
  });
  const [hasChanges, setHasChanges] = useState(false);

  const validateFacebookUrl = (url: string) => {
    if (!url) return true;
    const facebookRegex = /^(https?:\/\/)?(www\.)?facebook\.com\/.+/i;
    return facebookRegex.test(url);
  };

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    setHasChanges(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validation
    if (!formData.name.trim() || !formData.email.trim()) {
      setError('Le nom et l\'email sont requis');
      return;
    }

    if (!validateFacebookUrl(formData.facebook_url)) {
      setError('L\'URL Facebook n\'est pas valide');
      return;
    }

    setLoading(true);

    try {
      const { error: updateError } = await supabase
        .from('sponsors')
        .update({
          name: formData.name.trim(),
          email: formData.email.trim(),
          facebook_url: formData.facebook_url.trim() || null,
          is_anonymous: formData.is_anonymous,
          contact_preferences: formData.contact_preferences,
          updated_at: new Date().toISOString()
        })
        .eq('id', sponsor.id);

      if (updateError) throw updateError;

      toast.success('Parrain modifié avec succès');
      onSuccess();
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors de la modification du parrain');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (hasChanges) {
      if (confirm('Des modifications non enregistrées seront perdues. Voulez-vous continuer ?')) {
        onClose();
      }
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full p-6 relative">
        <Button
          variant="secondary"
          size="sm"
          icon={X}
          onClick={handleClose}
          className="absolute top-4 right-4"
        />

        <h2 className="text-2xl font-bold mb-6">
          Modifier le parrain
        </h2>

        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <User className="w-5 h-5 mr-2" />
                Informations personnelles
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nom complet
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                    value={formData.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    disabled={loading}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    required
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                    value={formData.email}
                    onChange={(e) => handleChange('email', e.target.value)}
                    disabled={loading}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    URL Facebook
                  </label>
                  <div className="relative">
                    <Facebook className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="url"
                      className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                      value={formData.facebook_url}
                      onChange={(e) => handleChange('facebook_url', e.target.value)}
                      placeholder="https://facebook.com/profile"
                      disabled={loading}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <Mail className="w-5 h-5 mr-2" />
                Préférences de contact
              </h3>

              <div className="space-y-4">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="email_contact"
                    className="rounded border-gray-300 text-red-600 focus:ring-red-500"
                    checked={formData.contact_preferences.email}
                    onChange={(e) => handleChange('contact_preferences', {
                      ...formData.contact_preferences,
                      email: e.target.checked
                    })}
                    disabled={loading}
                  />
                  <label htmlFor="email_contact" className="ml-2 text-sm text-gray-700">
                    Recevoir les communications par email
                  </label>
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="facebook_contact"
                    className="rounded border-gray-300 text-red-600 focus:ring-red-500"
                    checked={formData.contact_preferences.facebook}
                    onChange={(e) => handleChange('contact_preferences', {
                      ...formData.contact_preferences,
                      facebook: e.target.checked
                    })}
                    disabled={loading}
                  />
                  <label htmlFor="facebook_contact" className="ml-2 text-sm text-gray-700">
                    Autoriser les messages Facebook
                  </label>
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="is_anonymous"
                    className="rounded border-gray-300 text-red-600 focus:ring-red-500"
                    checked={formData.is_anonymous}
                    onChange={(e) => handleChange('is_anonymous', e.target.checked)}
                    disabled={loading}
                  />
                  <label htmlFor="is_anonymous" className="ml-2 text-sm text-gray-700">
                    Rester anonyme publiquement
                  </label>
                </div>
              </div>

              <div className="mt-6">
                <h4 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
                  <Calendar className="w-4 h-4 mr-2" />
                  Informations du compte
                </h4>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600">
                    Inscrit le: {new Date(sponsor.created_at).toLocaleDateString()}
                  </p>
                  {sponsor.last_login && (
                    <p className="text-sm text-gray-600">
                      Dernière connexion: {new Date(sponsor.last_login).toLocaleDateString()}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="sticky bottom-0 bg-white pt-4 mt-8 border-t flex justify-end space-x-4">
            <Button
              type="button"
              variant="secondary"
              onClick={handleClose}
              disabled={loading}
            >
              Annuler
            </Button>
            <Button
              type="submit"
              variant="primary"
              loading={loading}
              disabled={!hasChanges}
            >
              Enregistrer
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditSponsorModal;