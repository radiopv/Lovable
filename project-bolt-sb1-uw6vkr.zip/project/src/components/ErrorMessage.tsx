import React from 'react';
import { AlertTriangle } from 'lucide-react';
import Button from './Button';

interface ErrorMessageProps {
  message: string;
  onRetry?: () => void;
  className?: string;
}

const ErrorMessage: React.FC<ErrorMessageProps> = ({ 
  message, 
  onRetry,
  className = ''
}) => {
  return (
    <div className={`flex flex-col items-center justify-center p-4 ${className}`}>
      <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-lg max-w-lg w-full">
        <div className="flex items-start">
          <AlertTriangle className="h-6 w-6 text-red-500 mr-3 flex-shrink-0" />
          <p className="text-red-700">{message}</p>
        </div>
        {onRetry && (
          <Button
            onClick={onRetry}
            variant="secondary"
            className="mt-4 mx-auto"
          >
            Réessayer
          </Button>
        )}
      </div>
    </div>
  );
};

export default ErrorMessage;