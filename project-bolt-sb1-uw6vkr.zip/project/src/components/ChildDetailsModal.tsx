import React from 'react';
import { X, Edit2, Calendar, MapPin, User, Heart } from 'lucide-react';
import type { Child } from '../types';
import Button from './Button';

interface ChildDetailsModalProps {
  child: Child;
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

const ChildDetailsModal: React.FC<ChildDetailsModalProps> = ({
  child,
  onClose,
  onEdit,
  onDelete
}) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="relative h-64">
          <img
            src={child.image_url}
            alt={child.name}
            className="w-full h-full object-cover"
          />
          <Button
            variant="secondary"
            size="sm"
            icon={X}
            onClick={onClose}
            className="absolute top-4 right-4"
          />
          {child.is_sponsored && (
            <div className="absolute top-4 left-4 bg-green-500 text-white px-4 py-2 rounded-full">
              Parrainé
            </div>
          )}
        </div>

        <div className="p-6">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h2 className="text-2xl font-bold mb-2">{child.name}</h2>
              <div className="space-y-2">
                <div className="flex items-center text-gray-600">
                  <Calendar className="w-5 h-5 mr-2" />
                  <span>
                    {child.age} ans
                    {child.birthday && (
                      <span className="ml-1">
                        (né{child.gender === 'female' ? 'e' : ''} le {new Date(child.birthday).toLocaleDateString()})
                      </span>
                    )}
                  </span>
                </div>
                <div className="flex items-center text-gray-600">
                  <MapPin className="w-5 h-5 mr-2" />
                  <span>{child.city}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <User className="w-5 h-5 mr-2" />
                  <span>{child.gender === 'male' ? 'Garçon' : 'Fille'}</span>
                </div>
                {child.sponsor && (
                  <div className="flex items-center text-green-600">
                    <Heart className="w-5 h-5 mr-2" />
                    <span>
                      Parrainé par {child.sponsor.is_anonymous ? 'un parrain anonyme' : child.sponsor.name}
                    </span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                variant="secondary"
                size="sm"
                icon={Edit2}
                onClick={onEdit}
              >
                Modifier
              </Button>
              <Button
                variant="danger"
                size="sm"
                onClick={onDelete}
              >
                Supprimer
              </Button>
            </div>
          </div>

          {child.private_notes && (
            <div>
              <h3 className="text-lg font-semibold mb-2">Notes privées</h3>
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                <p className="text-yellow-800 whitespace-pre-line">{child.private_notes}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChildDetailsModal;