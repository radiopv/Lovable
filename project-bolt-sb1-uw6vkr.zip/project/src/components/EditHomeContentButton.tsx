import React, { useState } from 'react';
import { Edit } from 'lucide-react';
import EditHomeContentModal from './EditHomeContentModal';

interface EditHomeContentButtonProps {
  section: string;
  title: string;
  content: string;
  imageUrl?: string;
  onUpdate: () => void;
}

const EditHomeContentButton: React.FC<EditHomeContentButtonProps> = ({
  section,
  title,
  content,
  imageUrl,
  onUpdate
}) => {
  const [showModal, setShowModal] = useState(false);

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        className="absolute top-2 right-2 p-2 bg-white rounded-full shadow-md hover:bg-gray-50 z-10"
        title="Modifier cette section"
      >
        <Edit className="w-4 h-4 text-gray-600" />
      </button>

      {showModal && (
        <EditHomeContentModal
          section={section}
          onClose={() => setShowModal(false)}
          onSuccess={() => {
            setShowModal(false);
            onUpdate();
          }}
        />
      )}
    </>
  );
};

export default EditHomeContentButton;