import React, { useState, useEffect } from 'react';
import { X, Search, Save, RefreshCw, Globe } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import Button from './Button';
import LoadingSpinner from './LoadingSpinner';
import ErrorMessage from './ErrorMessage';

interface TranslationManagerProps {
  onClose: () => void;
  onSuccess: () => void;
}

interface Translation {
  key: string;
  fr: string;
  en: string;
  es: string;
}

const TranslationManager: React.FC<TranslationManagerProps> = ({
  onClose,
  onSuccess
}) => {
  const { t, i18n } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [translations, setTranslations] = useState<Record<string, Translation>>({});
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('fr');
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    loadTranslations();
  }, []);

  const loadTranslations = async () => {
    try {
      const { data, error } = await supabase
        .from('translations')
        .select('*')
        .order('key');

      if (error) throw error;

      const translationsMap: Record<string, Translation> = {};
      data?.forEach(item => {
        translationsMap[item.key] = {
          key: item.key,
          fr: item.fr,
          en: item.en,
          es: item.es
        };
      });

      setTranslations(translationsMap);
    } catch (err) {
      console.error('Error loading translations:', err);
      setError('Erreur lors du chargement des traductions');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setLoading(true);

      // Update translations in database
      const { error } = await supabase
        .from('translations')
        .upsert(Object.values(translations));

      if (error) throw error;

      // Update translations in i18n
      Object.values(translations).forEach(translation => {
        i18n.addResource('fr', translation.key, translation.fr);
        i18n.addResource('en', translation.key, translation.en);
        i18n.addResource('es', translation.key, translation.es);
      });

      setHasChanges(false);
      toast.success('Traductions mises à jour avec succès');
      onSuccess();
    } catch (err) {
      console.error('Error saving translations:', err);
      toast.error('Erreur lors de la sauvegarde des traductions');
    } finally {
      setLoading(false);
    }
  };

  const handleTranslationChange = (key: string, lang: keyof Translation, value: string) => {
    setTranslations(prev => ({
      ...prev,
      [key]: {
        ...prev[key],
        [lang]: value
      }
    }));
    setHasChanges(true);
  };

  const filteredTranslations = Object.values(translations).filter(translation =>
    translation.key.toLowerCase().includes(searchTerm.toLowerCase()) ||
    translation[selectedLanguage as keyof Translation].toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-2xl font-bold">Gestionnaire de traductions</h2>
          <Button
            variant="secondary"
            size="sm"
            icon={X}
            onClick={onClose}
          />
        </div>

        <div className="p-4 border-b bg-gray-50 flex items-center gap-4">
          <select
            className="px-4 py-2 border rounded-lg"
            value={selectedLanguage}
            onChange={(e) => setSelectedLanguage(e.target.value)}
          >
            <option value="fr">Français</option>
            <option value="en">English</option>
            <option value="es">Español</option>
          </select>

          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Rechercher une traduction..."
              className="w-full pl-10 pr-4 py-2 border rounded-lg"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <Button
            onClick={loadTranslations}
            variant="secondary"
            size="sm"
            icon={RefreshCw}
            disabled={loading}
          >
            Actualiser
          </Button>

          <Button
            onClick={handleSave}
            variant="primary"
            size="sm"
            icon={Save}
            disabled={loading || !hasChanges}
          >
            Enregistrer
          </Button>
        </div>

        <div className="flex-1 overflow-auto p-4">
          <div className="space-y-4">
            {filteredTranslations.map((translation) => (
              <div key={translation.key} className="bg-white rounded-lg shadow p-4">
                <div className="font-mono text-sm text-gray-500 mb-2">{translation.key}</div>
                <textarea
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                  value={translation[selectedLanguage as keyof Translation]}
                  onChange={(e) => handleTranslationChange(translation.key, selectedLanguage as keyof Translation, e.target.value)}
                  rows={2}
                  placeholder={`Entrez la traduction en ${
                    selectedLanguage === 'fr' ? 'français' :
                    selectedLanguage === 'en' ? 'anglais' : 'espagnol'
                  }`}
                />
              </div>
            ))}

            {filteredTranslations.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                Aucune traduction trouvée
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TranslationManager;