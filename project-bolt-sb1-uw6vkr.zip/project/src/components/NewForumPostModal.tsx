import React, { useState } from 'react';
import { X } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import ErrorMessage from './ErrorMessage';

interface NewForumPostModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

const NewForumPostModal: React.FC<NewForumPostModalProps> = ({
  onClose,
  onSuccess
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isUrgent, setIsUrgent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const sponsorData = localStorage.getItem('sponsor');
      if (!sponsorData) {
        throw new Error('Vous devez être connecté pour créer une discussion');
      }

      const sponsor = JSON.parse(sponsorData);
      const { error: postError } = await supabase
        .from('forum_posts')
        .insert({
          sponsor_id: sponsor.id,
          title: title.trim(),
          content: content.trim(),
          is_urgent: isUrgent
        });

      if (postError) throw postError;

      toast.success('Discussion créée avec succès');
      onSuccess();
    } catch (err) {
      console.error('Erreur:', err);
      setError(err instanceof Error ? err.message : 'Erreur lors de la création de la discussion');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
          disabled={loading}
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-bold mb-4">
          Nouvelle Discussion
        </h2>

        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Titre
            </label>
            <input
              type="text"
              required
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Contenu
            </label>
            <textarea
              required
              rows={6}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              disabled={loading}
            />
          </div>

          <div className="flex items-center">
            <input
              type="checkbox"
              id="is_urgent"
              checked={isUrgent}
              onChange={(e) => setIsUrgent(e.target.checked)}
              className="rounded border-gray-300 text-red-600 focus:ring-red-500"
              disabled={loading}
            />
            <label htmlFor="is_urgent" className="ml-2 text-sm text-gray-700">
              Marquer comme urgent
            </label>
          </div>

          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border rounded-lg hover:bg-gray-50"
              disabled={loading}
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 flex items-center justify-center"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Création en cours...
                </>
              ) : (
                'Créer la discussion'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewForumPostModal;