// Previous imports remain the same...

const MemoryGallery: React.FC<MemoryGalleryProps> = ({
  memories,
  isOwner = false,
  onDelete,
  onShare
}) => {
  // Previous state remains the same...

  const handleShare = async (memory: Memory) => {
    const shareData = {
      title: `Souvenir de ${memory.child?.name || 'notre filleul'}`,
      text: memory.description || 'Un moment spécial à partager',
      url: window.location.href
    };

    try {
      if (onShare) {
        onShare(memory.id);
      } else if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
      } else {
        // Fallback: copy to clipboard
        await navigator.clipboard.writeText(window.location.href);
        toast.success('Lien copié dans le presse-papiers');
      }
    } catch (err) {
      // Ignore user cancellation
      if (err instanceof Error && err.name !== 'AbortError') {
        console.error('Error sharing:', err);
        // Fallback: copy to clipboard
        try {
          await navigator.clipboard.writeText(window.location.href);
          toast.success('Lien copié dans le presse-papiers');
        } catch (clipboardErr) {
          console.error('Clipboard error:', clipboardErr);
          toast.error('Impossible de partager ou copier le lien');
        }
      }
    }
  };

  // Rest of the component remains the same...
};

export default MemoryGallery;