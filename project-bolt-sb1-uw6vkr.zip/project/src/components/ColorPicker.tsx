import React from 'react';

interface ColorPickerProps {
  color: string;
  onChange: (color: string) => void;
}

const ColorPicker: React.FC<ColorPickerProps> = ({ color, onChange }) => {
  const [showPicker, setShowPicker] = React.useState(false);

  const presetColors = [
    '#ffffff', '#000000', '#ff0000', '#00ff00', '#0000ff',
    '#ffff00', '#00ffff', '#ff00ff', '#808080', '#800000',
    '#808000', '#008000', '#800080', '#008080', '#000080'
  ];

  return (
    <div className="relative">
      <div
        className="w-full h-10 rounded-lg border cursor-pointer flex items-center px-3"
        style={{ backgroundColor: color }}
        onClick={() => setShowPicker(!showPicker)}
      >
        <span className="text-sm" style={{ color: getContrastColor(color) }}>
          {color}
        </span>
      </div>
      
      {showPicker && (
        <>
          <div
            className="fixed inset-0"
            onClick={() => setShowPicker(false)}
          />
          <div className="absolute z-10 mt-2 p-4 bg-white rounded-lg shadow-lg border">
            <input
              type="color"
              value={color}
              onChange={(e) => onChange(e.target.value)}
              className="w-full h-10 mb-4"
            />
            <div className="grid grid-cols-5 gap-2">
              {presetColors.map((presetColor) => (
                <button
                  key={presetColor}
                  className="w-6 h-6 rounded-full border"
                  style={{ backgroundColor: presetColor }}
                  onClick={() => {
                    onChange(presetColor);
                    setShowPicker(false);
                  }}
                />
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

// Helper function to determine text color based on background
function getContrastColor(hexcolor: string): string {
  // Convert hex to RGB
  const r = parseInt(hexcolor.slice(1, 3), 16);
  const g = parseInt(hexcolor.slice(3, 5), 16);
  const b = parseInt(hexcolor.slice(5, 7), 16);
  
  // Calculate relative luminance
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  
  return luminance > 0.5 ? '#000000' : '#ffffff';
}

export default ColorPicker;