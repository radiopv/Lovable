import React from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { isSponsorAuthenticated } from '../lib/auth';

const SponsorRoute: React.FC = () => {
  const location = useLocation();
  const isAuthenticated = isSponsorAuthenticated();

  if (!isAuthenticated) {
    return <Navigate to="/parrain/connexion" state={{ from: location }} replace />;
  }

  return <Outlet />;
};

export default SponsorRoute;