import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Globe } from 'lucide-react';
import Button from './Button';

interface Language {
  code: string;
  name: string;
  flag: string;
  nativeName: string;
}

const LANGUAGES: Language[] = [
  { code: 'fr', name: 'French', nativeName: 'Français', flag: '🇫🇷' },
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸' }
];

const LanguageSelector: React.FC = () => {
  const { t, i18n } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState<Language>(
    LANGUAGES.find(lang => lang.code === i18n.language) || LANGUAGES[0]
  );

  useEffect(() => {
    const lang = LANGUAGES.find(l => l.code === i18n.language);
    if (lang) {
      setCurrentLanguage(lang);
    }
  }, [i18n.language]);

  const handleLanguageChange = async (language: Language) => {
    try {
      await i18n.changeLanguage(language.code);
      setCurrentLanguage(language);
      document.documentElement.lang = language.code;
      localStorage.setItem('i18nextLng', language.code);
      setIsOpen(false);
    } catch (error) {
      console.error('Error changing language:', error);
    }
  };

  return (
    <div className="relative">
      <Button
        variant="secondary"
        size="sm"
        icon={Globe}
        onClick={() => setIsOpen(!isOpen)}
        className="min-w-[120px]"
      >
        <span className="flex items-center">
          {currentLanguage.flag} {currentLanguage.nativeName}
        </span>
      </Button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg z-50 py-2">
          {LANGUAGES.map(language => (
            <button
              key={language.code}
              onClick={() => handleLanguageChange(language)}
              className={`w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center space-x-2 ${
                currentLanguage.code === language.code ? 'text-red-600 font-semibold bg-red-50' : 'text-gray-700'
              }`}
            >
              <span>{language.flag}</span>
              <span>{language.nativeName}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default LanguageSelector;