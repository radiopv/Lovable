import React from 'react';
import type { Child } from '../types';
import Button from './Button';

interface ChildCardProps {
  child: Child;
  showSponsorInfo?: boolean;
  onEdit?: () => void;
  onDelete?: () => void;
  onView?: () => void;
}

const ChildCard: React.FC<ChildCardProps> = ({
  child,
  showSponsorInfo = false,
  onEdit,
  onDelete,
  onView
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="relative h-48">
        <img
          src={child.image_url || 'https://via.placeholder.com/300x200?text=Photo+non+disponible'}
          alt={child.name}
          className="w-full h-full object-cover"
        />
        {child.is_sponsored && (
          <div className="absolute top-2 right-2 bg-green-500 text-white px-3 py-1 rounded-full text-sm">
            Parrainé
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold mb-2">{child.name}</h3>
        <div className="space-y-2 text-sm text-gray-600">
          <p>{child.age} ans - {child.gender === 'female' ? 'Fille' : 'Garçon'}</p>
          <p>{child.city}</p>
          {child.situation && (
            <p className="text-sm italic">{child.situation}</p>
          )}
          {showSponsorInfo && child.sponsor && (
            <p className="text-green-600">
              Parrainé par {child.sponsor.is_anonymous ? 'un parrain anonyme' : child.sponsor.name}
            </p>
          )}
        </div>

        <div className="mt-4 flex gap-2">
          {!child.is_sponsored && (
            <Button
              to={`/enfants/${child.id}`}
              variant="primary"
              fullWidth
            >
              Parrainer {child.name}
            </Button>
          )}
          {onView && (
            <Button
              variant="secondary"
              size="sm"
              onClick={onView}
            >
              Voir
            </Button>
          )}
          {onEdit && (
            <Button
              variant="secondary"
              size="sm"
              onClick={onEdit}
            >
              Modifier
            </Button>
          )}
          {onDelete && (
            <Button
              variant="danger"
              size="sm"
              onClick={onDelete}
            >
              Supprimer
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChildCard;