import React, { useState, useEffect } from 'react';
import { X, Calendar, User, Edit, Plus, Trash2, Heart, Image } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import Button from './Button';
import LoadingSpinner from './LoadingSpinner';
import ErrorMessage from './ErrorMessage';

interface Activity {
  id: string;
  type: string;
  user_id: string;
  user_name: string;
  action: string;
  details: any;
  is_read: boolean;
  created_at: string;
}

const ActivityDashboardModal: React.FC<{
  onClose: () => void;
  onMarkAsRead: () => void;
}> = ({ onClose, onMarkAsRead }) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activities, setActivities] = useState<Activity[]>([]);

  useEffect(() => {
    fetchActivities();
  }, []);

  const fetchActivities = async () => {
    try {
      const { data, error } = await supabase
        .from('activity_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      setActivities(data || []);

      // Mark all as read
      const { error: updateError } = await supabase
        .from('activity_logs')
        .update({ is_read: true })
        .eq('is_read', false);

      if (!updateError) {
        onMarkAsRead();
      }
    } catch (err) {
      console.error('Error:', err);
      setError(t('admin.dashboard.activity.errors.loading'));
    } finally {
      setLoading(false);
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'child_added':
        return Plus;
      case 'child_updated':
        return Edit;
      case 'child_deleted':
        return Trash2;
      case 'memory_added':
        return Image;
      case 'testimonial_added':
        return Heart;
      default:
        return Calendar;
    }
  };

  const formatActivityMessage = (activity: Activity) => {
    const { type, user_name, details } = activity;
    
    switch (type) {
      case 'child_added':
        return t('admin.dashboard.activity.child_added', {
          user: user_name,
          child: details.child_name
        });
      case 'child_updated':
        return t('admin.dashboard.activity.child_updated', {
          user: user_name,
          child: details.child_name,
          changes: Object.keys(details.changes).join(', ')
        });
      case 'memory_added':
        return t('admin.dashboard.activity.memory_added', {
          user: user_name,
          child: details.child_name
        });
      case 'testimonial_added':
        return t('admin.dashboard.activity.testimonial_added', {
          user: user_name,
          child: details.child_name
        });
      default:
        return activity.action;
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-2xl font-bold">{t('admin.dashboard.activity.title')}</h2>
          <Button
            variant="secondary"
            size="sm"
            icon={X}
            onClick={onClose}
          />
        </div>

        <div className="flex-1 overflow-auto p-4">
          <div className="space-y-4">
            {activities.map((activity) => {
              const Icon = getActivityIcon(activity.type);
              return (
                <div
                  key={activity.id}
                  className={`bg-white border rounded-lg p-4 ${
                    !activity.is_read ? 'border-red-200 bg-red-50' : ''
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      <Icon className="w-5 h-5 text-gray-500" />
                    </div>
                    <div className="flex-1">
                      <p className="text-gray-900">
                        {formatActivityMessage(activity)}
                      </p>
                      <p className="text-sm text-gray-500 mt-1">
                        {new Date(activity.created_at).toLocaleString()}
                      </p>
                      <p className="text-sm text-gray-600 mt-1">
                        {t('admin.dashboard.activity.by', { user: activity.user_name })}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ActivityDashboardModal;