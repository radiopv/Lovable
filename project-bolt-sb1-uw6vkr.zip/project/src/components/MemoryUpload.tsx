<diff>@@ -82,1 +82,1 @@
-        .from('memories')
+        .from('media')
@@ -92,1 +92,1 @@
-        .from('memories')
+        .from('media')
@@ -112,1 +112,1 @@
-          .from('memories')
+          .from('media')</diff>