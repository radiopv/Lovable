import React from 'react';
import Button from './Button';
import { Bold, Italic, List, ListOrdered } from 'lucide-react';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  readOnly?: boolean;
}

const RichTextEditor: React.FC<RichTextEditorProps> = ({
  value,
  onChange,
  readOnly = false
}) => {
  const handleBold = () => {
    const textarea = document.querySelector('textarea');
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    
    const before = text.substring(0, start);
    const selected = text.substring(start, end);
    const after = text.substring(end);
    
    onChange(`${before}**${selected}**${after}`);
  };

  const handleItalic = () => {
    const textarea = document.querySelector('textarea');
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    
    const before = text.substring(0, start);
    const selected = text.substring(start, end);
    const after = text.substring(end);
    
    onChange(`${before}_${selected}_${after}`);
  };

  if (readOnly) {
    return (
      <div 
        className="prose max-w-none"
        dangerouslySetInnerHTML={{ __html: value }}
      />
    );
  }

  return (
    <div className="border rounded-lg overflow-hidden">
      <div className="bg-gray-50 border-b p-2 flex flex-wrap gap-2">
        <Button
          variant="secondary"
          size="sm"
          icon={Bold}
          onClick={handleBold}
        />
        <Button
          variant="secondary"
          size="sm"
          icon={Italic}
          onClick={handleItalic}
        />
        <Button
          variant="secondary"
          size="sm"
          icon={List}
          onClick={() => onChange(value + '\n- ')}
        />
        <Button
          variant="secondary"
          size="sm"
          icon={ListOrdered}
          onClick={() => onChange(value + '\n1. ')}
        />
      </div>

      <div className="p-4">
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full min-h-[200px] focus:outline-none resize-y"
          placeholder="Start writing..."
        />
      </div>
    </div>
  );
};

export default RichTextEditor;