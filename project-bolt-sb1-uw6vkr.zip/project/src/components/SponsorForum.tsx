import React, { useState, useEffect } from 'react';
import { Plus, MessageCircle, AlertTriangle, Plane, Package } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import LoadingSpinner from './LoadingSpinner';
import ErrorMessage from './ErrorMessage';
import NewForumPostModal from './NewForumPostModal';
import NewTravelAnnouncementModal from './NewTravelAnnouncementModal';
import Button from './Button';

interface ForumPost {
  id: string;
  title: string;
  content: string;
  category: string;
  is_urgent: boolean;
  created_at: string;
  sponsor: {
    name: string;
    is_anonymous: boolean;
  };
  replies: {
    id: string;
    content: string;
    created_at: string;
    sponsor: {
      name: string;
      is_anonymous: boolean;
    };
  }[];
}

interface TravelAnnouncement {
  id: string;
  departure_date: string;
  return_date: string;
  destination: string;
  available_space: string;
  notes?: string;
  sponsor: {
    name: string;
    is_anonymous: boolean;
  };
  transport_requests: {
    id: string;
    sponsor: {
      name: string;
    };
    child: {
      name: string;
    };
    items: string;
    status: string;
  }[];
}

const CATEGORIES = {
  vetement: 'Vêtements',
  nourriture: 'Nourriture',
  medicament: 'Médicaments',
  jouet: 'Jouets',
  education: 'Éducation',
  voyage: 'Voyages à Cuba',
  autre: 'Autres'
};

const SponsorForum: React.FC = () => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [posts, setPosts] = useState<ForumPost[]>([]);
  const [travels, setTravels] = useState<TravelAnnouncement[]>([]);
  const [showNewPostModal, setShowNewPostModal] = useState(false);
  const [showNewTravelModal, setShowNewTravelModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch forum posts
      const { data: postsData, error: postsError } = await supabase
        .from('forum_posts')
        .select(`
          *,
          sponsor:sponsors(name, is_anonymous),
          replies:forum_replies(
            id,
            content,
            created_at,
            sponsor:sponsors(name, is_anonymous)
          )
        `)
        .order('created_at', { ascending: false });

      if (postsError) throw postsError;
      setPosts(postsData || []);

      // Fetch travel announcements
      const { data: travelsData, error: travelsError } = await supabase
        .from('travel_announcements')
        .select(`
          *,
          sponsor:sponsors(name, is_anonymous),
          transport_requests(
            id,
            sponsor:sponsors(name),
            child:children(name),
            items,
            status
          )
        `)
        .eq('is_active', true)
        .order('departure_date', { ascending: true });

      if (travelsError) throw travelsError;
      setTravels(travelsData || []);
    } catch (err) {
      console.error('Error:', err);
      setError(t('errors.loading'));
    } finally {
      setLoading(false);
    }
  };

  const handleRequestTransport = async (travelId: string) => {
    const sponsorData = localStorage.getItem('sponsor');
    if (!sponsorData) {
      toast.error(t('errors.auth_required'));
      return;
    }

    const items = prompt(t('forum.transport.items_prompt'));
    if (!items) return;

    try {
      const sponsor = JSON.parse(sponsorData);
      const { error } = await supabase
        .from('transport_requests')
        .insert({
          travel_id: travelId,
          sponsor_id: sponsor.id,
          items
        });

      if (error) throw error;

      toast.success(t('forum.transport.request_success'));
      fetchData();
    } catch (err) {
      console.error('Error:', err);
      toast.error(t('forum.transport.request_error'));
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  const filteredPosts = selectedCategory
    ? posts.filter(post => post.category === selectedCategory)
    : posts;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{t('forum.title')}</h1>
        <div className="flex gap-4">
          <Button
            onClick={() => setShowNewTravelModal(true)}
            variant="secondary"
            icon={Plane}
          >
            {t('forum.buttons.new_travel')}
          </Button>
          <Button
            onClick={() => setShowNewPostModal(true)}
            variant="primary"
            icon={Plus}
          >
            {t('forum.buttons.new_post')}
          </Button>
        </div>
      </div>

      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        <Button
          onClick={() => setSelectedCategory(null)}
          variant={selectedCategory === null ? "primary" : "secondary"}
        >
          {t('forum.categories.all')}
        </Button>
        {Object.entries(CATEGORIES).map(([key, label]) => (
          <Button
            key={key}
            onClick={() => setSelectedCategory(key)}
            variant={selectedCategory === key ? "primary" : "secondary"}
          >
            {label}
          </Button>
        ))}
      </div>

      {selectedCategory === 'voyage' && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">{t('forum.upcoming_travels')}</h2>
          <div className="space-y-4">
            {travels.map((travel) => (
              <div key={travel.id} className="bg-white rounded-lg shadow-md p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-semibold">
                      {t('forum.travel.destination', { destination: travel.destination })}
                    </h3>
                    <p className="text-gray-600">
                      {t('forum.travel.dates', {
                        start: new Date(travel.departure_date).toLocaleDateString(),
                        end: new Date(travel.return_date).toLocaleDateString()
                      })}
                    </p>
                    <p className="text-gray-600">
                      {t('forum.travel.by', {
                        name: travel.sponsor.is_anonymous ? t('common.anonymous_sponsor') : travel.sponsor.name
                      })}
                    </p>
                    <p className="mt-2">
                      <strong>{t('forum.travel.space')}:</strong> {travel.available_space}
                    </p>
                    {travel.notes && (
                      <p className="mt-2 text-gray-700">{travel.notes}</p>
                    )}
                  </div>
                  <Button
                    onClick={() => handleRequestTransport(travel.id)}
                    variant="secondary"
                    icon={Package}
                  >
                    {t('forum.travel.request_transport')}
                  </Button>
                </div>

                {travel.transport_requests.length > 0 && (
                  <div className="mt-4 border-t pt-4">
                    <h4 className="font-semibold mb-2">{t('forum.travel.requests')}:</h4>
                    <ul className="space-y-2">
                      {travel.transport_requests.map((request) => (
                        <li key={request.id} className="text-sm text-gray-600">
                          {t('forum.travel.request_details', {
                            sponsor: request.sponsor.name,
                            child: request.child.name,
                            items: request.items
                          })}
                          <span className="ml-2 px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">
                            {request.status}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-6">
        {filteredPosts.map((post) => (
          <div key={post.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-700">
                      {CATEGORIES[post.category as keyof typeof CATEGORIES]}
                    </span>
                    {post.is_urgent && (
                      <span className="px-3 py-1 rounded-full text-sm bg-red-100 text-red-700">
                        {t('forum.urgent')}
                      </span>
                    )}
                  </div>
                  <h2 className="text-xl font-semibold">{post.title}</h2>
                  <p className="text-gray-500 text-sm mt-1">
                    {t('forum.post.by', {
                      name: post.sponsor.is_anonymous ? t('common.anonymous_sponsor') : post.sponsor.name,
                      date: new Date(post.created_at).toLocaleDateString('fr-FR', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric'
                      })
                    })}
                  </p>
                </div>
              </div>

              <div className="mt-4 text-gray-700">{post.content}</div>

              {post.replies.length > 0 && (
                <div className="mt-4 space-y-4">
                  {post.replies.map((reply) => (
                    <div key={reply.id} className="bg-gray-50 rounded-lg p-4">
                      <p className="text-sm text-gray-500 mb-2">
                        {t('forum.reply.by', {
                          name: reply.sponsor.is_anonymous ? t('common.anonymous_sponsor') : reply.sponsor.name,
                          date: new Date(reply.created_at).toLocaleDateString()
                        })}
                      </p>
                      <p className="text-gray-700">{reply.content}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {showNewPostModal && (
        <NewForumPostModal
          onClose={() => setShowNewPostModal(false)}
          onSuccess={() => {
            setShowNewPostModal(false);
            fetchData();
          }}
        />
      )}

      {showNewTravelModal && (
        <NewTravelAnnouncementModal
          onClose={() => setShowNewTravelModal(false)}
          onSuccess={() => {
            setShowNewTravelModal(false);
            fetchData();
          }}
        />
      )}
    </div>
  );
};

export default SponsorForum;