import React, { useState } from 'react';
import { ZoomIn, ZoomOut } from 'lucide-react';
import Button from './Button';

interface ImageContainerProps {
  src: string;
  alt: string;
  className?: string;
  preserveAspectRatio?: boolean;
  allowZoom?: boolean;
}

const ImageContainer: React.FC<ImageContainerProps> = ({
  src,
  alt,
  className = '',
  preserveAspectRatio = true,
  allowZoom = false
}) => {
  const [isZoomed, setIsZoomed] = useState(false);

  const baseStyles = preserveAspectRatio
    ? 'w-full h-auto object-contain'
    : 'w-full h-full object-cover';

  const containerStyles = `relative overflow-hidden ${className}`;
  const imageStyles = `${baseStyles} ${isZoomed ? 'scale-150 cursor-zoom-out' : 'cursor-zoom-in'}`;

  const handleZoomClick = () => {
    if (allowZoom) {
      setIsZoomed(!isZoomed);
    }
  };

  return (
    <div className={containerStyles}>
      <img
        src={src}
        alt={alt}
        className={imageStyles}
        onClick={allowZoom ? handleZoomClick : undefined}
        style={{ transition: 'transform 0.3s ease-in-out' }}
      />
      {allowZoom && (
        <Button
          variant="secondary"
          size="sm"
          icon={isZoomed ? ZoomOut : ZoomIn}
          onClick={handleZoomClick}
          className="absolute bottom-2 right-2"
        >
          {isZoomed ? 'Réduire' : 'Agrandir'}
        </Button>
      )}
    </div>
  );
};

export default ImageContainer;