import React, { useState } from 'react';
import { X } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import { hashPassword } from '../utils/passwords';
import type { Sponsor } from '../types';
import Button from './Button';
import ErrorMessage from './ErrorMessage';

interface EditSponsorProfileModalProps {
  sponsor: Sponsor;
  onClose: () => void;
  onSuccess: () => void;
}

const EditSponsorProfileModal: React.FC<EditSponsorProfileModalProps> = ({
  sponsor,
  onClose,
  onSuccess
}) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: sponsor.name,
    email: sponsor.email,
    facebook_url: sponsor.facebook_url || '',
    is_anonymous: sponsor.is_anonymous,
    new_password: '',
    confirm_password: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.name.trim() || !formData.email.trim()) {
      setError(t('sponsor.dashboard.profile.errors.required_fields'));
      return;
    }

    if (formData.new_password && formData.new_password !== formData.confirm_password) {
      setError(t('sponsor.dashboard.profile.errors.password_mismatch'));
      return;
    }

    setLoading(true);

    try {
      const updates: any = {
        name: formData.name.trim(),
        email: formData.email.trim(),
        facebook_url: formData.facebook_url.trim() || null,
        is_anonymous: formData.is_anonymous
      };

      if (formData.new_password) {
        updates.password_hash = await hashPassword(formData.new_password);
        updates.is_temp_password = false;
      }

      const { error: updateError } = await supabase
        .from('sponsors')
        .update(updates)
        .eq('id', sponsor.id);

      if (updateError) throw updateError;

      // Update local storage
      const updatedSponsor = { ...sponsor, ...updates };
      localStorage.setItem('sponsor', JSON.stringify(updatedSponsor));

      onSuccess();
    } catch (err) {
      console.error('Error:', err);
      setError(t('sponsor.dashboard.profile.errors.update_failed'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-md w-full p-6 relative">
        <Button
          variant="secondary"
          size="sm"
          icon={X}
          onClick={onClose}
          className="absolute top-4 right-4"
        />

        <h2 className="text-2xl font-bold mb-6">
          {t('sponsor.dashboard.profile.title')}
        </h2>

        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('sponsor.dashboard.profile.name')}
            </label>
            <input
              type="text"
              required
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('sponsor.dashboard.profile.email')}
            </label>
            <input
              type="email"
              required
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={formData.email}
              onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('sponsor.dashboard.profile.facebook_url')}
            </label>
            <input
              type="url"
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={formData.facebook_url}
              onChange={(e) => setFormData(prev => ({ ...prev, facebook_url: e.target.value }))}
              disabled={loading}
              placeholder="https://facebook.com/profile"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('sponsor.dashboard.profile.new_password')}
            </label>
            <input
              type="password"
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
              value={formData.new_password}
              onChange={(e) => setFormData(prev => ({ ...prev, new_password: e.target.value }))}
              disabled={loading}
              minLength={8}
            />
          </div>

          {formData.new_password && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t('sponsor.dashboard.profile.confirm_password')}
              </label>
              <input
                type="password"
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
                value={formData.confirm_password}
                onChange={(e) => setFormData(prev => ({ ...prev, confirm_password: e.target.value }))}
                disabled={loading}
                minLength={8}
              />
            </div>
          )}

          <div className="flex items-center">
            <input
              type="checkbox"
              id="is_anonymous"
              className="rounded border-gray-300 text-red-600 focus:ring-red-500"
              checked={formData.is_anonymous}
              onChange={(e) => setFormData(prev => ({ ...prev, is_anonymous: e.target.checked }))}
              disabled={loading}
            />
            <label htmlFor="is_anonymous" className="ml-2 text-sm text-gray-700">
              {t('sponsor.dashboard.profile.anonymous')}
            </label>
          </div>

          <div className="flex justify-end space-x-4">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
              disabled={loading}
            >
              {t('common.buttons.cancel')}
            </Button>
            <Button
              type="submit"
              variant="primary"
              loading={loading}
            >
              {t('common.buttons.save')}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditSponsorProfileModal;