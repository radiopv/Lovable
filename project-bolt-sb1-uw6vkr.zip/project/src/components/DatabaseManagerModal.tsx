import React, { useState, useEffect } from 'react';
import { X, Save, Trash2, RefreshCw, Search } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import Button from './Button';
import LoadingSpinner from './LoadingSpinner';
import ErrorMessage from './ErrorMessage';

interface DatabaseManagerModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

const TABLES = [
  { name: 'children', label: 'Enfants' },
  { name: 'sponsors', label: 'Parrains' },
  { name: 'memories', label: 'Souvenirs' },
  { name: 'home_content', label: 'Contenu du site' },
  { name: 'sponsorship_archives', label: 'Archives' }
];

const DatabaseManagerModal: React.FC<DatabaseManagerModalProps> = ({
  onClose,
  onSuccess
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedTable, setSelectedTable] = useState('children');
  const [data, setData] = useState<any[]>([]);
  const [editedData, setEditedData] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchTableData(selectedTable);
  }, [selectedTable]);

  const fetchTableData = async (tableName: string) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase
        .from(tableName)
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const tableData = data || [];
      setData(tableData);
      setEditedData(tableData);
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des données');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      const modifiedRecords = editedData.filter((record, index) => {
        const originalRecord = data[index];
        return JSON.stringify(record) !== JSON.stringify(originalRecord);
      });

      if (modifiedRecords.length === 0) {
        toast.info('Aucune modification à enregistrer');
        return;
      }

      for (const record of modifiedRecords) {
        const { error } = await supabase
          .from(selectedTable)
          .update(record)
          .eq('id', record.id);

        if (error) throw error;
      }

      toast.success('Modifications enregistrées avec succès');
      fetchTableData(selectedTable);
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de la sauvegarde');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cet enregistrement ?')) return;

    try {
      const { error } = await supabase
        .from(selectedTable)
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast.success('Enregistrement supprimé avec succès');
      fetchTableData(selectedTable);
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de la suppression');
    }
  };

  const handleDataChange = (id: string, field: string, value: any) => {
    setEditedData(prev => 
      prev.map(record => 
        record.id === id ? { ...record, [field]: value } : record
      )
    );
  };

  const filteredData = editedData.filter(record => {
    const searchString = searchTerm.toLowerCase();
    return Object.values(record).some(value => 
      value && value.toString().toLowerCase().includes(searchString)
    );
  });

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-2xl font-bold">Gestion de la base de données</h2>
          <Button
            variant="secondary"
            size="sm"
            icon={X}
            onClick={onClose}
          />
        </div>

        <div className="p-4 border-b bg-gray-50 flex items-center gap-4">
          <select
            className="px-4 py-2 border rounded-lg"
            value={selectedTable}
            onChange={(e) => setSelectedTable(e.target.value)}
          >
            {TABLES.map(table => (
              <option key={table.name} value={table.name}>
                {table.label}
              </option>
            ))}
          </select>

          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Rechercher dans les données..."
              className="w-full pl-10 pr-4 py-2 border rounded-lg"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <Button
            onClick={() => fetchTableData(selectedTable)}
            variant="secondary"
            size="sm"
            icon={RefreshCw}
          >
            Actualiser
          </Button>

          <Button
            onClick={handleSave}
            variant="primary"
            size="sm"
            icon={Save}
          >
            Enregistrer
          </Button>
        </div>

        <div className="flex-1 overflow-auto p-4">
          {filteredData.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              Aucune donnée disponible dans cette table
            </div>
          ) : (
            <div className="space-y-4">
              {filteredData.map((record) => (
                <div key={record.id} className="bg-white border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-4">
                    <div className="text-sm text-gray-500">ID: {record.id}</div>
                    <Button
                      onClick={() => handleDelete(record.id)}
                      variant="secondary"
                      size="sm"
                      icon={Trash2}
                      className="text-red-600"
                    >
                      Supprimer
                    </Button>
                  </div>
                  {Object.entries(record).map(([key, value]) => {
                    if (key === 'id') return null;
                    return (
                      <div key={key} className="mb-4">
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          {key}
                        </label>
                        {typeof value === 'string' ? (
                          <input
                            type="text"
                            className="w-full px-3 py-2 border rounded-lg"
                            value={value}
                            onChange={(e) => handleDataChange(record.id, key, e.target.value)}
                          />
                        ) : (
                          <textarea
                            className="w-full px-3 py-2 border rounded-lg"
                            value={JSON.stringify(value, null, 2)}
                            onChange={(e) => {
                              try {
                                const parsed = JSON.parse(e.target.value);
                                handleDataChange(record.id, key, parsed);
                              } catch (err) {
                                // Invalid JSON, ignore
                              }
                            }}
                          />
                        )}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DatabaseManagerModal;