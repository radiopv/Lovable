import React, { useState, useEffect } from 'react';
import { Users, Heart, MapPin } from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '../lib/supabase';

interface Statistics {
  total_children: number;
  sponsored_children: number;
  active_sponsors: number;
  regions: string[];
}

const StatisticsSection: React.FC = () => {
  const [stats, setStats] = useState<Statistics>({
    total_children: 0,
    sponsored_children: 0,
    active_sponsors: 0,
    regions: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStatistics();
  }, []);

  const fetchStatistics = async () => {
    try {
      const { data, error } = await supabase
        .from('statistics')
        .select('*')
        .single();

      if (error) throw error;
      if (data) {
        setStats(data);
      }
    } catch (error) {
      console.error('Error fetching statistics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return null;

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">
          Notre Impact
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <StatCard
            icon={Heart}
            title="Enfants Parrainés"
            value={stats.sponsored_children}
            description="Enfants dont la vie a été transformée grâce à nos parrains"
            delay={0}
          />
          <StatCard
            icon={Users}
            title="Parrains Actifs"
            value={stats.active_sponsors}
            description="Personnes engagées dans notre communauté de parrainage"
            delay={0.2}
          />
          <StatCard
            icon={MapPin}
            title="Régions Touchées"
            value={stats.regions.length}
            description="Zones où nous avons un impact direct à Cuba"
            delay={0.4}
          />
        </div>
      </div>
    </section>
  );
};

interface StatCardProps {
  icon: React.FC<any>;
  title: string;
  value: number;
  description: string;
  delay: number;
}

const StatCard: React.FC<StatCardProps> = ({
  icon: Icon,
  title,
  value,
  description,
  delay
}) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay }}
    className="text-center"
  >
    <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
      <Icon className="w-8 h-8 text-red-600" />
    </div>
    <h3 className="text-xl font-semibold mb-2">{title}</h3>
    <p className="text-3xl font-bold text-red-600 mb-2">{value}</p>
    <p className="text-gray-600">{description}</p>
  </motion.div>
);

export default StatisticsSection;