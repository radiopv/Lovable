import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, Heart, Settings, Upload } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import type { Child, Memory } from '../types';
import AddMemoryModal from './AddMemoryModal';
import AddTestimonialModal from './AddTestimonialModal';
import CancelSponsorshipModal from './CancelSponsorshipModal';
import EditSponsorProfileModal from './EditSponsorProfileModal';
import ErrorMessage from './ErrorMessage';
import LoadingSpinner from './LoadingSpinner';
import Button from './Button';

const SponsorDashboard: React.FC = () => {
  const [children, setChildren] = useState<Child[]>([]);
  const [memories, setMemories] = useState<Memory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedChild, setSelectedChild] = useState<Child | null>(null);
  const [showAddMemoryModal, setShowAddMemoryModal] = useState(false);
  const [showAddTestimonialModal, setShowAddTestimonialModal] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const { t } = useTranslation();
  const navigate = useNavigate();

  useEffect(() => {
    const sponsorData = localStorage.getItem('sponsor');
    if (!sponsorData) {
      navigate('/parrain/connexion');
      return;
    }
    const sponsor = JSON.parse(sponsorData);
    fetchSponsoredChildren(sponsor.id);
  }, [navigate]);

  const fetchSponsoredChildren = async (sponsorId: string) => {
    try {
      const { data: sponsoredChildren, error: childrenError } = await supabase
        .from('children')
        .select('*')
        .eq('sponsor_id', sponsorId);

      if (childrenError) throw childrenError;
      setChildren(sponsoredChildren || []);

      if (sponsoredChildren?.length > 0) {
        const { data: childMemories, error: memoriesError } = await supabase
          .from('memories')
          .select('*')
          .eq('sponsor_id', sponsorId)
          .order('created_at', { ascending: false });

        if (memoriesError) throw memoriesError;
        setMemories(childMemories || []);
      }
    } catch (err) {
      console.error('Error:', err);
      setError(t('errors.loading'));
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('sponsor');
    navigate('/parrain/connexion');
  };

  const handleCancelSponsorship = (child: Child) => {
    setSelectedChild(child);
    setShowCancelModal(true);
  };

  const handleSponsorshipCancelled = () => {
    setShowCancelModal(false);
    const sponsorData = localStorage.getItem('sponsor');
    if (sponsorData) {
      const sponsor = JSON.parse(sponsorData);
      fetchSponsoredChildren(sponsor.id);
    }
  };

  const deleteMemory = async (memoryId: string) => {
    if (!confirm(t('sponsor.dashboard.memories.delete_confirm'))) return;

    try {
      const { error } = await supabase
        .from('memories')
        .delete()
        .eq('id', memoryId);

      if (error) throw error;

      toast.success(t('sponsor.dashboard.memories.delete_success'));
      setMemories(memories.filter(m => m.id !== memoryId));
    } catch (err) {
      console.error('Error:', err);
      toast.error(t('sponsor.dashboard.memories.delete_error'));
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  const sponsorData = JSON.parse(localStorage.getItem('sponsor') || '{}');

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{t('sponsor.dashboard.title')}</h1>
        <div className="flex items-center space-x-4">
          <Button
            variant="secondary"
            icon={Settings}
            onClick={() => setShowProfileModal(true)}
          >
            {t('sponsor.dashboard.profile.button')}
          </Button>
          <Button
            variant="secondary"
            icon={LogOut}
            onClick={handleLogout}
          >
            {t('common.buttons.logout')}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {children.map(child => (
          <div key={child.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src={child.image_url}
              alt={child.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h2 className="text-xl font-semibold mb-2">{child.name}</h2>
              <p className="text-gray-600 mb-4">
                {child.age} {t('children.details.age')} - {child.city}
              </p>
              
              <div className="space-y-3">
                <Button
                  variant="primary"
                  icon={Upload}
                  fullWidth
                  onClick={() => {
                    setSelectedChild(child);
                    setShowAddMemoryModal(true);
                  }}
                >
                  {t('sponsor.dashboard.children.add_memory')}
                </Button>

                <Button
                  variant="secondary"
                  icon={Heart}
                  fullWidth
                  onClick={() => {
                    setSelectedChild(child);
                    setShowAddTestimonialModal(true);
                  }}
                >
                  {t('sponsor.dashboard.children.add_testimonial')}
                </Button>

                <Button
                  variant="danger"
                  icon={Heart}
                  fullWidth
                  onClick={() => handleCancelSponsorship(child)}
                >
                  {t('sponsor.dashboard.children.plan_end')}
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {children.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <p className="text-gray-600">{t('sponsor.dashboard.children.no_children')}</p>
        </div>
      )}

      {memories.length > 0 && (
        <section className="mt-8">
          <h2 className="text-2xl font-bold mb-6">{t('sponsor.dashboard.memories.title')}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {memories.map(memory => {
              const child = children.find(c => c.id === memory.child_id);
              return (
                <div key={memory.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                  <div className="relative">
                    <img
                      src={memory.image_url}
                      alt="Memory"
                      className="w-full h-48 object-cover"
                    />
                    {child && (
                      <div className="absolute top-2 right-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-sm">
                        {child.name}
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <p className="text-sm text-gray-500">
                      {new Date(memory.created_at).toLocaleDateString()}
                    </p>
                    {memory.description && (
                      <p className="text-gray-600 mt-2">{memory.description}</p>
                    )}
                    <Button
                      variant="secondary"
                      size="sm"
                      icon={Heart}
                      onClick={() => deleteMemory(memory.id)}
                      className="mt-2"
                    >
                      {t('sponsor.dashboard.memories.delete')}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {showAddMemoryModal && selectedChild && (
        <AddMemoryModal
          child={selectedChild}
          sponsorId={sponsorData.id}
          onClose={() => setShowAddMemoryModal(false)}
          onSuccess={() => {
            setShowAddMemoryModal(false);
            const sponsorData = localStorage.getItem('sponsor');
            if (sponsorData) {
              const sponsor = JSON.parse(sponsorData);
              fetchSponsoredChildren(sponsor.id);
            }
          }}
        />
      )}

      {showAddTestimonialModal && selectedChild && (
        <AddTestimonialModal
          child={selectedChild}
          sponsorId={sponsorData.id}
          onClose={() => setShowAddTestimonialModal(false)}
          onSuccess={() => {
            setShowAddTestimonialModal(false);
            toast.success(t('sponsor.dashboard.testimonial.success'));
          }}
        />
      )}

      {showCancelModal && selectedChild && (
        <CancelSponsorshipModal
          child={selectedChild}
          onClose={() => setShowCancelModal(false)}
          onSuccess={handleSponsorshipCancelled}
        />
      )}

      {showProfileModal && (
        <EditSponsorProfileModal
          sponsor={sponsorData}
          onClose={() => setShowProfileModal(false)}
          onSuccess={() => {
            setShowProfileModal(false);
            toast.success(t('sponsor.dashboard.profile.success'));
          }}
        />
      )}
    </div>
  );
};

export default SponsorDashboard;