import React, { useState } from 'react';
import { Mail } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import Button from './Button';

const NewsletterSignup: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase
        .from('mailing_list')
        .insert([{ 
          email: email.toLowerCase().trim(), 
          name: name.trim() 
        }]);

      if (error) throw error;

      toast.success('Inscription réussie à la newsletter !');
      setEmail('');
      setName('');
      
      // Envoyer un email de bienvenue
      await supabase.functions.invoke('send-welcome-email', {
        body: { email, name }
      });
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de l\'inscription');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center space-x-3 mb-4">
        <Mail className="w-6 h-6 text-red-600" />
        <h3 className="text-xl font-semibold">Newsletter PassionVaradero</h3>
      </div>
      
      <p className="text-gray-600 mb-6">
        Recevez nos meilleurs conseils pour votre voyage à Varadero et des offres exclusives !
      </p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
            Votre nom
          </label>
          <input
            type="text"
            id="name"
            required
            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
            value={name}
            onChange={(e) => setName(e.target.value)}
            disabled={loading}
          />
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
            Votre email
          </label>
          <input
            type="email"
            id="email"
            required
            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={loading}
          />
        </div>

        <Button
          type="submit"
          variant="primary"
          fullWidth
          loading={loading}
        >
          S'inscrire à la newsletter
        </Button>
        
        <p className="text-xs text-gray-500 text-center">
          En vous inscrivant, vous acceptez de recevoir nos emails. 
          Vous pourrez vous désinscrire à tout moment.
        </p>
      </form>
    </div>
  );
};

export default NewsletterSignup;