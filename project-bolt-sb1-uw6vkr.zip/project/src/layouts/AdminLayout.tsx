import React from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Heart,
  BarChart, 
  Settings,
  BookOpen,
  LogOut 
} from 'lucide-react';
import Button from '../components/Button';

const AdminLayout: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    { path: '/admin', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/admin/enfants', icon: Users, label: 'Enfants' },
    { path: '/admin/parrains', icon: Heart, label: 'Parrains' },
    { path: '/admin/temoignages', icon: BookOpen, label: 'Témoignages' },
    { path: '/admin/statistiques', icon: BarChart, label: 'Statistiques' },
    { path: '/admin/parametres', icon: Settings, label: 'Paramètres' }
  ];

  const handleLogout = () => {
    localStorage.removeItem('adminAuthenticated');
    navigate('/admin/login');
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-lg mb-6 py-2 px-4">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2 overflow-x-auto pb-2">
            {menuItems.map(({ path, icon: Icon, label }) => (
              <Button
                key={path}
                variant={isActive(path) ? "primary" : "secondary"}
                icon={Icon}
                onClick={() => navigate(path)}
                size="sm"
              >
                {label}
              </Button>
            ))}
          </div>
          
          <Button
            variant="secondary"
            icon={LogOut}
            onClick={handleLogout}
            size="sm"
          >
            Déconnexion
          </Button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <main className="bg-white rounded-lg shadow-md p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;