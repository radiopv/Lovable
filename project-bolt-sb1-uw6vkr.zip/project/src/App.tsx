import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'sonner';
import ErrorBoundary from './components/ErrorBoundary';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import LoadingSpinner from './components/LoadingSpinner';
import AdminRoute from './components/AdminRoute';
import SponsorRoute from './components/SponsorRoute';
import AdminLayout from './layouts/AdminLayout';
import { publicRoutes, sponsorRoutes, adminRoutes } from './lib/routes';

const App: React.FC = () => {
  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Navbar />
        
        <main className="flex-grow">
          <React.Suspense fallback={<LoadingSpinner />}>
            <Routes>
              {/* Public routes */}
              {publicRoutes.map(route => (
                <Route
                  key={route.path}
                  path={route.path}
                  element={<route.component />}
                />
              ))}

              {/* Sponsor routes */}
              {sponsorRoutes.map(route => (
                <Route
                  key={route.path}
                  path={route.path}
                  element={
                    route.path === '/parrain/connexion' ? (
                      <route.component />
                    ) : (
                      <SponsorRoute>
                        <route.component />
                      </SponsorRoute>
                    )
                  }
                />
              ))}

              {/* Admin routes */}
              {adminRoutes.map(route => (
                <Route
                  key={route.path}
                  path={route.path}
                  element={
                    route.path === '/admin/login' ? (
                      <route.component />
                    ) : (
                      <AdminRoute>
                        <AdminLayout>
                          <route.component />
                        </AdminLayout>
                      </AdminRoute>
                    )
                  }
                />
              ))}

              {/* Catch all route */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </React.Suspense>
        </main>

        <Footer />
        <Toaster position="top-center" />
      </div>
    </ErrorBoundary>
  );
};

export default App;