import { z } from 'zod';

// Child Schema
export const ChildSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1, 'Name is required'),
  age: z.number().min(0).max(18),
  gender: z.enum(['male', 'female']),
  city: z.string().min(1, 'City is required'),
  birthday: z.string().optional(),
  situation: z.string().optional(),
  image_url: z.string().url().optional(),
  is_sponsored: z.boolean().default(false),
  sponsor_id: z.string().optional(),
  private_notes: z.string().optional(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
  needs: z.array(z.object({
    category: z.enum(['essential', 'healthcare', 'education', 'clothing', 'development', 'emergency']),
    description: z.string(),
    priority: z.enum(['high', 'medium', 'low']),
    is_urgent: z.boolean()
  })).optional()
});

export type Child = z.infer<typeof ChildSchema>;