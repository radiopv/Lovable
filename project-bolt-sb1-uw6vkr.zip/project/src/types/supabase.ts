export interface Database {
  public: {
    Tables: {
      home_content: {
        Row: {
          id: string;
          section: string;
          title: string;
          content: string;
          image_url?: string;
          created_at: string;
          updated_at: string;
          background_color?: string;
          text_color?: string;
          button_text?: string;
          button_url?: string;
          custom_html?: string;
          news_items?: string[];
          is_html_enabled: boolean;
        };
        Insert: {
          id?: string;
          section: string;
          title: string;
          content: string;
          image_url?: string;
          created_at?: string;
          updated_at?: string;
          background_color?: string;
          text_color?: string;
          button_text?: string;
          button_url?: string;
          custom_html?: string;
          news_items?: string[];
          is_html_enabled?: boolean;
        };
        Update: {
          id?: string;
          section?: string;
          title?: string;
          content?: string;
          image_url?: string;
          updated_at?: string;
          background_color?: string;
          text_color?: string;
          button_text?: string;
          button_url?: string;
          custom_html?: string;
          news_items?: string[];
          is_html_enabled?: boolean;
        };
      };
    };
  };
}