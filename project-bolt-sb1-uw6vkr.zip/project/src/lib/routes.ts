import { lazy } from 'react';

// Public routes
export const publicRoutes = [
  {
    path: '/',
    component: lazy(() => import('../pages/Home')),
    title: 'Accueil',
    description: 'Transformez la vie d\'un enfant cubain grâce à notre programme de parrainage'
  },
  {
    path: '/enfants',
    component: lazy(() => import('../pages/ChildrenList')),
    title: 'Enfants à parrainer',
    description: 'Découvrez les enfants qui attendent votre aide'
  },
  {
    path: '/parraines',
    component: lazy(() => import('../pages/SponsoredChildren')),
    title: 'Enfants parrainés',
    description: 'Voyez l\'impact de nos parrainages'
  },
  {
    path: '/temoignages',
    component: lazy(() => import('../pages/Testimonials')),
    title: 'Témoignages',
    description: 'Découvrez les histoires touchantes de nos parrains'
  }
];

// Sponsor routes
export const sponsorRoutes = [
  {
    path: '/parrain/connexion',
    component: lazy(() => import('../pages/SponsorLogin')),
    title: 'Connexion Parrain',
    description: 'Accédez à votre espace parrain'
  },
  {
    path: '/parrain/tableau-de-bord',
    component: lazy(() => import('../pages/SponsorDashboard')),
    title: 'Tableau de bord',
    description: 'Gérez vos parrainages et suivez vos filleuls'
  },
  {
    path: '/parrain/forum',
    component: lazy(() => import('../pages/SponsorForum')),
    title: 'Forum des parrains',
    description: 'Échangez avec les autres parrains'
  }
];

// Admin routes
export const adminRoutes = [
  {
    path: '/admin/login',
    component: lazy(() => import('../pages/AdminLogin')),
    title: 'Connexion Admin',
    description: 'Accès administrateur'
  },
  {
    path: '/admin',
    component: lazy(() => import('../pages/AdminDashboard')),
    title: 'Administration',
    description: 'Tableau de bord administrateur'
  },
  {
    path: '/admin/enfants',
    component: lazy(() => import('../pages/AdminChildren')),
    title: 'Gestion des enfants',
    description: 'Gérer les profils des enfants'
  },
  {
    path: '/admin/parrains',
    component: lazy(() => import('../pages/AdminSponsors')),
    title: 'Gestion des parrains',
    description: 'Gérer les comptes parrains'
  },
  {
    path: '/admin/temoignages',
    component: lazy(() => import('../pages/AdminTestimonials')),
    title: 'Gestion des témoignages',
    description: 'Modérer les témoignages'
  },
  {
    path: '/admin/statistiques',
    component: lazy(() => import('../pages/Statistics')),
    title: 'Statistiques',
    description: 'Statistiques du programme'
  },
  {
    path: '/admin/parametres',
    component: lazy(() => import('../pages/Settings')),
    title: 'Paramètres',
    description: 'Configuration du site'
  }
];

// Route validation
export const validateRoutes = () => {
  const allRoutes = [...publicRoutes, ...sponsorRoutes, ...adminRoutes];
  const paths = new Set();

  for (const route of allRoutes) {
    if (paths.has(route.path)) {
      throw new Error(`Duplicate route path: ${route.path}`);
    }
    paths.add(route.path);

    if (!route.component) {
      throw new Error(`Missing component for route: ${route.path}`);
    }
  }
};