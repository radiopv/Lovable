import { supabase } from './supabase';

// Rate limiting configuration
const RATE_LIMIT = {
  MAX_ATTEMPTS: 5,
  WINDOW_MS: 15 * 60 * 1000, // 15 minutes
  LOCKOUT_MS: 60 * 60 * 1000 // 1 hour
};

// Track login attempts
const loginAttempts = new Map<string, { count: number; timestamp: number }>();

export const checkRateLimit = (identifier: string): boolean => {
  const now = Date.now();
  const attempt = loginAttempts.get(identifier);

  if (!attempt) {
    loginAttempts.set(identifier, { count: 1, timestamp: now });
    return true;
  }

  if (now - attempt.timestamp > RATE_LIMIT.WINDOW_MS) {
    loginAttempts.set(identifier, { count: 1, timestamp: now });
    return true;
  }

  if (attempt.count >= RATE_LIMIT.MAX_ATTEMPTS) {
    if (now - attempt.timestamp < RATE_LIMIT.LOCKOUT_MS) {
      return false;
    }
    loginAttempts.set(identifier, { count: 1, timestamp: now });
    return true;
  }

  attempt.count += 1;
  return true;
};

// Input sanitization
export const sanitizeInput = (input: string): string => {
  return input
    .replace(/[<>]/g, '') // Remove < and >
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+=/gi, '') // Remove event handlers
    .trim();
};

// Content Security Policy
export const CSP_DIRECTIVES = {
  'default-src': ["'self'"],
  'script-src': ["'self'", "'unsafe-inline'", 'https://dgjksmnwhgiqtisionam.supabase.co'],
  'style-src': ["'self'", "'unsafe-inline'"],
  'img-src': ["'self'", 'data:', 'https:', 'blob:'],
  'connect-src': ["'self'", 'https://dgjksmnwhgiqtisionam.supabase.co'],
  'frame-ancestors': ["'none'"],
  'form-action': ["'self'"]
};

// Security headers
export const SECURITY_HEADERS = {
  'Content-Security-Policy': Object.entries(CSP_DIRECTIVES)
    .map(([key, values]) => `${key} ${values.join(' ')}`)
    .join('; '),
  'X-Frame-Options': 'DENY',
  'X-Content-Type-Options': 'nosniff',
  'X-XSS-Protection': '1; mode=block',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()'
};

// Secure file upload validation
export const validateFileUpload = (file: File): boolean => {
  const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'video/mp4'];
  const MAX_SIZE = 5 * 1024 * 1024; // 5MB

  if (!ALLOWED_TYPES.includes(file.type)) {
    throw new Error('Type de fichier non autorisé');
  }

  if (file.size > MAX_SIZE) {
    throw new Error('Fichier trop volumineux (max 5MB)');
  }

  return true;
};