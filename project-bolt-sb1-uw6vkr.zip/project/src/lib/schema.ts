import { supabase } from './supabase';

// Helper function to execute SQL queries
const executeQuery = async (query: string) => {
  try {
    const { error } = await supabase.rpc('execute_sql', { query });
    if (error) throw error;
  } catch (err) {
    console.error('Error executing query:', err);
    throw err;
  }
};

// Initialize database schema and functions
export const initializeSchema = async () => {
  try {
    // Create execute_sql function if it doesn't exist
    await supabase.rpc('execute_sql', {
      query: `
        create or replace function execute_sql(query text)
        returns void as $$
        begin
          execute query;
        exception
          when others then
            raise notice 'Error executing query: %', SQLERRM;
        end;
        $$ language plpgsql security definer;
      `
    });

    // Create required tables
    await executeQuery(`
      -- Create news table if not exists
      create table if not exists news (
        id uuid primary key default uuid_generate_v4(),
        text text not null,
        url text,
        is_active boolean default true,
        created_at timestamp with time zone default now(),
        updated_at timestamp with time zone default now()
      );

      -- Create statistics table if not exists
      create table if not exists statistics (
        id uuid primary key default uuid_generate_v4(),
        total_children integer default 0,
        sponsored_children integer default 0,
        active_sponsors integer default 0,
        regions jsonb default '[]'::jsonb,
        updated_at timestamp with time zone default now()
      );

      -- Insert initial statistics if none exist
      insert into statistics (total_children, sponsored_children, active_sponsors, regions)
      select 0, 0, 0, '[]'::jsonb
      where not exists (select 1 from statistics);

      -- Enable RLS
      alter table news enable row level security;
      alter table statistics enable row level security;

      -- Create policies
      do $$
      begin
        -- News policies
        if not exists (
          select 1 from pg_policies where tablename = 'news' and policyname = 'Public can view news'
        ) then
          create policy "Public can view news"
            on news for select
            using (true);
        end if;

        if not exists (
          select 1 from pg_policies where tablename = 'news' and policyname = 'Admins can manage news'
        ) then
          create policy "Admins can manage news"
            on news for all
            using (auth.role() = 'authenticated');
        end if;

        -- Statistics policies
        if not exists (
          select 1 from pg_policies where tablename = 'statistics' and policyname = 'Public can view statistics'
        ) then
          create policy "Public can view statistics"
            on statistics for select
            using (true);
        end if;

        if not exists (
          select 1 from pg_policies where tablename = 'statistics' and policyname = 'Admins can manage statistics'
        ) then
          create policy "Admins can manage statistics"
            on statistics for all
            using (auth.role() = 'authenticated');
        end if;
      end $$;
    `);

    console.log('Database schema initialized successfully');
  } catch (error) {
    console.error('Error initializing schema:', error);
    throw error;
  }
};