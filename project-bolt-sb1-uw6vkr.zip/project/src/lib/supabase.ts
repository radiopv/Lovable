import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing Supabase configuration');
}

export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  }
});

// Initialize database schema
export const initializeSchema = async () => {
  try {
    // Create tables if they don't exist
    const { data, error } = await supabase
      .from('children')
      .select('count')
      .limit(1);

    if (error) {
      console.error('Error checking schema:', error);
      return;
    }

    console.log('Database schema initialized successfully');
  } catch (error) {
    console.error('Error initializing schema:', error);
  }
};

// Initialize everything
export const initSupabase = async () => {
  try {
    await initializeSchema();
    console.log('Supabase initialized successfully');
  } catch (error) {
    console.error('Error initializing Supabase:', error);
  }
};