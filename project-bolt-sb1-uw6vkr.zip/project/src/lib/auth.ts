import { supabase } from './supabase';

// Admin credentials
export const ADMIN_EMAIL = 'renaudcanuel@me.com';
export const ADMIN_PASSWORD = 'Lechef400..';

// Admin authentication functions
export const isAdmin = async (email: string) => {
  return email === ADMIN_EMAIL;
};

export const adminLogin = async (email: string, password: string) => {
  try {
    if (email !== ADMIN_EMAIL || password !== ADMIN_PASSWORD) {
      throw new Error('Invalid email or password');
    }

    localStorage.setItem('adminAuthenticated', 'true');
    localStorage.setItem('adminEmail', email);
    
    return true;
  } catch (error) {
    localStorage.removeItem('adminAuthenticated');
    localStorage.removeItem('adminEmail');
    throw error;
  }
};

export const adminLogout = () => {
  localStorage.removeItem('adminAuthenticated');
  localStorage.removeItem('adminEmail');
};

export const isAdminAuthenticated = () => {
  return localStorage.getItem('adminAuthenticated') === 'true' &&
         localStorage.getItem('adminEmail') === ADMIN_EMAIL;
};

// Simple sponsor authentication
export const isSponsorAuthenticated = () => {
  return true; // Allow all access for now
};