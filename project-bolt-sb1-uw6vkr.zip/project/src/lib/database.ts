import { supabase } from './supabase';
import type { Child } from '../types';

// Helper function to handle Supabase errors
const handleSupabaseError = (error: any, defaultValue: any = []) => {
  console.warn('Supabase error:', error);
  if (process.env.NODE_ENV === 'development') {
    return defaultValue;
  }
  throw error;
};

// Children functions
export const getChildren = async (): Promise<Child[]> => {
  try {
    const { data, error } = await supabase
      .from('children')
      .select(`
        *,
        needs (
          category,
          description,
          priority,
          is_urgent
        )
      `)
      .order('created_at', { ascending: false });

    if (error) return handleSupabaseError(error);
    return Array.isArray(data) ? data : [];
  } catch (error) {
    return handleSupabaseError(error);
  }
};

export const getChildById = async (id: string): Promise<Child | null> => {
  try {
    const { data, error } = await supabase
      .from('children')
      .select(`
        *,
        needs (
          category,
          description,
          priority,
          is_urgent
        ),
        sponsor:sponsors (
          id,
          name,
          is_anonymous,
          facebook_url
        )
      `)
      .eq('id', id)
      .single();

    if (error) return null;
    return data;
  } catch (error) {
    console.error('Error fetching child:', error);
    return null;
  }
};

export const createChild = async (child: Omit<Child, 'id'>): Promise<Child | null> => {
  try {
    const { data, error } = await supabase
      .from('children')
      .insert([child])
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error creating child:', error);
    return null;
  }
};

export const updateChild = async (id: string, updates: Partial<Child>): Promise<boolean> => {
  try {
    const { error } = await supabase
      .from('children')
      .update(updates)
      .eq('id', id);

    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error updating child:', error);
    return false;
  }
};

export const deleteChild = async (id: string): Promise<boolean> => {
  try {
    const { error } = await supabase
      .from('children')
      .delete()
      .eq('id', id);

    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error deleting child:', error);
    return false;
  }
};