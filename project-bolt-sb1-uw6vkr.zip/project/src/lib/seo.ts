import { Helmet } from 'react-helmet-async';

export const defaultMetaTags = {
  title: 'Parrainage Cuba - Aidez un enfant cubain',
  description: 'Transformez la vie d\'un enfant cubain grâce à notre programme de parrainage. Découvrez comment vous pouvez faire la différence aujourd\'hui.',
  keywords: 'parrainage, cuba, enfants, aide humanitaire, éducation, santé',
  ogImage: 'https://images.unsplash.com/photo-1500759285222-a95626b934cb',
  domain: 'passionvaradero.ca'
};

interface PageMetaProps {
  title?: string;
  description?: string;
  image?: string;
  path: string;
}

export const generateMetaTags = ({
  title,
  description,
  image,
  path
}: PageMetaProps) => {
  const fullTitle = title 
    ? `${title} | ${defaultMetaTags.title}`
    : defaultMetaTags.title;

  const fullUrl = `https://${defaultMetaTags.domain}${path}`;
  const imageUrl = image || defaultMetaTags.ogImage;

  return (
    <Helmet>
      {/* Basic Meta Tags */}
      <title>{fullTitle}</title>
      <meta name="description" content={description || defaultMetaTags.description} />
      <meta name="keywords" content={defaultMetaTags.keywords} />

      {/* Open Graph */}
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description || defaultMetaTags.description} />
      <meta property="og:image" content={imageUrl} />
      <meta property="og:url" content={fullUrl} />
      <meta property="og:type" content="website" />
      <meta property="og:site_name" content={defaultMetaTags.title} />
      <meta property="og:locale" content="fr_FR" />

      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description || defaultMetaTags.description} />
      <meta name="twitter:image" content={imageUrl} />
      <meta name="twitter:url" content={fullUrl} />

      {/* Canonical URL */}
      <link rel="canonical" href={fullUrl} />

      {/* Additional Meta Tags */}
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <meta name="theme-color" content="#dc2626" />
      <meta name="robots" content="index, follow" />
      <meta name="language" content="fr" />

      {/* JSON-LD */}
      <script type="application/ld+json">
        {JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'Organization',
          'name': defaultMetaTags.title,
          'url': `https://${defaultMetaTags.domain}`,
          'logo': `https://${defaultMetaTags.domain}/logo.png`,
          'sameAs': [
            'https://facebook.com/passionvaradero',
            'https://instagram.com/passionvaradero'
          ],
          'contactPoint': {
            '@type': 'ContactPoint',
            'telephone': '+1-514-XXX-XXXX',
            'contactType': 'customer service',
            'availableLanguage': ['French', 'English', 'Spanish']
          },
          'description': defaultMetaTags.description
        })}
      </script>
    </Helmet>
  );
};