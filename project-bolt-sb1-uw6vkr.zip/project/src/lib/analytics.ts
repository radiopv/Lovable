// Analytics configuration
const ANALYTICS_CONFIG = {
  TRACKING_ID: 'UA-XXXXXXXXX-X',
  DEBUG_MODE: process.env.NODE_ENV === 'development'
};

// Page view tracking
export const trackPageView = (path: string) => {
  try {
    if (typeof window.gtag !== 'undefined') {
      window.gtag('config', ANALYTICS_CONFIG.TRACKING_ID, {
        page_path: path
      });
    }
  } catch (error) {
    if (ANALYTICS_CONFIG.DEBUG_MODE) {
      console.error('Error tracking page view:', error);
    }
  }
};

// Event tracking
export const trackEvent = (
  category: string,
  action: string,
  label?: string,
  value?: number
) => {
  try {
    if (typeof window.gtag !== 'undefined') {
      window.gtag('event', action, {
        event_category: category,
        event_label: label,
        value: value
      });
    }
  } catch (error) {
    if (ANALYTICS_CONFIG.DEBUG_MODE) {
      console.error('Error tracking event:', error);
    }
  }
};

// Error tracking
export const trackError = (error: Error, context?: string) => {
  try {
    if (typeof window.gtag !== 'undefined') {
      window.gtag('event', 'error', {
        event_category: 'Error',
        event_label: context || 'Unknown context',
        error_name: error.name,
        error_message: error.message,
        error_stack: error.stack
      });
    }
  } catch (err) {
    if (ANALYTICS_CONFIG.DEBUG_MODE) {
      console.error('Error tracking error:', err);
    }
  }
};

// User tracking
export const trackUser = (userId: string, properties?: Record<string, any>) => {
  try {
    if (typeof window.gtag !== 'undefined') {
      window.gtag('set', 'user_properties', {
        user_id: userId,
        ...properties
      });
    }
  } catch (error) {
    if (ANALYTICS_CONFIG.DEBUG_MODE) {
      console.error('Error tracking user:', error);
    }
  }
};