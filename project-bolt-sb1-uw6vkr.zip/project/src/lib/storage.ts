import { supabase } from './supabase';

export const initStorage = async () => {
  try {
    // Create required buckets with proper configuration
    const buckets = [
      {
        id: 'media',
        options: {
          public: true,
          allowedMimeTypes: ['image/*', 'video/*'],
          fileSizeLimit: 5242880 // 5MB
        }
      },
      {
        id: 'memories',
        options: {
          public: true,
          allowedMimeTypes: ['image/*', 'video/*'],
          fileSizeLimit: 5242880
        }
      },
      {
        id: 'avatars',
        options: {
          public: true,
          allowedMimeTypes: ['image/*'],
          fileSizeLimit: 2097152 // 2MB
        }
      }
    ];
    
    for (const bucket of buckets) {
      const { data, error } = await supabase.storage.getBucket(bucket.id);
      
      if (error && error.message.includes('not found')) {
        await supabase.storage.createBucket(bucket.id, bucket.options);
        console.log(`Created bucket: ${bucket.id}`);
      } else if (error) {
        console.error(`Error checking bucket ${bucket.id}:`, error);
      } else {
        // Update bucket configuration if it exists
        await supabase.storage.updateBucket(bucket.id, bucket.options);
        console.log(`Updated bucket: ${bucket.id}`);
      }
    }

    console.log('Storage initialization completed');
  } catch (error) {
    console.error('Error initializing storage:', error);
    throw error;
  }
};

export const uploadFile = async (
  file: File,
  bucket: string,
  path: string
): Promise<string> => {
  try {
    // Ensure bucket exists before upload
    const { data: bucketData, error: bucketError } = await supabase.storage.getBucket(bucket);
    if (bucketError && bucketError.message.includes('not found')) {
      await initStorage();
    }

    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(path, file, {
        cacheControl: '3600',
        upsert: false
      });

    if (error) throw error;

    const { data: { publicUrl } } = supabase.storage
      .from(bucket)
      .getPublicUrl(data.path);

    return publicUrl;
  } catch (error) {
    console.error('Error uploading file:', error);
    throw error;
  }
};

export const deleteFile = async (bucket: string, path: string): Promise<void> => {
  try {
    const { error } = await supabase.storage
      .from(bucket)
      .remove([path]);

    if (error) throw error;
  } catch (error) {
    console.error('Error deleting file:', error);
    throw error;
  }
};