import { supabase } from './supabase';

// Cache configuration
const CACHE_CONFIG = {
  MAX_AGE: 5 * 60 * 1000, // 5 minutes
  STALE_WHILE_REVALIDATE: 60 * 60 * 1000 // 1 hour
};

// Cache implementation
const cache = new Map<string, {
  data: any;
  timestamp: number;
}>();

// Cached data fetching
export const fetchWithCache = async (
  key: string,
  fetcher: () => Promise<any>
) => {
  const now = Date.now();
  const cached = cache.get(key);

  if (cached) {
    if (now - cached.timestamp < CACHE_CONFIG.MAX_AGE) {
      return cached.data;
    }

    if (now - cached.timestamp < CACHE_CONFIG.STALE_WHILE_REVALIDATE) {
      // Return stale data while revalidating
      revalidateCache(key, fetcher);
      return cached.data;
    }
  }

  return revalidateCache(key, fetcher);
};

const revalidateCache = async (
  key: string,
  fetcher: () => Promise<any>
) => {
  try {
    const data = await fetcher();
    cache.set(key, {
      data,
      timestamp: Date.now()
    });
    return data;
  } catch (error) {
    // If cache exists, return stale data on error
    if (cache.has(key)) {
      console.warn(`Error fetching fresh data for ${key}, using stale cache:`, error);
      return cache.get(key)!.data;
    }
    throw error;
  }
};

// Image optimization
export const optimizeImage = async (file: File): Promise<Blob> => {
  const MAX_WIDTH = 1200;
  const QUALITY = 0.8;

  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        reject(new Error('Could not get canvas context'));
        return;
      }

      let width = img.width;
      let height = img.height;

      if (width > MAX_WIDTH) {
        height = (height * MAX_WIDTH) / width;
        width = MAX_WIDTH;
      }

      canvas.width = width;
      canvas.height = height;

      ctx.drawImage(img, 0, 0, width, height);

      canvas.toBlob(
        (blob) => {
          if (!blob) {
            reject(new Error('Could not create blob'));
            return;
          }
          resolve(blob);
        },
        'image/jpeg',
        QUALITY
      );
    };

    img.onerror = () => reject(new Error('Could not load image'));
    img.src = URL.createObjectURL(file);
  });
};

// Lazy loading implementation
export const lazyLoad = (
  element: HTMLElement,
  callback: () => void,
  options = {}
) => {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        callback();
        observer.unobserve(entry.target);
      }
    });
  }, options);

  observer.observe(element);

  return () => observer.disconnect();
};