import { supabase } from './supabase';

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
}

export const sendEmail = async ({ to, subject, html }: EmailOptions) => {
  try {
    // Queue the email in Supabase
    const { error } = await supabase
      .from('email_queue')
      .insert([{
        to_email: to,
        subject,
        html,
        status: 'pending',
        created_at: new Date().toISOString()
      }]);

    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error queueing email:', error);
    throw error;
  }
};

export const sendSponsorshipEmail = async (
  email: string,
  childName: string,
  sponsorName: string
) => {
  try {
    await sendEmail({
      to: email,
      subject: `Sponsorship Confirmation - ${childName}`,
      html: `
        <h1>Congratulations ${sponsorName}!</h1>
        <p>Your sponsorship of ${childName} has been confirmed.</p>
        <p>You can now log in to your sponsor area to follow their progress.</p>
      `
    });
  } catch (error) {
    console.error('Error sending sponsorship email:', error);
    // Don't throw the error to avoid blocking the sponsorship process
  }
};