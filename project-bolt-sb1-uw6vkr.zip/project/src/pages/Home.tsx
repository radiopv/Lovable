import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Calendar, MapPin } from 'lucide-react';
import Button from '../components/Button';
import NewsTicker from '../components/NewsTicker';
import StatisticsSection from '../components/StatisticsSection';
import TestimonialSection from '../components/TestimonialSection';
import HeroSection from '../components/HeroSection';

const Home: React.FC = () => {
  return (
    <>
      <NewsTicker />
      
      <HeroSection />

      <StatisticsSection />

      <TestimonialSection />

      <section className="py-16 bg-red-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">
            Commencez votre voyage de parrainage aujourd'hui
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Transformez la vie d'un enfant et créez un impact durable à travers notre programme de parrainage.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button
              to="/enfants"
              variant="secondary"
              size="lg"
              icon={Heart}
            >
              Parrainer un enfant
            </Button>
            <Button
              to="/parraines"
              variant="secondary"
              size="lg"
              icon={Calendar}
            >
              Voir les enfants parrainés
            </Button>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;