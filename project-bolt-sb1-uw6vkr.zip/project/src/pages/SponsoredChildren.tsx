import React, { useState, useEffect } from 'react';
import { ArrowUpDown } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Child } from '../types';
import Button from '../components/Button';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import SearchBar from '../components/SearchBar';
import ChildCard from '../components/ChildCard';

const SponsoredChildren: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [children, setChildren] = useState<Child[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  useEffect(() => {
    fetchSponsoredChildren();
  }, []);

  const fetchSponsoredChildren = async () => {
    try {
      const { data, error } = await supabase
        .from('children')
        .select(`
          *,
          sponsor:sponsors (
            id,
            name,
            is_anonymous
          )
        `)
        .eq('is_sponsored', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setChildren(data || []);
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des enfants parrainés');
    } finally {
      setLoading(false);
    }
  };

  const filteredChildren = children.filter(child =>
    child.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    child.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (child.sponsor?.name && !child.sponsor.is_anonymous && 
     child.sponsor.name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const sortedChildren = [...filteredChildren].sort((a, b) => {
    const dateA = new Date(a.created_at).getTime();
    const dateB = new Date(b.created_at).getTime();
    return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
  });

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Enfants Parrainés</h1>
        <div className="flex items-center gap-4">
          <SearchBar
            value={searchTerm}
            onChange={setSearchTerm}
            placeholder="Rechercher..."
          />
          <Button
            variant="secondary"
            icon={ArrowUpDown}
            onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
          >
            {sortOrder === 'asc' ? 'Plus anciens d\'abord' : 'Plus récents d\'abord'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {sortedChildren.map((child) => (
          <ChildCard
            key={child.id}
            child={child}
            showSponsorInfo
          />
        ))}
      </div>

      {sortedChildren.length === 0 && (
        <div className="text-center py-12">
          <p className="text-xl text-gray-600">
            {searchTerm ? 'Aucun résultat trouvé' : 'Aucun enfant parrainé pour le moment'}
          </p>
        </div>
      )}
    </div>
  );
};

export default SponsoredChildren;