import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  LogOut, 
  Baby,
  Database,
  BarChart
} from 'lucide-react';
import { toast } from 'sonner';
import { adminLogout } from '../lib/auth';
import Button from '../components/Button';
import DatabaseManagerModal from '../components/DatabaseManagerModal';

const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [showDatabaseModal, setShowDatabaseModal] = useState(false);

  const handleLogout = () => {
    adminLogout();
    navigate('/admin/login');
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Administration</h1>
        <Button
          onClick={handleLogout}
          variant="secondary"
          icon={LogOut}
        >
          Déconnexion
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center mb-4">
            <Baby className="w-6 h-6 text-blue-500 mr-2" />
            <h2 className="text-xl font-semibold">Gestion des enfants</h2>
          </div>
          <p className="text-gray-600 mb-4">
            Gérer les profils des enfants et leur statut de parrainage
          </p>
          <Button
            onClick={() => navigate('/admin/enfants')}
            variant="secondary"
            fullWidth
          >
            Accéder
          </Button>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center mb-4">
            <Database className="w-6 h-6 text-indigo-500 mr-2" />
            <h2 className="text-xl font-semibold">Base de données</h2>
          </div>
          <p className="text-gray-600 mb-4">
            Gérer les données de l'application
          </p>
          <Button
            onClick={() => setShowDatabaseModal(true)}
            variant="secondary"
            fullWidth
          >
            Ouvrir
          </Button>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center mb-4">
            <BarChart className="w-6 h-6 text-green-500 mr-2" />
            <h2 className="text-xl font-semibold">Statistiques</h2>
          </div>
          <p className="text-gray-600 mb-4">
            Consulter les statistiques du site
          </p>
          <Button
            onClick={() => navigate('/admin/statistiques')}
            variant="secondary"
            fullWidth
          >
            Voir les statistiques
          </Button>
        </div>
      </div>

      {showDatabaseModal && (
        <DatabaseManagerModal
          onClose={() => setShowDatabaseModal(false)}
          onSuccess={() => {
            setShowDatabaseModal(false);
            toast.success('Base de données mise à jour avec succès');
          }}
        />
      )}
    </div>
  );
};

export default AdminDashboard;