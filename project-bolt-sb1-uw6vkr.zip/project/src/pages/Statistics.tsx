import React, { useState, useEffect } from 'react';
import { BarChart, Heart, Users, BookOpen } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import Button from '../components/Button';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';

interface StatsData {
  totalChildren: number;
  sponsoredChildren: number;
  activeSponsors: number;
  totalMemories: number;
}

const Statistics: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<StatsData | null>(null);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const { data: children, error: childrenError } = await supabase
        .from('children')
        .select('*');

      if (childrenError) throw childrenError;

      const { data: sponsors, error: sponsorsError } = await supabase
        .from('sponsors')
        .select('*');

      if (sponsorsError) throw sponsorsError;

      const { data: memories, error: memoriesError } = await supabase
        .from('memories')
        .select('*');

      if (memoriesError) throw memoriesError;

      setStats({
        totalChildren: children?.length || 0,
        sponsoredChildren: children?.filter(c => c.is_sponsored).length || 0,
        activeSponsors: sponsors?.filter(s => s.children_sponsored?.length > 0).length || 0,
        totalMemories: memories?.length || 0
      });
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des statistiques');
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;
  if (!stats) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Statistiques</h1>
        <Button
          variant="secondary"
          icon={BarChart}
          onClick={() => {
            const data = {
              children: stats.totalChildren,
              sponsored: stats.sponsoredChildren,
              sponsors: stats.activeSponsors,
              memories: stats.totalMemories
            };
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'statistiques.json';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
          }}
        >
          Exporter les statistiques
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Nombre total d'enfants"
          value={stats.totalChildren}
          icon={Users}
        />
        <StatCard
          title="Enfants parrainés"
          value={stats.sponsoredChildren}
          icon={Heart}
        />
        <StatCard
          title="Parrains actifs"
          value={stats.activeSponsors}
          icon={Users}
        />
        <StatCard
          title="Souvenirs partagés"
          value={stats.totalMemories}
          icon={BookOpen}
        />
      </div>
    </div>
  );
};

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.FC<any>;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon: Icon }) => (
  <div className="bg-white p-6 rounded-lg shadow-md">
    <div className="flex justify-between items-start">
      <div>
        <p className="text-gray-600 text-sm">{title}</p>
        <p className="text-3xl font-bold mt-1">{value}</p>
      </div>
      <Icon className="w-8 h-8 text-red-500" />
    </div>
  </div>
);

export default Statistics;