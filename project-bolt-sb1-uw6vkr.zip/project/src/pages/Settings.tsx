import React, { useState } from 'react';
import { Settings as SettingsIcon, Database, Globe, Mail } from 'lucide-react';
import Button from '../components/Button';
import DatabaseManagerModal from '../components/DatabaseManagerModal';
import TranslationManagerModal from '../components/TranslationManagerModal';
import SendNewsletterModal from '../components/SendNewsletterModal';

const Settings: React.FC = () => {
  const [showDatabaseModal, setShowDatabaseModal] = useState(false);
  const [showTranslationModal, setShowTranslationModal] = useState(false);
  const [showNewsletterModal, setShowNewsletterModal] = useState(false);

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4">
        <SettingsIcon className="w-8 h-8 text-gray-400" />
        <h1 className="text-2xl font-bold">Paramètres</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center gap-3 mb-4">
            <Database className="w-6 h-6 text-blue-500" />
            <h2 className="text-lg font-semibold">Base de données</h2>
          </div>
          <p className="text-gray-600 mb-4">
            Gérer les données de l'application, effectuer des sauvegardes et des restaurations.
          </p>
          <Button
            variant="secondary"
            icon={Database}
            onClick={() => setShowDatabaseModal(true)}
            fullWidth
          >
            Gérer la base de données
          </Button>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center gap-3 mb-4">
            <Globe className="w-6 h-6 text-green-500" />
            <h2 className="text-lg font-semibold">Traductions</h2>
          </div>
          <p className="text-gray-600 mb-4">
            Gérer les traductions du site en français, anglais et espagnol.
          </p>
          <Button
            variant="secondary"
            icon={Globe}
            onClick={() => setShowTranslationModal(true)}
            fullWidth
          >
            Gérer les traductions
          </Button>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center gap-3 mb-4">
            <Mail className="w-6 h-6 text-red-500" />
            <h2 className="text-lg font-semibold">Newsletter</h2>
          </div>
          <p className="text-gray-600 mb-4">
            Envoyer des newsletters aux parrains et aux abonnés.
          </p>
          <Button
            variant="secondary"
            icon={Mail}
            onClick={() => setShowNewsletterModal(true)}
            fullWidth
          >
            Envoyer une newsletter
          </Button>
        </div>
      </div>

      {showDatabaseModal && (
        <DatabaseManagerModal
          onClose={() => setShowDatabaseModal(false)}
          onSuccess={() => setShowDatabaseModal(false)}
        />
      )}

      {showTranslationModal && (
        <TranslationManagerModal
          onClose={() => setShowTranslationModal(false)}
          onSuccess={() => setShowTranslationModal(false)}
        />
      )}

      {showNewsletterModal && (
        <SendNewsletterModal
          onClose={() => setShowNewsletterModal(false)}
        />
      )}
    </div>
  );
};

export default Settings;