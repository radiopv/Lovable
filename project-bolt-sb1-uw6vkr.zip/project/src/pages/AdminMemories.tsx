import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Eye, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import type { Child, Memory } from '../types';
import AddAdminMemoryModal from '../components/AddAdminMemoryModal';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import Button from '../components/Button';

const AdminMemories: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [children, setChildren] = useState<Child[]>([]);
  const [memories, setMemories] = useState<Memory[]>([]);
  const [selectedChild, setSelectedChild] = useState<Child | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const { data: childrenData, error: childrenError } = await supabase
        .from('children')
        .select('*')
        .order('name');

      if (childrenError) throw childrenError;
      setChildren(childrenData || []);

      const { data: memoriesData, error: memoriesError } = await supabase
        .from('memories')
        .select(`
          *,
          child:children(name),
          sponsor:sponsors(name, is_anonymous)
        `)
        .order('created_at', { ascending: false });

      if (memoriesError) throw memoriesError;
      setMemories(memoriesData || []);
    } catch (err) {
      console.error('Error:', err);
      setError('Error loading data');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (memoryId: string) => {
    if (!confirm('Are you sure you want to delete this memory?')) return;

    try {
      const { error } = await supabase
        .from('memories')
        .delete()
        .eq('id', memoryId);

      if (error) throw error;

      toast.success('Memory deleted successfully');
      fetchData();
    } catch (err) {
      console.error('Error:', err);
      toast.error('Error deleting memory');
    }
  };

  const filteredMemories = memories.filter(memory =>
    memory.child?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    memory.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Memory Management</h1>
        <div className="flex gap-4">
          <input
            type="text"
            placeholder="Search memories..."
            className="px-4 py-2 border rounded-lg"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Button
            variant="primary"
            icon={Plus}
            onClick={() => setShowAddModal(true)}
          >
            Add Memory
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMemories.map((memory) => (
          <div key={memory.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="relative h-48">
              <img
                src={memory.image_url}
                alt={`Memory for ${memory.child?.name}`}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 right-2 space-x-2">
                <Button
                  variant="danger"
                  size="sm"
                  icon={Trash2}
                  onClick={() => handleDelete(memory.id)}
                >
                  Delete
                </Button>
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-lg mb-2">{memory.child?.name}</h3>
              {memory.description && (
                <p className="text-gray-600 mb-2">{memory.description}</p>
              )}
              <div className="text-sm text-gray-500">
                {memory.sponsor && (
                  <p>
                    By: {memory.sponsor.is_anonymous ? 'Anonymous sponsor' : memory.sponsor.name}
                  </p>
                )}
                <p>
                  {new Date(memory.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-lg w-full p-6">
            <h2 className="text-2xl font-bold mb-4">Select a child</h2>
            <div className="grid grid-cols-2 gap-4 max-h-[60vh] overflow-y-auto">
              {children.map((child) => (
                <button
                  key={child.id}
                  onClick={() => {
                    setSelectedChild(child);
                    setShowAddModal(false);
                  }}
                  className="flex items-center p-4 border rounded-lg hover:bg-gray-50"
                >
                  <img
                    src={child.image_url}
                    alt={child.name}
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div className="text-left">
                    <p className="font-semibold">{child.name}</p>
                    <p className="text-sm text-gray-600">{child.age} years old</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {selectedChild && (
        <AddAdminMemoryModal
          child={selectedChild}
          onClose={() => setSelectedChild(null)}
          onSuccess={() => {
            setSelectedChild(null);
            fetchData();
          }}
        />
      )}
    </div>
  );
};

export default AdminMemories;