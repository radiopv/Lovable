import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Heart, MapPin, Calendar } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import type { Child } from '../types';
import Button from '../components/Button';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import SponsorshipForm from '../components/SponsorshipForm';

const ChildDetails: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [child, setChild] = useState<Child | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showSponsorshipForm, setShowSponsorshipForm] = useState(false);

  useEffect(() => {
    if (id) {
      fetchChildDetails();
    }
  }, [id]);

  const fetchChildDetails = async () => {
    try {
      const { data, error } = await supabase
        .from('children')
        .select(`
          *,
          sponsor:sponsors (
            id,
            name,
            is_anonymous,
            facebook_url
          )
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      setChild(data);
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des détails');
    } finally {
      setLoading(false);
    }
  };

  const handleShare = async () => {
    if (!child) return;

    const shareData = {
      title: `${child.name} - Profil de parrainage`,
      text: `Découvrez le profil de ${child.name} et comment vous pouvez aider.`,
      url: window.location.href
    };

    try {
      if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(window.location.href);
        toast.success('Lien copié dans le presse-papiers');
      }
    } catch (err) {
      if (err instanceof Error && err.name !== 'AbortError') {
        console.error('Error sharing:', err);
        try {
          await navigator.clipboard.writeText(window.location.href);
          toast.success('Lien copié dans le presse-papiers');
        } catch (clipboardErr) {
          console.error('Clipboard error:', clipboardErr);
          toast.error('Impossible de partager ou copier le lien');
        }
      }
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;
  if (!child) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto px-4 py-8"
    >
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="relative h-96">
            <img
              src={child.image_url || 'https://via.placeholder.com/800x600?text=Photo+non+disponible'}
              alt={child.name}
              className="w-full h-full object-cover"
            />
            {child.is_sponsored && (
              <div className="absolute top-4 right-4 bg-green-500 text-white px-4 py-2 rounded-full">
                Parrainé
              </div>
            )}
          </div>
          
          <div className="p-6">
            <h1 className="text-3xl font-bold mb-4">{child.name}</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="flex items-center">
                <Calendar className="w-5 h-5 text-gray-500 mr-2" />
                <span>
                  {child.age} ans
                  {child.birthday && (
                    <span className="ml-1">
                      (né{child.gender === 'female' ? 'e' : ''} le {new Date(child.birthday).toLocaleDateString()})
                    </span>
                  )}
                </span>
              </div>
              <div className="flex items-center">
                <MapPin className="w-5 h-5 text-gray-500 mr-2" />
                <span>{child.city}</span>
              </div>
            </div>

            {!child.is_sponsored ? (
              <Button
                variant="primary"
                icon={Heart}
                onClick={() => setShowSponsorshipForm(true)}
                fullWidth
              >
                Parrainer {child.name}
              </Button>
            ) : child.sponsor && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-700">
                  {child.name} est parrainé{child.gender === 'female' ? 'e' : ''} par{' '}
                  {child.sponsor.is_anonymous ? (
                    'un parrain anonyme'
                  ) : child.sponsor.facebook_url ? (
                    <a
                      href={child.sponsor.facebook_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      {child.sponsor.name}
                    </a>
                  ) : (
                    child.sponsor.name
                  )}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {showSponsorshipForm && child && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <SponsorshipForm
            child={child}
            onClose={() => setShowSponsorshipForm(false)}
            onSuccess={() => {
              setShowSponsorshipForm(false);
              fetchChildDetails();
            }}
          />
        </div>
      )}
    </motion.div>
  );
};

export default ChildDetails;