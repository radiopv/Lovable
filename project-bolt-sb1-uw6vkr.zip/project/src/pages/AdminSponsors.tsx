import React, { useState, useEffect } from 'react';
import { Search, Edit2, Trash2, Eye, ArrowUp, ArrowDown, Download } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import type { Sponsor, Child } from '../types';
import Button from '../components/Button';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import EditSponsorModal from '../components/EditSponsorModal';
import SponsorDetailsModal from '../components/SponsorDetailsModal';

interface SponsorWithChildren extends Sponsor {
  children: Child[];
}

type SortField = 'name' | 'email' | 'children_count' | 'created_at' | 'status';
type SortDirection = 'asc' | 'desc';

const AdminSponsors: React.FC = () => {
  const [sponsors, setSponsors] = useState<SponsorWithChildren[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSponsor, setSelectedSponsor] = useState<SponsorWithChildren | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [sortField, setSortField] = useState<SortField>('created_at');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [filters, setFilters] = useState({
    status: 'all',
    hasChildren: 'all',
    dateRange: 'all'
  });

  useEffect(() => {
    fetchSponsors();
  }, []);

  const fetchSponsors = async () => {
    try {
      const { data, error: sponsorsError } = await supabase
        .from('sponsors')
        .select(`
          *,
          children:children(*)
        `);

      if (sponsorsError) throw sponsorsError;
      setSponsors(data || []);
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des parrains');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (sponsorId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce parrain ?')) return;

    try {
      const { error: deleteError } = await supabase
        .from('sponsors')
        .delete()
        .eq('id', sponsorId);

      if (deleteError) throw deleteError;
      
      toast.success('Parrain supprimé avec succès');
      fetchSponsors();
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de la suppression');
    }
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleExport = () => {
    const exportData = filteredSponsors.map(sponsor => ({
      name: sponsor.name,
      email: sponsor.email,
      children_count: sponsor.children.length,
      registration_date: new Date(sponsor.created_at).toLocaleDateString(),
      status: sponsor.children.length > 0 ? 'Actif' : 'Inactif'
    }));

    const csv = [
      ['Nom', 'Email', 'Enfants parrainés', 'Date d\'inscription', 'Statut'],
      ...exportData.map(row => Object.values(row))
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'parrains.csv';
    link.click();
  };

  const filteredSponsors = sponsors.filter(sponsor => {
    const matchesSearch = 
      sponsor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sponsor.email.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = filters.status === 'all' ? true :
      filters.status === 'active' ? sponsor.children.length > 0 :
      sponsor.children.length === 0;

    const matchesChildren = filters.hasChildren === 'all' ? true :
      filters.hasChildren === 'yes' ? sponsor.children.length > 0 :
      sponsor.children.length === 0;

    const matchesDate = filters.dateRange === 'all' ? true :
      filters.dateRange === 'month' ? 
        new Date(sponsor.created_at) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) :
      filters.dateRange === 'year' ?
        new Date(sponsor.created_at) > new Date(Date.now() - 365 * 24 * 60 * 60 * 1000) :
        true;

    return matchesSearch && matchesStatus && matchesChildren && matchesDate;
  }).sort((a, b) => {
    let comparison = 0;
    switch (sortField) {
      case 'name':
        comparison = a.name.localeCompare(b.name);
        break;
      case 'email':
        comparison = a.email.localeCompare(b.email);
        break;
      case 'children_count':
        comparison = a.children.length - b.children.length;
        break;
      case 'created_at':
        comparison = new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
        break;
      case 'status':
        comparison = (b.children.length > 0 ? 1 : 0) - (a.children.length > 0 ? 1 : 0);
        break;
    }
    return sortDirection === 'asc' ? comparison : -comparison;
  });

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="space-y-4">
      {/* En-tête avec titre et actions */}
      <div className="sticky top-0 bg-white z-10 p-4 shadow-md rounded-lg">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <h1 className="text-2xl font-bold">Gestion des Parrains</h1>
          <div className="flex flex-wrap items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Rechercher un parrain..."
                className="w-64 pl-10 pr-4 py-2 border rounded-lg"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button
              variant="secondary"
              icon={Download}
              onClick={handleExport}
            >
              Exporter
            </Button>
          </div>
        </div>

        {/* Filtres */}
        <div className="flex flex-wrap gap-4 mt-4">
          <select
            className="px-3 py-2 border rounded-lg"
            value={filters.status}
            onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
          >
            <option value="all">Tous les statuts</option>
            <option value="active">Actifs</option>
            <option value="inactive">Inactifs</option>
          </select>

          <select
            className="px-3 py-2 border rounded-lg"
            value={filters.hasChildren}
            onChange={(e) => setFilters(prev => ({ ...prev, hasChildren: e.target.value }))}
          >
            <option value="all">Tous les parrainages</option>
            <option value="yes">Avec enfants</option>
            <option value="no">Sans enfants</option>
          </select>

          <select
            className="px-3 py-2 border rounded-lg"
            value={filters.dateRange}
            onChange={(e) => setFilters(prev => ({ ...prev, dateRange: e.target.value }))}
          >
            <option value="all">Toutes les dates</option>
            <option value="month">Dernier mois</option>
            <option value="year">Dernière année</option>
          </select>
        </div>
      </div>

      {/* Tableau des parrains */}
      <div className="bg-white rounded-lg shadow overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer whitespace-nowrap"
                onClick={() => handleSort('name')}
              >
                <div className="flex items-center">
                  Nom
                  {sortField === 'name' && (
                    sortDirection === 'asc' ? 
                      <ArrowUp className="w-4 h-4 ml-1" /> : 
                      <ArrowDown className="w-4 h-4 ml-1" />
                  )}
                </div>
              </th>
              <th 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer whitespace-nowrap"
                onClick={() => handleSort('email')}
              >
                <div className="flex items-center">
                  Email
                  {sortField === 'email' && (
                    sortDirection === 'asc' ? 
                      <ArrowUp className="w-4 h-4 ml-1" /> : 
                      <ArrowDown className="w-4 h-4 ml-1" />
                  )}
                </div>
              </th>
              <th 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer whitespace-nowrap"
                onClick={() => handleSort('children_count')}
              >
                <div className="flex items-center">
                  Enfants parrainés
                  {sortField === 'children_count' && (
                    sortDirection === 'asc' ? 
                      <ArrowUp className="w-4 h-4 ml-1" /> : 
                      <ArrowDown className="w-4 h-4 ml-1" />
                  )}
                </div>
              </th>
              <th 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer whitespace-nowrap"
                onClick={() => handleSort('created_at')}
              >
                <div className="flex items-center">
                  Date d'inscription
                  {sortField === 'created_at' && (
                    sortDirection === 'asc' ? 
                      <ArrowUp className="w-4 h-4 ml-1" /> : 
                      <ArrowDown className="w-4 h-4 ml-1" />
                  )}
                </div>
              </th>
              <th 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer whitespace-nowrap"
                onClick={() => handleSort('status')}
              >
                <div className="flex items-center">
                  Statut
                  {sortField === 'status' && (
                    sortDirection === 'asc' ? 
                      <ArrowUp className="w-4 h-4 ml-1" /> : 
                      <ArrowDown className="w-4 h-4 ml-1" />
                  )}
                </div>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredSponsors.map((sponsor) => (
              <tr key={sponsor.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="text-sm font-medium text-gray-900">
                      {sponsor.name}
                      {sponsor.is_anonymous && (
                        <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
                          Anonyme
                        </span>
                      )}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{sponsor.email}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{sponsor.children.length}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">
                    {new Date(sponsor.created_at).toLocaleDateString()}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                    sponsor.children.length > 0 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {sponsor.children.length > 0 ? 'Actif' : 'Inactif'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <div className="flex items-center gap-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      icon={Eye}
                      onClick={() => {
                        setSelectedSponsor(sponsor);
                        setShowDetailsModal(true);
                      }}
                    >
                      Détails
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      icon={Edit2}
                      onClick={() => {
                        setSelectedSponsor(sponsor);
                        setShowEditModal(true);
                      }}
                    >
                      Modifier
                    </Button>
                    <Button
                      variant="danger"
                      size="sm"
                      icon={Trash2}
                      onClick={() => handleDelete(sponsor.id)}
                    >
                      Supprimer
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Message si aucun résultat */}
      {filteredSponsors.length === 0 && (
        <div className="text-center py-8 bg-white rounded-lg shadow">
          <p className="text-gray-500">Aucun parrain trouvé</p>
        </div>
      )}

      {/* Modales */}
      {showEditModal && selectedSponsor && (
        <EditSponsorModal
          sponsor={selectedSponsor}
          onClose={() => {
            setShowEditModal(false);
            setSelectedSponsor(null);
          }}
          onSuccess={() => {
            setShowEditModal(false);
            setSelectedSponsor(null);
            fetchSponsors();
          }}
        />
      )}

      {showDetailsModal && selectedSponsor && (
        <SponsorDetailsModal
          sponsor={selectedSponsor}
          onClose={() => {
            setShowDetailsModal(false);
            setSelectedSponsor(null);
          }}
          onSponsorshipUpdate={fetchSponsors}
        />
      )}
    </div>
  );
};

export default AdminSponsors;