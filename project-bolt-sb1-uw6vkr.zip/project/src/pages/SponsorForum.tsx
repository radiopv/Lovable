import React, { useState, useEffect } from 'react';
import { Plus, MessageCircle, AlertTriangle, Plane, Package } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import NewForumPostModal from '../components/NewForumPostModal';
import NewTravelAnnouncementModal from '../components/NewTravelAnnouncementModal';

interface ForumPost {
  id: string;
  title: string;
  content: string;
  category: string;
  is_urgent: boolean;
  created_at: string;
  sponsor: {
    name: string;
    is_anonymous: boolean;
  };
  replies: {
    id: string;
    content: string;
    created_at: string;
    sponsor: {
      name: string;
      is_anonymous: boolean;
    };
  }[];
}

interface TravelAnnouncement {
  id: string;
  departure_date: string;
  return_date: string;
  destination: string;
  available_space: string;
  notes?: string;
  sponsor: {
    name: string;
    is_anonymous: boolean;
  };
  transport_requests: {
    id: string;
    sponsor: {
      name: string;
    };
    child: {
      name: string;
    };
    items: string;
    status: string;
  }[];
}

const CATEGORIES = {
  vetement: 'Vêtements',
  nourriture: 'Nourriture',
  medicament: 'Médicaments',
  jouet: 'Jouets',
  education: 'Éducation',
  voyage: 'Voyages à Cuba',
  autre: 'Autres'
};

const SponsorForum = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [posts, setPosts] = useState<ForumPost[]>([]);
  const [travels, setTravels] = useState<TravelAnnouncement[]>([]);
  const [showNewPostModal, setShowNewPostModal] = useState(false);
  const [showNewTravelModal, setShowNewTravelModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Récupérer les discussions
      const { data: postsData, error: postsError } = await supabase
        .from('forum_posts')
        .select(`
          *,
          sponsor:sponsors(name, is_anonymous),
          replies:forum_replies(
            id,
            content,
            created_at,
            sponsor:sponsors(name, is_anonymous)
          )
        `)
        .order('created_at', { ascending: false });

      if (postsError) throw postsError;
      setPosts(postsData || []);

      // Récupérer les annonces de voyage
      const { data: travelsData, error: travelsError } = await supabase
        .from('travel_announcements')
        .select(`
          *,
          sponsor:sponsors(name, is_anonymous),
          transport_requests(
            id,
            sponsor:sponsors(name),
            child:children(name),
            items,
            status
          )
        `)
        .eq('is_active', true)
        .order('departure_date', { ascending: true });

      if (travelsError) throw travelsError;
      setTravels(travelsData || []);
    } catch (err) {
      console.error('Erreur:', err);
      setError('Erreur lors du chargement des données');
    } finally {
      setLoading(false);
    }
  };

  const handleRequestTransport = async (travelId: string) => {
    const sponsorData = localStorage.getItem('sponsor');
    if (!sponsorData) {
      toast.error('Vous devez être connecté pour faire une demande');
      return;
    }

    const items = prompt('Que souhaitez-vous faire transporter ?');
    if (!items) return;

    try {
      const sponsor = JSON.parse(sponsorData);
      const { error } = await supabase
        .from('transport_requests')
        .insert({
          travel_id: travelId,
          sponsor_id: sponsor.id,
          items
        });

      if (error) throw error;

      toast.success('Demande envoyée avec succès');
      fetchData();
    } catch (err) {
      console.error('Erreur:', err);
      toast.error('Erreur lors de l\'envoi de la demande');
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  const filteredPosts = selectedCategory
    ? posts.filter(post => post.category === selectedCategory)
    : posts;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Forum des Parrains</h1>
        <div className="flex gap-4">
          <button
            onClick={() => setShowNewTravelModal(true)}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Plane className="w-5 h-5 mr-2" />
            Je vais à Cuba
          </button>
          <button
            onClick={() => setShowNewPostModal(true)}
            className="inline-flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
          >
            <Plus className="w-5 h-5 mr-2" />
            Nouvelle Discussion
          </button>
        </div>
      </div>

      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        <button
          onClick={() => setSelectedCategory(null)}
          className={`px-4 py-2 rounded-full ${
            selectedCategory === null
              ? 'bg-red-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          Tout
        </button>
        {Object.entries(CATEGORIES).map(([key, label]) => (
          <button
            key={key}
            onClick={() => setSelectedCategory(key)}
            className={`px-4 py-2 rounded-full whitespace-nowrap ${
              selectedCategory === key
                ? 'bg-red-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {selectedCategory === 'voyage' && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Voyages à venir</h2>
          <div className="space-y-4">
            {travels.map((travel) => (
              <div key={travel.id} className="bg-white rounded-lg shadow-md p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-semibold">
                      Voyage à {travel.destination}
                    </h3>
                    <p className="text-gray-600">
                      Du {new Date(travel.departure_date).toLocaleDateString()} au{' '}
                      {new Date(travel.return_date).toLocaleDateString()}
                    </p>
                    <p className="text-gray-600">
                      Par {travel.sponsor.is_anonymous ? 'Parrain anonyme' : travel.sponsor.name}
                    </p>
                    <p className="mt-2">
                      <strong>Espace disponible :</strong> {travel.available_space}
                    </p>
                    {travel.notes && (
                      <p className="mt-2 text-gray-700">{travel.notes}</p>
                    )}
                  </div>
                  <button
                    onClick={() => handleRequestTransport(travel.id)}
                    className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                  >
                    <Package className="w-5 h-5 mr-2" />
                    Demander un transport
                  </button>
                </div>

                {travel.transport_requests.length > 0 && (
                  <div className="mt-4 border-t pt-4">
                    <h4 className="font-semibold mb-2">Demandes de transport :</h4>
                    <ul className="space-y-2">
                      {travel.transport_requests.map((request) => (
                        <li key={request.id} className="text-sm text-gray-600">
                          {request.sponsor.name} pour {request.child.name} : {request.items}
                          <span className="ml-2 px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">
                            {request.status}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-6">
        {filteredPosts.map((post) => (
          <div key={post.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-700">
                      {CATEGORIES[post.category as keyof typeof CATEGORIES]}
                    </span>
                    {post.is_urgent && (
                      <span className="px-3 py-1 rounded-full text-sm bg-red-100 text-red-700">
                        Urgent
                      </span>
                    )}
                  </div>
                  <h2 className="text-xl font-semibold">{post.title}</h2>
                  <p className="text-gray-500 text-sm mt-1">
                    Par {post.sponsor.is_anonymous ? 'Parrain anonyme' : post.sponsor.name} le{' '}
                    {new Date(post.created_at).toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                  </p>
                </div>
              </div>

              <div className="mt-4 text-gray-700">{post.content}</div>

              {/* Reste du code pour les réponses... */}
            </div>
          </div>
        ))}
      </div>

      {showNewPostModal && (
        <NewForumPostModal
          onClose={() => setShowNewPostModal(false)}
          onSuccess={() => {
            setShowNewPostModal(false);
            fetchData();
          }}
        />
      )}

      {showNewTravelModal && (
        <NewTravelAnnouncementModal
          onClose={() => setShowNewTravelModal(false)}
          onSuccess={() => {
            setShowNewTravelModal(false);
            fetchData();
          }}
        />
      )}
    </div>
  );
};

export default SponsorForum;