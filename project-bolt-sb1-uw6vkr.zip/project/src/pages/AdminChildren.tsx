import React, { useState, useEffect } from 'react';
import { Plus, Filter } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import type { Child } from '../types';
import Button from '../components/Button';
import AddEditChildModal from '../components/AddEditChildModal';
import ChildDetailsModal from '../components/ChildDetailsModal';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import SearchBar from '../components/SearchBar';
import ChildrenFilters from '../components/ChildrenFilters';
import ChildCard from '../components/ChildCard';

const AdminChildren: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [children, setChildren] = useState<Child[]>([]);
  const [selectedChild, setSelectedChild] = useState<Child | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    city: '',
    minAge: '',
    maxAge: '',
    gender: '',
    isSponsored: ''
  });

  useEffect(() => {
    fetchChildren();
  }, []);

  const fetchChildren = async () => {
    try {
      const { data, error } = await supabase
        .from('children')
        .select(`
          *,
          sponsor:sponsors (
            id,
            name,
            email,
            is_anonymous
          ),
          needs (
            category,
            description,
            priority,
            is_urgent
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setChildren(data || []);
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des enfants');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (childId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cet enfant ?')) return;

    try {
      const { error } = await supabase
        .from('children')
        .delete()
        .eq('id', childId);

      if (error) throw error;
      
      toast.success('Enfant supprimé avec succès');
      setChildren(prev => prev.filter(child => child.id !== childId));
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de la suppression');
    }
  };

  const resetFilters = () => {
    setFilters({
      city: '',
      minAge: '',
      maxAge: '',
      gender: '',
      isSponsored: ''
    });
  };

  const filteredChildren = children.filter(child => {
    const matchesSearch = child.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         child.city.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCity = !filters.city || child.city === filters.city;
    const matchesAge = (!filters.minAge || child.age >= parseInt(filters.minAge)) &&
                      (!filters.maxAge || child.age <= parseInt(filters.maxAge));
    const matchesGender = !filters.gender || child.gender === filters.gender;
    const matchesSponsored = !filters.isSponsored || 
                            (filters.isSponsored === 'true' ? child.is_sponsored : !child.is_sponsored);

    return matchesSearch && matchesCity && matchesAge && matchesGender && matchesSponsored;
  });

  const cities = Array.from(new Set(children.map(child => child.city))).sort();

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Gestion des enfants</h1>
        <div className="flex items-center gap-4">
          <SearchBar
            value={searchTerm}
            onChange={setSearchTerm}
            placeholder="Rechercher un enfant..."
          />
          <Button
            variant="secondary"
            icon={Filter}
            onClick={() => setShowFilters(!showFilters)}
          >
            Filtres
          </Button>
          <Button
            variant="primary"
            icon={Plus}
            onClick={() => setShowAddModal(true)}
          >
            Ajouter
          </Button>
        </div>
      </div>

      {showFilters && (
        <ChildrenFilters
          filters={filters}
          onFilterChange={setFilters}
          onReset={resetFilters}
          cities={cities}
        />
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredChildren.map((child) => (
          <ChildCard
            key={child.id}
            child={child}
            showSponsorInfo
            onView={() => {
              setSelectedChild(child);
              setShowDetailsModal(true);
            }}
            onEdit={() => {
              setSelectedChild(child);
              setShowAddModal(true);
            }}
            onDelete={() => handleDelete(child.id)}
          />
        ))}
      </div>

      {filteredChildren.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <p className="text-gray-600">Aucun enfant trouvé</p>
        </div>
      )}

      {(showAddModal || selectedChild) && (
        <AddEditChildModal
          child={selectedChild}
          onClose={() => {
            setShowAddModal(false);
            setSelectedChild(null);
          }}
          onSuccess={() => {
            setShowAddModal(false);
            setSelectedChild(null);
            fetchChildren();
          }}
        />
      )}

      {showDetailsModal && selectedChild && (
        <ChildDetailsModal
          child={selectedChild}
          onClose={() => {
            setShowDetailsModal(false);
            setSelectedChild(null);
          }}
          onEdit={() => {
            setShowDetailsModal(false);
            setShowAddModal(true);
          }}
          onDelete={() => {
            setShowDetailsModal(false);
            setSelectedChild(null);
            handleDelete(selectedChild.id);
          }}
        />
      )}
    </div>
  );
};

export default AdminChildren;