import React, { useState, useEffect } from 'react';
import { Search, Calendar, User, Trash2, Plus } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import type { Memory } from '../types';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import Button from '../components/Button';
import AddAdminMemoryModal from '../components/AddAdminMemoryModal';

interface ArchivedSponsorship {
  id: string;
  child_id: string;
  sponsor_id: string;
  start_date: string;
  end_date: string;
  child_name: string;
  child_image_url: string;
  sponsor_name: string;
  sponsor_is_anonymous: boolean;
  memories: Memory[];
}

const SponsorshipArchives: React.FC = () => {
  const [archives, setArchives] = useState<ArchivedSponsorship[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedChild, setSelectedChild] = useState<any>(null);
  const [showMemoryModal, setShowMemoryModal] = useState(false);

  useEffect(() => {
    fetchArchives();
  }, []);

  const fetchArchives = async () => {
    try {
      const { data, error } = await supabase
        .from('sponsorship_archives_view')
        .select('*')
        .order('end_date', { ascending: false });

      if (error) throw error;
      setArchives(data || []);
    } catch (err) {
      console.error('Erreur:', err);
      setError('Erreur lors du chargement des archives');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteArchive = async (archiveId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette archive ? Cette action est irréversible.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('sponsorship_archives')
        .delete()
        .eq('id', archiveId);

      if (error) throw error;

      toast.success('Archive supprimée avec succès');
      fetchArchives();
    } catch (err) {
      console.error('Erreur:', err);
      toast.error('Erreur lors de la suppression de l\'archive');
    }
  };

  const handleAddMemory = (archive: ArchivedSponsorship) => {
    setSelectedChild({
      id: archive.child_id,
      name: archive.child_name,
      sponsor_id: archive.sponsor_id,
      image_url: archive.child_image_url
    });
    setShowMemoryModal(true);
  };

  const filteredArchives = archives.filter(archive =>
    archive.child_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (!archive.sponsor_is_anonymous && archive.sponsor_name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Archives des Parrainages</h1>
        <div className="relative w-64">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Rechercher..."
            className="w-full pl-10 pr-4 py-2 border rounded-lg"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {filteredArchives.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <p className="text-gray-600">Aucune archive trouvée</p>
        </div>
      ) : (
        <div className="grid gap-6">
          {filteredArchives.map((archive) => (
            <div key={archive.id} className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="text-xl font-semibold mb-2">{archive.child_name}</h2>
                    <div className="flex items-center text-gray-600 mb-4">
                      <Calendar className="w-4 h-4 mr-2" />
                      <span>
                        Du {new Date(archive.start_date).toLocaleDateString()} au{' '}
                        {new Date(archive.end_date).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-gray-600">
                      <User className="w-4 h-4 inline mr-2" />
                      Parrainé par {archive.sponsor_is_anonymous ? 'un parrain anonyme' : archive.sponsor_name}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      icon={Plus}
                      onClick={() => handleAddMemory(archive)}
                    >
                      Ajouter un souvenir
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      icon={Trash2}
                      onClick={() => handleDeleteArchive(archive.id)}
                      className="text-red-600"
                    >
                      Supprimer
                    </Button>
                  </div>
                </div>

                {archive.memories && archive.memories.length > 0 && (
                  <div className="mt-6">
                    <h3 className="text-lg font-semibold mb-4">Souvenirs partagés</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                      {archive.memories.map((memory) => (
                        <div key={memory.id} className="relative">
                          <img
                            src={memory.image_url}
                            alt="Souvenir"
                            className="w-full h-32 object-cover rounded-lg"
                          />
                          {memory.description && (
                            <div className="absolute inset-0 bg-black bg-opacity-50 rounded-lg opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                              <p className="text-white text-sm p-2 text-center">
                                {memory.description}
                              </p>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {showMemoryModal && selectedChild && (
        <AddAdminMemoryModal
          child={selectedChild}
          onClose={() => setShowMemoryModal(false)}
          onSuccess={() => {
            setShowMemoryModal(false);
            fetchArchives();
          }}
        />
      )}
    </div>
  );
};

export default SponsorshipArchives;