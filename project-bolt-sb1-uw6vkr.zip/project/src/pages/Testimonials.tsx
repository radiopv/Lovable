import React, { useState, useEffect } from 'react';
import { Heart, Search } from 'lucide-react';
import { supabase } from '../lib/supabase';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';

const Testimonials = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [testimonials, setTestimonials] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchTestimonials();
  }, []);

  const fetchTestimonials = async () => {
    try {
      const { data, error } = await supabase
        .from('testimonials')
        .select(`
          id,
          message,
          created_at,
          sponsor:sponsors(name, is_anonymous),
          child:children(name)
        `)
        .eq('is_approved', true)
        .eq('is_published', true)
        .eq('is_hidden', false)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTestimonials(data || []);
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des témoignages');
    } finally {
      setLoading(false);
    }
  };

  const filteredTestimonials = testimonials.filter(testimonial =>
    testimonial.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
    testimonial.child.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (!testimonial.sponsor.is_anonymous && 
     testimonial.sponsor.name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Témoignages</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Découvrez les histoires touchantes de nos parrains et leur impact sur la vie des enfants
        </p>
      </div>

      <div className="mb-8">
        <div className="relative max-w-md mx-auto">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Rechercher dans les témoignages..."
            className="w-full pl-10 pr-4 py-2 border rounded-lg"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredTestimonials.map((testimonial) => (
          <div 
            key={testimonial.id} 
            className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow"
          >
            <div className="flex items-start mb-4">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                  <Heart className="w-5 h-5 text-red-600" />
                </div>
              </div>
              <div className="ml-4">
                <p className="text-gray-900 font-semibold">
                  {testimonial.sponsor.is_anonymous ? 'Parrain anonyme' : testimonial.sponsor.name}
                </p>
                <p className="text-sm text-gray-500">
                  Parrain de {testimonial.child.name}
                </p>
                <p className="text-xs text-gray-400">
                  {new Date(testimonial.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>
            <blockquote className="text-gray-700 italic">
              "{testimonial.message}"
            </blockquote>
          </div>
        ))}
      </div>

      {filteredTestimonials.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          Aucun témoignage ne correspond à votre recherche
        </div>
      )}
    </div>
  );
};

export default Testimonials;