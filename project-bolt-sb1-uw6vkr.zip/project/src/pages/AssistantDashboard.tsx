import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, Edit2 } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import type { Child } from '../types';
import Button from '../components/Button';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import AddEditChildModal from '../components/AddEditChildModal';

const AssistantDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [children, setChildren] = useState<Child[]>([]);
  const [selectedChild, setSelectedChild] = useState<Child | null>(null);
  const [showAddChildModal, setShowAddChildModal] = useState(false);

  useEffect(() => {
    fetchChildren();
  }, []);

  const fetchChildren = async () => {
    try {
      const { data, error } = await supabase
        .from('children')
        .select(`
          *,
          sponsor:sponsors (
            id,
            name,
            facebook_url,
            is_anonymous
          )
        `)
        .order('name', { ascending: true });

      if (error) throw error;
      setChildren(data || []);
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des enfants');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('adminAuthenticated');
    navigate('/admin/login');
  };

  const handleEditClick = (child: Child) => {
    setSelectedChild(child);
    setShowAddChildModal(true);
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <h1 className="text-xl font-bold text-gray-900">
            Gestion des enfants
          </h1>

          <Button
            variant="secondary"
            icon={LogOut}
            onClick={handleLogout}
          >
            Déconnexion
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {children.map((child) => (
            <div key={child.id} className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="relative h-48">
                <img
                  src={child.image_url}
                  alt={child.name}
                  className="w-full h-full object-cover"
                />
                {child.is_sponsored && (
                  <div className="absolute top-2 right-2 bg-green-500 text-white px-3 py-1 rounded-full text-sm">
                    Parrainé
                  </div>
                )}
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold mb-2">{child.name}</h3>
                <p className="text-gray-600">
                  {child.age} ans - {child.city}
                </p>
                {child.sponsor && (
                  <div className="mt-2 text-sm text-gray-600">
                    <p>
                      Parrain: {' '}
                      {child.sponsor.is_anonymous ? 
                        'Parrain anonyme' :
                        child.sponsor.facebook_url ? (
                          <button
                            onClick={() => window.open(child.sponsor.facebook_url!, '_blank')}
                            className="text-blue-600 hover:underline"
                          >
                            {child.sponsor.name}
                          </button>
                        ) : child.sponsor.name
                      }
                    </p>
                  </div>
                )}
                <div className="mt-4 flex gap-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    icon={Edit2}
                    onClick={() => handleEditClick(child)}
                  >
                    Modifier
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {children.length === 0 && (
          <div className="text-center py-12 bg-white rounded-lg shadow">
            <p className="text-gray-600">Aucun enfant trouvé</p>
          </div>
        )}

        {(showAddChildModal || selectedChild) && (
          <AddEditChildModal
            child={selectedChild}
            onClose={() => {
              setShowAddChildModal(false);
              setSelectedChild(null);
            }}
            onSuccess={() => {
              setShowAddChildModal(false);
              setSelectedChild(null);
              fetchChildren();
            }}
          />
        )}
      </div>
    </div>
  );
};

export default AssistantDashboard;