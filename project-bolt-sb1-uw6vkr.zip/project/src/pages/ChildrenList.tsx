import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Child } from '../types';
import Button from '../components/Button';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import SearchBar from '../components/SearchBar';
import ChildCard from '../components/ChildCard';

const ChildrenList: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [children, setChildren] = useState<Child[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchChildren();
  }, []);

  const fetchChildren = async () => {
    try {
      const { data, error } = await supabase
        .from('children')
        .select(`
          *,
          needs (
            category,
            description,
            priority,
            is_urgent
          )
        `)
        .eq('is_sponsored', false)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setChildren(data || []);
    } catch (err) {
      console.error('Error fetching children:', err);
      setError('Erreur lors du chargement des enfants');
    } finally {
      setLoading(false);
    }
  };

  const filteredChildren = children.filter(child =>
    child.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    child.city.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Enfants à parrainer</h1>
        <SearchBar
          value={searchTerm}
          onChange={setSearchTerm}
          placeholder="Rechercher un enfant..."
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredChildren.map((child) => (
          <ChildCard key={child.id} child={child} />
        ))}
      </div>

      {filteredChildren.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          Aucun enfant disponible pour le moment
        </div>
      )}
    </div>
  );
};

export default ChildrenList;