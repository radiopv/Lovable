import React, { useState, useEffect } from 'react';
import { Check, X, Eye, EyeOff, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import Button from '../components/Button';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';

interface Testimonial {
  id: string;
  sponsor_id: string;
  child_id: string;
  message: string;
  is_approved: boolean;
  is_published: boolean;
  is_hidden: boolean;
  created_at: string;
  sponsor: {
    name: string;
    is_anonymous: boolean;
  };
  child: {
    name: string;
  };
}

const AdminTestimonials: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'hidden'>('all');

  useEffect(() => {
    fetchTestimonials();
  }, []);

  const fetchTestimonials = async () => {
    try {
      const { data, error } = await supabase
        .from('testimonials')
        .select(`
          *,
          sponsor:sponsors(name, is_anonymous),
          child:children(name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTestimonials(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des témoignages');
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (id: string, approve: boolean) => {
    try {
      const { error } = await supabase
        .from('testimonials')
        .update({
          is_approved: approve,
          is_published: approve,
          is_hidden: false
        })
        .eq('id', id);

      if (error) throw error;

      setTestimonials(prev => prev.map(testimonial => 
        testimonial.id === id 
          ? { ...testimonial, is_approved: approve, is_published: approve, is_hidden: false }
          : testimonial
      ));

      toast.success(approve ? 'Témoignage approuvé' : 'Témoignage rejeté');
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de la mise à jour du témoignage');
    }
  };

  const handleVisibility = async (id: string, hide: boolean) => {
    try {
      const { error } = await supabase
        .from('testimonials')
        .update({ is_hidden: hide })
        .eq('id', id);

      if (error) throw error;

      setTestimonials(prev => prev.map(testimonial => 
        testimonial.id === id 
          ? { ...testimonial, is_hidden: hide }
          : testimonial
      ));

      toast.success(hide ? 'Témoignage masqué' : 'Témoignage visible');
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de la mise à jour de la visibilité');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce témoignage ?')) return;

    try {
      const { error } = await supabase
        .from('testimonials')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setTestimonials(prev => prev.filter(t => t.id !== id));
      toast.success('Témoignage supprimé');
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de la suppression');
    }
  };

  const filteredTestimonials = testimonials.filter(testimonial => {
    switch (filter) {
      case 'pending':
        return !testimonial.is_approved;
      case 'approved':
        return testimonial.is_approved && !testimonial.is_hidden;
      case 'hidden':
        return testimonial.is_hidden;
      default:
        return true;
    }
  });

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Gestion des témoignages</h1>
        <div className="flex gap-2">
          <select
            className="px-3 py-2 border rounded-lg"
            value={filter}
            onChange={(e) => setFilter(e.target.value as typeof filter)}
          >
            <option value="all">Tous</option>
            <option value="pending">En attente</option>
            <option value="approved">Approuvés</option>
            <option value="hidden">Masqués</option>
          </select>
        </div>
      </div>

      <div className="space-y-4">
        {filteredTestimonials.map((testimonial) => (
          <div 
            key={testimonial.id} 
            className={`bg-white p-6 rounded-lg shadow-md ${
              !testimonial.is_approved ? 'border-l-4 border-yellow-500' :
              testimonial.is_hidden ? 'opacity-50' : ''
            }`}
          >
            <div className="flex justify-between items-start">
              <div>
                <p className="font-semibold">
                  {testimonial.sponsor.is_anonymous ? 'Parrain anonyme' : testimonial.sponsor.name}
                </p>
                <p className="text-sm text-gray-500">
                  Pour {testimonial.child.name} - {new Date(testimonial.created_at).toLocaleDateString()}
                </p>
              </div>
              <div className="flex gap-2">
                {!testimonial.is_approved ? (
                  <>
                    <Button
                      variant="secondary"
                      size="sm"
                      icon={Check}
                      onClick={() => handleApprove(testimonial.id, true)}
                      className="text-green-600"
                    >
                      Approuver
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      icon={X}
                      onClick={() => handleApprove(testimonial.id, false)}
                      className="text-red-600"
                    >
                      Rejeter
                    </Button>
                  </>
                ) : (
                  <Button
                    variant="secondary"
                    size="sm"
                    icon={testimonial.is_hidden ? Eye : EyeOff}
                    onClick={() => handleVisibility(testimonial.id, !testimonial.is_hidden)}
                  >
                    {testimonial.is_hidden ? 'Afficher' : 'Masquer'}
                  </Button>
                )}
                <Button
                  variant="secondary"
                  size="sm"
                  icon={Trash2}
                  onClick={() => handleDelete(testimonial.id)}
                  className="text-red-600"
                >
                  Supprimer
                </Button>
              </div>
            </div>
            <p className="mt-4">{testimonial.message}</p>
          </div>
        ))}

        {filteredTestimonials.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            Aucun témoignage trouvé
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminTestimonials;