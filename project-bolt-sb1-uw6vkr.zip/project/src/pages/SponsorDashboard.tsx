import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, Heart, Settings, Upload } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import type { Child, Memory } from '../types';
import AddMemoryModal from '../components/AddMemoryModal';
import AddTestimonialModal from '../components/AddTestimonialModal';
import CancelSponsorshipModal from '../components/CancelSponsorshipModal';
import EditSponsorProfileModal from '../components/EditSponsorProfileModal';
import ErrorMessage from '../components/ErrorMessage';
import LoadingSpinner from '../components/LoadingSpinner';
import Button from '../components/Button';

const SponsorDashboard: React.FC = () => {
  const [children, setChildren] = useState<Child[]>([]);
  const [memories, setMemories] = useState<Memory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedChild, setSelectedChild] = useState<Child | null>(null);
  const [showAddMemoryModal, setShowAddMemoryModal] = useState(false);
  const [showAddTestimonialModal, setShowAddTestimonialModal] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const sponsorData = localStorage.getItem('sponsor');
    if (!sponsorData) {
      navigate('/parrain/connexion');
      return;
    }
    const sponsor = JSON.parse(sponsorData);
    fetchSponsoredChildren(sponsor.id);
  }, [navigate]);

  const fetchSponsoredChildren = async (sponsorId: string) => {
    try {
      const { data: sponsoredChildren, error: childrenError } = await supabase
        .from('children')
        .select('*')
        .eq('sponsor_id', sponsorId);

      if (childrenError) throw childrenError;
      setChildren(Array.isArray(sponsoredChildren) ? sponsoredChildren : []);

      if (sponsoredChildren?.length > 0) {
        const { data: childMemories, error: memoriesError } = await supabase
          .from('memories')
          .select('*')
          .eq('sponsor_id', sponsorId)
          .order('created_at', { ascending: false });

        if (memoriesError) throw memoriesError;
        setMemories(Array.isArray(childMemories) ? childMemories : []);
      }
    } catch (err) {
      console.error('Error:', err);
      setError('Erreur lors du chargement des données');
      setChildren([]);
      setMemories([]);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('sponsor');
    navigate('/parrain/connexion');
  };

  const handleCancelSponsorship = (child: Child) => {
    setSelectedChild(child);
    setShowCancelModal(true);
  };

  const handleSponsorshipCancelled = () => {
    setShowCancelModal(false);
    const sponsorData = localStorage.getItem('sponsor');
    if (sponsorData) {
      const sponsor = JSON.parse(sponsorData);
      fetchSponsoredChildren(sponsor.id);
    }
  };

  const deleteMemory = async (memoryId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce souvenir ?')) return;

    try {
      const { error } = await supabase
        .from('memories')
        .delete()
        .eq('id', memoryId);

      if (error) throw error;

      toast.success('Souvenir supprimé avec succès');
      setMemories(prev => prev.filter(m => m.id !== memoryId));
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de la suppression du souvenir');
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Mon Espace Parrain</h1>
        <div className="flex gap-4">
          <Button
            variant="secondary"
            icon={Settings}
            onClick={() => setShowProfileModal(true)}
          >
            Mon profil
          </Button>
          <Button
            variant="secondary"
            icon={LogOut}
            onClick={handleLogout}
          >
            Déconnexion
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Array.isArray(children) && children.map(child => (
          <div key={child.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src={child.image_url || 'https://via.placeholder.com/300x200?text=Photo+non+disponible'}
              alt={child.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h2 className="text-xl font-semibold mb-2">{child.name}</h2>
              <p className="text-gray-600 mb-4">
                {child.age} ans - {child.city}
              </p>
              
              <div className="space-y-3">
                <Button
                  variant="primary"
                  icon={Upload}
                  fullWidth
                  onClick={() => {
                    setSelectedChild(child);
                    setShowAddMemoryModal(true);
                  }}
                >
                  Ajouter un souvenir
                </Button>

                <Button
                  variant="secondary"
                  icon={Heart}
                  fullWidth
                  onClick={() => {
                    setSelectedChild(child);
                    setShowAddTestimonialModal(true);
                  }}
                >
                  Ajouter un témoignage
                </Button>

                <Button
                  variant="danger"
                  icon={Heart}
                  fullWidth
                  onClick={() => handleCancelSponsorship(child)}
                >
                  Planifier la fin du parrainage
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {(!Array.isArray(children) || children.length === 0) && (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <p className="text-gray-600">Vous ne parrainez aucun enfant pour le moment</p>
        </div>
      )}

      {Array.isArray(memories) && memories.length > 0 && (
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Souvenirs partagés</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {memories.map(memory => {
              const child = Array.isArray(children) ? children.find(c => c.id === memory.child_id) : null;
              return (
                <div key={memory.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                  {memory.media_type === 'image' ? (
                    <img
                      src={memory.media_url}
                      alt="Souvenir"
                      className="w-full h-48 object-cover"
                    />
                  ) : (
                    <video
                      src={memory.media_url}
                      className="w-full h-48 object-cover"
                      controls
                    />
                  )}
                  <div className="p-4">
                    {child && (
                      <p className="font-semibold mb-2">{child.name}</p>
                    )}
                    {memory.description && (
                      <p className="text-gray-600 mb-2">{memory.description}</p>
                    )}
                    <p className="text-sm text-gray-500">
                      {new Date(memory.created_at).toLocaleDateString()}
                    </p>
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => deleteMemory(memory.id)}
                      className="mt-2"
                    >
                      Supprimer
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {showAddMemoryModal && selectedChild && (
        <AddMemoryModal
          child={selectedChild}
          sponsorId={JSON.parse(localStorage.getItem('sponsor') || '{}').id}
          onClose={() => {
            setShowAddMemoryModal(false);
            setSelectedChild(null);
          }}
          onSuccess={() => {
            setShowAddMemoryModal(false);
            setSelectedChild(null);
            const sponsorData = localStorage.getItem('sponsor');
            if (sponsorData) {
              const sponsor = JSON.parse(sponsorData);
              fetchSponsoredChildren(sponsor.id);
            }
          }}
        />
      )}

      {showAddTestimonialModal && selectedChild && (
        <AddTestimonialModal
          child={selectedChild}
          sponsorId={JSON.parse(localStorage.getItem('sponsor') || '{}').id}
          onClose={() => setShowAddTestimonialModal(false)}
          onSuccess={() => {
            setShowAddTestimonialModal(false);
            toast.success('Témoignage ajouté avec succès');
          }}
        />
      )}

      {showCancelModal && selectedChild && (
        <CancelSponsorshipModal
          child={selectedChild}
          onClose={() => setShowCancelModal(false)}
          onSuccess={handleSponsorshipCancelled}
        />
      )}

      {showProfileModal && (
        <EditSponsorProfileModal
          sponsor={JSON.parse(localStorage.getItem('sponsor') || '{}')}
          onClose={() => setShowProfileModal(false)}
          onSuccess={() => {
            setShowProfileModal(false);
            toast.success('Profil mis à jour avec succès');
          }}
        />
      )}
    </div>
  );
};

export default SponsorDashboard;