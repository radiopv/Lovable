import { serve } from 'https://deno.fresh.dev/std@0.168.0/http/server.ts';
import { SmtpClient } from 'https://deno.land/x/smtp/mod.ts';

const client = new SmtpClient({
  connection: {
    hostname: "smtp.bluehost.com",
    port: 465,
    tls: true,
    auth: {
      username: "admin@passionvaradero.ca",
      password: "Lechef400.."
    }
  }
});

serve(async (req) => {
  try {
    const { to, subject, html } = await req.json();

    await client.send({
      from: "Parrainage Cuba <admin@passionvaradero.ca>",
      to,
      subject,
      html,
    });

    await client.close();

    return new Response(JSON.stringify({ success: true }), {
      headers: { "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    console.error('Error sending email:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { "Content-Type": "application/json" },
      status: 500,
    });
  }
});