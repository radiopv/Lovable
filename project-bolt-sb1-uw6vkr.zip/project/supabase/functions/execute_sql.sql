-- Create a function to execute SQL queries
create or replace function execute_sql(query text)
returns void as $$
begin
  execute query;
exception
  when others then
    -- Log the error but don't throw it
    raise notice 'Error executing query: %', SQLERRM;
end;
$$ language plpgsql security definer;