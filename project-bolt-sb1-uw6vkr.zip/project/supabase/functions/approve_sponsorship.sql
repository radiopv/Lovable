-- Function to handle sponsorship approval transaction
create or replace function approve_sponsorship(
  request_id uuid,
  child_id uuid,
  sponsor_id uuid
) returns void as $$
begin
  -- Update the sponsorship request status
  update sponsorship_requests
  set status = 'approved',
      updated_at = now()
  where id = request_id;

  -- Update the child's sponsor
  update children
  set sponsor_id = sponsor_id,
      is_sponsored = true,
      updated_at = now()
  where id = child_id;

  -- Update the sponsor's children list
  update sponsors
  set children_sponsored = array_append(children_sponsored, child_id),
      updated_at = now()
  where id = sponsor_id;

  -- Create activity log
  insert into activity_logs (
    type,
    user_id,
    action,
    details,
    created_at
  ) values (
    'sponsorship_approved',
    sponsor_id,
    'Sponsorship approved',
    jsonb_build_object(
      'request_id', request_id,
      'child_id', child_id,
      'sponsor_id', sponsor_id
    ),
    now()
  );
end;
$$ language plpgsql;