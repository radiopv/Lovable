-- Drop existing policies for sponsorship_requests
drop policy if exists "Enable insert for anonymous users" on sponsorship_requests;
drop policy if exists "Enable select for authenticated users" on sponsorship_requests;
drop policy if exists "Enable select for sponsors on their own requests" on sponsorship_requests;
drop policy if exists "Enable update for authenticated users" on sponsorship_requests;
drop policy if exists "Enable delete for authenticated users" on sponsorship_requests;

-- Create new policies for sponsorship_requests
create policy "Enable insert for all users"
  on sponsorship_requests for insert
  with check (
    -- Allow insert if sponsor_id exists in sponsors table
    exists (
      select 1 from sponsors s
      where s.id = sponsor_id
    )
  );

create policy "Enable select for admins"
  on sponsorship_requests for select
  using (auth.role() = 'authenticated');

create policy "Enable select for sponsors"
  on sponsorship_requests for select
  using (
    exists (
      select 1 from sponsors s
      where s.id = sponsorship_requests.sponsor_id
      and s.id::text = coalesce(auth.uid(), '')::text
    )
  );

create policy "Enable update for admins"
  on sponsorship_requests for update
  using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

create policy "Enable delete for admins"
  on sponsorship_requests for delete
  using (auth.role() = 'authenticated');