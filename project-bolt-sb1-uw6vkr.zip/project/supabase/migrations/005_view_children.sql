-- Create a view to display children data with their needs
create or replace view children_with_needs as
select 
  c.*,
  json_agg(n.*) filter (where n.id is not null) as needs
from children c
left join needs n on c.id = n.child_id
group by c.id;

-- Select all children with their needs
select 
  c.name,
  c.age,
  c.gender,
  c.city,
  c.birthday,
  c.situation,
  c.image_url,
  c.is_sponsored,
  c.private_notes,
  c.created_at,
  c.updated_at,
  json_agg(n.*) filter (where n.id is not null) as needs
from children c
left join needs n on c.id = n.child_id
group by c.id
order by c.created_at desc;