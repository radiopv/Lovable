-- Drop existing buckets to ensure clean state
drop policy if exists "Public can view memory files" on storage.objects;
drop policy if exists "Sponsors can upload memory files" on storage.objects;
drop policy if exists "Sponsors can delete their memory files" on storage.objects;

-- Create storage buckets with proper configuration
insert into storage.buckets (id, name, public)
values 
  ('media', 'media', true),
  ('memories', 'memories', true),
  ('avatars', 'avatars', true)
on conflict (id) do nothing;

-- Create storage policies for media bucket
create policy "Public can view media files"
  on storage.objects for select
  using (bucket_id = 'media');

create policy "Authenticated users can upload media"
  on storage.objects for insert
  with check (bucket_id = 'media' and auth.role() = 'authenticated');

create policy "Users can delete their media"
  on storage.objects for delete
  using (bucket_id = 'media' and auth.role() = 'authenticated');

-- Create storage policies for memories bucket
create policy "Public can view memory files"
  on storage.objects for select
  using (bucket_id = 'memories');

create policy "Authenticated users can upload memories"
  on storage.objects for insert
  with check (bucket_id = 'memories' and auth.role() = 'authenticated');

create policy "Users can delete their memories"
  on storage.objects for delete
  using (bucket_id = 'memories' and auth.role() = 'authenticated');

-- Create storage policies for avatars bucket
create policy "Public can view avatars"
  on storage.objects for select
  using (bucket_id = 'avatars');

create policy "Authenticated users can upload avatars"
  on storage.objects for insert
  with check (bucket_id = 'avatars' and auth.role() = 'authenticated');

create policy "Users can delete their avatars"
  on storage.objects for delete
  using (bucket_id = 'avatars' and auth.role() = 'authenticated');