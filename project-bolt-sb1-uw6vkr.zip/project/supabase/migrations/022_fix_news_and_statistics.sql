-- Drop existing tables if they exist
drop table if exists news cascade;
drop table if exists statistics cascade;

-- Create news table
create table news (
  id uuid primary key default uuid_generate_v4(),
  text text not null,
  url text,
  is_active boolean default true,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create statistics table
create table statistics (
  id uuid primary key default uuid_generate_v4(),
  total_children integer default 0,
  sponsored_children integer default 0,
  active_sponsors integer default 0,
  regions jsonb default '[]'::jsonb,
  updated_at timestamp with time zone default now()
);

-- Enable RLS
alter table news enable row level security;
alter table statistics enable row level security;

-- Create RLS policies for news
create policy "Public can view news"
  on news for select
  using (true);

create policy "Admins can manage news"
  on news for all
  using (auth.role() = 'authenticated');

-- Create RLS policies for statistics
create policy "Public can view statistics"
  on statistics for select
  using (true);

create policy "Admins can manage statistics"
  on statistics for all
  using (auth.role() = 'authenticated');

-- Insert initial statistics
insert into statistics (
  total_children,
  sponsored_children,
  active_sponsors,
  regions
) values (
  0,
  0,
  0,
  '[]'::jsonb
) on conflict do nothing;