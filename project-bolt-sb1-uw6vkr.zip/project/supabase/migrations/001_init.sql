-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- Create sponsors table
create table sponsors (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  email text unique not null,
  facebook_url text,
  is_anonymous boolean default false,
  has_chosen_visibility boolean default false,
  children_sponsored uuid[] default array[]::uuid[],
  contact_preferences jsonb default '{"email": true, "facebook": false}'::jsonb,
  last_login timestamp with time zone,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create children table
create table children (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  age integer not null check (age >= 0 and age <= 18),
  gender text not null check (gender in ('male', 'female')),
  city text not null,
  birthday date,
  situation text,
  image_url text,
  is_sponsored boolean default false,
  sponsor_id uuid references sponsors(id),
  sponsorship_end_date date,
  private_notes text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create needs table
create table needs (
  id uuid primary key default uuid_generate_v4(),
  child_id uuid references children(id) not null,
  category text not null check (category in ('essential', 'healthcare', 'education', 'clothing', 'development', 'emergency')),
  description text not null,
  priority text not null check (priority in ('high', 'medium', 'low')),
  status text not null check (status in ('pending', 'in_progress', 'fulfilled')) default 'pending',
  is_urgent boolean default false,
  target_date date,
  estimated_cost decimal(10,2),
  quantity integer default 1,
  specifications text,
  notes text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create memories table
create table memories (
  id uuid primary key default uuid_generate_v4(),
  child_id uuid references children(id) not null,
  sponsor_id uuid references sponsors(id) not null,
  media_url text not null,
  media_type text not null check (media_type in ('image', 'video')),
  description text,
  is_public boolean default false,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create testimonials table
create table testimonials (
  id uuid primary key default uuid_generate_v4(),
  sponsor_id uuid references sponsors(id) not null,
  child_id uuid references children(id) not null,
  message text not null,
  category text not null check (category in ('success_story', 'impact', 'gratitude', 'experience')),
  language text not null default 'fr',
  likes integer default 0,
  helpful_count integer default 0,
  is_approved boolean default false,
  is_published boolean default false,
  is_hidden boolean default false,
  media_urls text[],
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create sponsorship_requests table
create table sponsorship_requests (
  id uuid primary key default uuid_generate_v4(),
  child_id uuid references children(id) not null,
  sponsor_id uuid references sponsors(id) not null,
  message text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create travel_announcements table
create table travel_announcements (
  id uuid primary key default uuid_generate_v4(),
  sponsor_id uuid references sponsors(id) not null,
  departure_date date not null,
  return_date date not null,
  destination text not null,
  available_space text not null,
  notes text,
  is_active boolean default true,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create transport_requests table
create table transport_requests (
  id uuid primary key default uuid_generate_v4(),
  travel_id uuid references travel_announcements(id) not null,
  sponsor_id uuid references sponsors(id) not null,
  child_id uuid references children(id) not null,
  items text not null,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create forum_posts table
create table forum_posts (
  id uuid primary key default uuid_generate_v4(),
  sponsor_id uuid references sponsors(id) not null,
  title text not null,
  content text not null,
  category text not null,
  is_urgent boolean default false,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create forum_replies table
create table forum_replies (
  id uuid primary key default uuid_generate_v4(),
  post_id uuid references forum_posts(id) not null,
  sponsor_id uuid references sponsors(id) not null,
  content text not null,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create activity_logs table
create table activity_logs (
  id uuid primary key default uuid_generate_v4(),
  type text not null,
  user_id uuid not null,
  action text not null,
  details jsonb,
  is_read boolean default false,
  created_at timestamp with time zone default now()
);

-- Create translations table
create table translations (
  id uuid primary key default uuid_generate_v4(),
  key text not null unique,
  fr text not null,
  en text not null,
  es text not null,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create home_content table
create table home_content (
  id uuid primary key default uuid_generate_v4(),
  section text not null unique,
  title text,
  content text,
  image_url text,
  background_color text default '#ffffff',
  text_color text default '#000000',
  button_text text,
  button_url text,
  custom_html text,
  is_html_enabled boolean default false,
  news_items jsonb[] default array[]::jsonb[],
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create mailing_list table
create table mailing_list (
  id uuid primary key default uuid_generate_v4(),
  email text unique not null,
  name text,
  is_active boolean default true,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create email_logs table
create table email_logs (
  id uuid primary key default uuid_generate_v4(),
  subject text not null,
  content text not null,
  sent_to text[] not null,
  status text not null default 'pending' check (status in ('pending', 'sent', 'failed')),
  error text,
  created_at timestamp with time zone default now(),
  sent_at timestamp with time zone
);

-- Enable Row Level Security (RLS)
alter table sponsors enable row level security;
alter table children enable row level security;
alter table needs enable row level security;
alter table memories enable row level security;
alter table testimonials enable row level security;
alter table sponsorship_requests enable row level security;
alter table travel_announcements enable row level security;
alter table transport_requests enable row level security;
alter table forum_posts enable row level security;
alter table forum_replies enable row level security;
alter table activity_logs enable row level security;
alter table translations enable row level security;
alter table home_content enable row level security;
alter table mailing_list enable row level security;
alter table email_logs enable row level security;

-- Create indexes for better performance
create index idx_children_sponsor on children(sponsor_id);
create index idx_needs_child on needs(child_id);
create index idx_memories_child on memories(child_id);
create index idx_memories_sponsor on memories(sponsor_id);
create index idx_testimonials_child on testimonials(child_id);
create index idx_testimonials_sponsor on testimonials(sponsor_id);
create index idx_sponsorship_requests_child on sponsorship_requests(child_id);
create index idx_sponsorship_requests_sponsor on sponsorship_requests(sponsor_id);
create index idx_transport_requests_travel on transport_requests(travel_id);
create index idx_transport_requests_sponsor on transport_requests(sponsor_id);
create index idx_forum_posts_sponsor on forum_posts(sponsor_id);
create index idx_forum_replies_post on forum_replies(post_id);
create index idx_forum_replies_sponsor on forum_replies(sponsor_id);
create index idx_activity_logs_user on activity_logs(user_id);
create index idx_translations_key on translations(key);
create index idx_home_content_section on home_content(section);
create index idx_mailing_list_email on mailing_list(email);

-- Create RLS policies
-- Sponsors policies
create policy "Sponsors can view their own profile"
  on sponsors for select
  using (id::text = auth.uid());

create policy "Sponsors can update their own profile"
  on sponsors for update
  using (id::text = auth.uid());

-- Children policies
create policy "Anyone can view children"
  on children for select
  using (true);

create policy "Admins can manage children"
  on children for all
  using (auth.role() = 'authenticated');

-- Needs policies
create policy "Anyone can view needs"
  on needs for select
  using (true);

create policy "Admins can manage needs"
  on needs for all
  using (auth.role() = 'authenticated');

-- Memories policies
create policy "Sponsors can view their memories"
  on memories for select
  using (sponsor_id::text = auth.uid() or is_public = true);

create policy "Sponsors can create memories"
  on memories for insert
  with check (sponsor_id::text = auth.uid());

create policy "Sponsors can update their memories"
  on memories for update
  using (sponsor_id::text = auth.uid());

create policy "Sponsors can delete their memories"
  on memories for delete
  using (sponsor_id::text = auth.uid());

-- Testimonials policies
create policy "Anyone can view approved testimonials"
  on testimonials for select
  using (is_approved = true and is_published = true and is_hidden = false);

create policy "Sponsors can create testimonials"
  on testimonials for insert
  with check (sponsor_id::text = auth.uid());

-- Forum policies
create policy "Anyone can view forum posts"
  on forum_posts for select
  using (true);

create policy "Sponsors can create forum posts"
  on forum_posts for insert
  with check (sponsor_id::text = auth.uid());

create policy "Sponsors can update their posts"
  on forum_posts for update
  using (sponsor_id::text = auth.uid());

-- Travel announcements policies
create policy "Anyone can view travel announcements"
  on travel_announcements for select
  using (is_active = true);

create policy "Sponsors can create travel announcements"
  on travel_announcements for insert
  with check (sponsor_id::text = auth.uid());

-- Transport requests policies
create policy "Sponsors can view their transport requests"
  on transport_requests for select
  using (sponsor_id::text = auth.uid());

create policy "Sponsors can create transport requests"
  on transport_requests for insert
  with check (sponsor_id::text = auth.uid());

-- Activity logs policies
create policy "Users can view their activity logs"
  on activity_logs for select
  using (user_id::text = auth.uid());

-- Create storage buckets
insert into storage.buckets (id, name, public)
values 
  ('media', 'media', true),
  ('memories', 'memories', true),
  ('avatars', 'avatars', true)
on conflict (id) do nothing;

-- Create storage policies
create policy "Public can view media files"
  on storage.objects for select
  using (bucket_id = 'media');

create policy "Authenticated users can upload media"
  on storage.objects for insert
  with check (bucket_id = 'media' and auth.role() = 'authenticated');

create policy "Users can delete their media"
  on storage.objects for delete
  using (bucket_id = 'media' and auth.role() = 'authenticated');

create policy "Public can view memory files"
  on storage.objects for select
  using (bucket_id = 'memories');

create policy "Authenticated users can upload memories"
  on storage.objects for insert
  with check (bucket_id = 'memories' and auth.role() = 'authenticated');

create policy "Users can delete their memories"
  on storage.objects for delete
  using (bucket_id = 'memories' and auth.role() = 'authenticated');

create policy "Public can view avatars"
  on storage.objects for select
  using (bucket_id = 'avatars');

create policy "Authenticated users can upload avatars"
  on storage.objects for insert
  with check (bucket_id = 'avatars' and auth.role() = 'authenticated');

create policy "Users can delete their avatars"
  on storage.objects for delete
  using (bucket_id = 'avatars' and auth.role() = 'authenticated');