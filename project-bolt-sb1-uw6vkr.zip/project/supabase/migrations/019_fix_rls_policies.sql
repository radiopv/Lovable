-- Drop existing policies
drop policy if exists "Public can view news" on news;
drop policy if exists "Admins can manage news" on news;
drop policy if exists "Public can view statistics" on statistics;
drop policy if exists "Admins can manage statistics" on statistics;
drop policy if exists "Public can submit sponsorship requests" on sponsorship_requests;
drop policy if exists "Sponsors can view their requests" on sponsorship_requests;
drop policy if exists "Admins can manage sponsorship requests" on sponsorship_requests;

-- Create news table if not exists
create table if not exists news (
  id uuid primary key default uuid_generate_v4(),
  text text not null,
  url text,
  is_active boolean default true,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create statistics table if not exists
create table if not exists statistics (
  id uuid primary key default uuid_generate_v4(),
  total_children integer default 0,
  sponsored_children integer default 0,
  active_sponsors integer default 0,
  regions jsonb default '[]'::jsonb,
  updated_at timestamp with time zone default now()
);

-- Insert initial statistics if none exist
insert into statistics (total_children, sponsored_children, active_sponsors, regions)
select 0, 0, 0, '[]'::jsonb
where not exists (select 1 from statistics);

-- Enable RLS
alter table news enable row level security;
alter table statistics enable row level security;
alter table sponsorship_requests enable row level security;

-- Create policies for news table
create policy "Public can view news"
  on news for select
  using (true);

create policy "Admins can manage news"
  on news for all
  using (auth.role() = 'authenticated');

-- Create policies for statistics table
create policy "Public can view statistics"
  on statistics for select
  using (true);

create policy "Admins can manage statistics"
  on statistics for all
  using (auth.role() = 'authenticated');

-- Create policies for sponsorship_requests table
create policy "Anyone can submit sponsorship requests"
  on sponsorship_requests for insert
  with check (true);

create policy "Sponsors can view their requests"
  on sponsorship_requests for select
  using (sponsor_id::text = auth.uid() or auth.role() = 'authenticated');

create policy "Admins can manage sponsorship requests"
  on sponsorship_requests for all
  using (auth.role() = 'authenticated');