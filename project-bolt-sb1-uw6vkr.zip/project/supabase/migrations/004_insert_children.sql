-- Insert sample children data
insert into children (
  name,
  age,
  gender,
  city,
  birthday,
  situation,
  image_url,
  is_sponsored,
  private_notes
) values 
  (
    'Maria Rodriguez',
    8,
    'female',
    'La Havane',
    '2015-05-12',
    'Maria vit avec sa grand-mère dans un petit appartement. Elle aime beaucoup dessiner et rêve de devenir artiste.',
    'https://images.unsplash.com/photo-1544476915-ed1370594142',
    false,
    'Besoin urgent de matériel scolaire et de vêtements'
  ),
  (
    'Carlos Hernandez',
    10,
    'male',
    'Santiago de Cuba',
    '2013-08-23',
    'Carlos est passionné de baseball et excelle à l''école. Sa famille a des difficultés financières.',
    'https://images.unsplash.com/photo-1502781252888-9143ba7f074e',
    false,
    'Excellent en mathématiques, potentiel pour des études supérieures'
  ),
  (
    'Ana Sofia Morales',
    6,
    'female',
    'Varadero',
    '2017-11-30',
    'Ana vit avec ses parents qui travaillent dur mais ont du mal à joindre les deux bouts.',
    'https://images.unsplash.com/photo-1516642898673-edd1ced08e87',
    false,
    'Très sociable et créative'
  ),
  (
    'Miguel Torres',
    12,
    'male',
    'Cienfuegos',
    '2011-03-15',
    'Miguel aide sa famille en vendant des fruits après l''école. Il rêve de devenir médecin.',
    'https://images.unsplash.com/photo-1545558014-8692077e9b5c',
    false,
    'Motivé pour les études, particulièrement intéressé par les sciences'
  ),
  (
    'Isabella Perez',
    7,
    'female',
    'Trinidad',
    '2016-09-08',
    'Isabella vit avec sa mère célibataire qui travaille comme infirmière.',
    'https://images.unsplash.com/photo-1516627145497-ae6968895b74',
    false,
    'Adore la danse et la musique'
  );

-- Insert needs for each child
insert into needs (
  child_id,
  category,
  description,
  priority,
  is_urgent,
  quantity
) 
select 
  id as child_id,
  'education' as category,
  'Matériel scolaire (cahiers, crayons, sac)' as description,
  'high' as priority,
  true as is_urgent,
  1 as quantity
from children
where name = 'Maria Rodriguez';

insert into needs (
  child_id,
  category,
  description,
  priority,
  is_urgent,
  quantity
)
select 
  id as child_id,
  'clothing' as category,
  'Uniforme scolaire et chaussures de sport' as description,
  'medium' as priority,
  false as is_urgent,
  1 as quantity
from children
where name = 'Carlos Hernandez';

insert into needs (
  child_id,
  category,
  description,
  priority,
  is_urgent,
  quantity
)
select 
  id as child_id,
  'healthcare' as category,
  'Vitamines et médicaments de base' as description,
  'high' as priority,
  true as is_urgent,
  1 as quantity
from children
where name = 'Ana Sofia Morales';

insert into needs (
  child_id,
  category,
  description,
  priority,
  is_urgent,
  quantity
)
select 
  id as child_id,
  'education' as category,
  'Livres de sciences et calculatrice' as description,
  'medium' as priority,
  false as is_urgent,
  1 as quantity
from children
where name = 'Miguel Torres';

insert into needs (
  child_id,
  category,
  description,
  priority,
  is_urgent,
  quantity
)
select 
  id as child_id,
  'essential' as category,
  'Nourriture et produits d''hygiène' as description,
  'high' as priority,
  true as is_urgent,
  1 as quantity
from children
where name = 'Isabella Perez';