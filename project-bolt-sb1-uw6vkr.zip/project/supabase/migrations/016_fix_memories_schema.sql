-- Drop existing memories table if it exists
drop table if exists memories cascade;

-- Create memories table with correct schema
create table memories (
  id uuid primary key default uuid_generate_v4(),
  child_id uuid references children(id) not null,
  sponsor_id uuid references sponsors(id) not null,
  media_url text not null,
  media_type text not null check (media_type in ('image', 'video')),
  description text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now(),
  
  constraint fk_child
    foreign key (child_id)
    references children(id)
    on delete cascade,
    
  constraint fk_sponsor
    foreign key (sponsor_id)
    references sponsors(id)
    on delete cascade
);

-- Enable RLS
alter table memories enable row level security;

-- Create policies
create policy "Sponsors can view their own memories"
  on memories for select
  using (sponsor_id = auth.uid());

create policy "Sponsors can insert memories"
  on memories for insert
  with check (sponsor_id = auth.uid());

create policy "Sponsors can delete their own memories"
  on memories for delete
  using (sponsor_id = auth.uid());

create policy "Admins can manage memories"
  on memories for all
  using (exists (
    select 1 from admin_users
    where email = auth.email()
  ));

-- Create storage bucket for memories if it doesn't exist
insert into storage.buckets (id, name, public)
values ('memories', 'memories', true)
on conflict (id) do nothing;

-- Create storage policies
create policy "Public can view memory files"
  on storage.objects for select
  using (bucket_id = 'memories');

create policy "Sponsors can upload memory files"
  on storage.objects for insert
  with check (bucket_id = 'memories' and auth.role() = 'authenticated');

create policy "Sponsors can delete their memory files"
  on storage.objects for delete
  using (bucket_id = 'memories' and auth.role() = 'authenticated');