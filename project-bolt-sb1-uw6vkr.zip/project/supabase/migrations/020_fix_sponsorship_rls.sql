-- Drop existing policies for sponsorship_requests
drop policy if exists "Anyone can submit sponsorship requests" on sponsorship_requests;
drop policy if exists "Sponsors can view their requests" on sponsorship_requests;
drop policy if exists "Admins can manage sponsorship requests" on sponsorship_requests;

-- Create sponsorship_requests table if not exists
create table if not exists sponsorship_requests (
  id uuid primary key default uuid_generate_v4(),
  child_id uuid references children(id) not null,
  sponsor_id uuid references sponsors(id) not null,
  message text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Enable RLS
alter table sponsorship_requests enable row level security;

-- Create new policies for sponsorship_requests
create policy "Enable insert for anonymous users"
  on sponsorship_requests for insert
  with check (true);

create policy "Enable select for authenticated users"
  on sponsorship_requests for select
  using (auth.role() = 'authenticated');

create policy "Enable select for sponsors on their own requests"
  on sponsorship_requests for select
  using (sponsor_id::text = coalesce(auth.uid(), '')::text);

create policy "Enable update for authenticated users"
  on sponsorship_requests for update
  using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

create policy "Enable delete for authenticated users"
  on sponsorship_requests for delete
  using (auth.role() = 'authenticated');