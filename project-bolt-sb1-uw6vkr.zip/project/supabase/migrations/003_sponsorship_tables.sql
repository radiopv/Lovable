-- Enable UUID extension if not already enabled
create extension if not exists "uuid-ossp";

-- Create sponsors table
create table if not exists sponsors (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  email text unique not null,
  facebook_url text,
  is_anonymous boolean default false,
  has_chosen_visibility boolean default false,
  children_sponsored uuid[] default array[]::uuid[],
  contact_preferences jsonb default '{"email": true, "facebook": false}'::jsonb,
  last_login timestamp with time zone,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create children table
create table if not exists children (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  age integer not null check (age >= 0 and age <= 18),
  gender text not null check (gender in ('male', 'female')),
  city text not null,
  birthday date,
  situation text,
  image_url text,
  is_sponsored boolean default false,
  sponsor_id uuid references sponsors(id),
  sponsorship_end_date date,
  private_notes text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create needs table for tracking children's needs
create table if not exists needs (
  id uuid primary key default uuid_generate_v4(),
  child_id uuid references children(id) not null,
  category text not null check (category in ('essential', 'healthcare', 'education', 'clothing', 'development', 'emergency')),
  description text not null,
  priority text not null check (priority in ('high', 'medium', 'low')),
  status text not null check (status in ('pending', 'in_progress', 'fulfilled')) default 'pending',
  is_urgent boolean default false,
  target_date date,
  estimated_cost decimal(10,2),
  quantity integer default 1,
  specifications text,
  notes text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create memories table for storing photos and videos
create table if not exists memories (
  id uuid primary key default uuid_generate_v4(),
  child_id uuid references children(id) not null,
  sponsor_id uuid references sponsors(id) not null,
  media_url text not null,
  media_type text not null check (media_type in ('image', 'video')),
  description text,
  is_public boolean default false,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create sponsorship_requests table
create table if not exists sponsorship_requests (
  id uuid primary key default uuid_generate_v4(),
  child_id uuid references children(id) not null,
  sponsor_id uuid references sponsors(id) not null,
  message text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Enable Row Level Security (RLS)
alter table sponsors enable row level security;
alter table children enable row level security;
alter table needs enable row level security;
alter table memories enable row level security;
alter table sponsorship_requests enable row level security;

-- Create indexes for better performance
create index if not exists idx_children_sponsor on children(sponsor_id);
create index if not exists idx_needs_child on needs(child_id);
create index if not exists idx_memories_child on memories(child_id);
create index if not exists idx_memories_sponsor on memories(sponsor_id);
create index if not exists idx_sponsorship_requests_child on sponsorship_requests(child_id);
create index if not exists idx_sponsorship_requests_sponsor on sponsorship_requests(sponsor_id);

-- Create RLS policies for sponsors
create policy "Sponsors can view their own profile"
  on sponsors for select
  using (id::text = auth.uid());

create policy "Sponsors can update their own profile"
  on sponsors for update
  using (id::text = auth.uid());

-- Create RLS policies for children
create policy "Anyone can view children"
  on children for select
  using (true);

create policy "Admins can manage children"
  on children for all
  using (auth.role() = 'authenticated');

-- Create RLS policies for needs
create policy "Anyone can view needs"
  on needs for select
  using (true);

create policy "Admins can manage needs"
  on needs for all
  using (auth.role() = 'authenticated');

-- Create RLS policies for memories
create policy "Sponsors can view their memories"
  on memories for select
  using (sponsor_id::text = auth.uid() or is_public = true);

create policy "Sponsors can create memories"
  on memories for insert
  with check (sponsor_id::text = auth.uid());

create policy "Sponsors can update their memories"
  on memories for update
  using (sponsor_id::text = auth.uid());

create policy "Sponsors can delete their memories"
  on memories for delete
  using (sponsor_id::text = auth.uid());

-- Create RLS policies for sponsorship requests
create policy "Anyone can submit sponsorship requests"
  on sponsorship_requests for insert
  with check (true);

create policy "Sponsors can view their requests"
  on sponsorship_requests for select
  using (sponsor_id::text = auth.uid());

create policy "Admins can manage sponsorship requests"
  on sponsorship_requests for all
  using (auth.role() = 'authenticated');

-- Create storage bucket for media if it doesn't exist
insert into storage.buckets (id, name, public)
values ('media', 'media', true)
on conflict (id) do nothing;

-- Create storage policies
create policy "Public can view media files"
  on storage.objects for select
  using (bucket_id = 'media');

create policy "Authenticated users can upload media"
  on storage.objects for insert
  with check (bucket_id = 'media' and auth.role() = 'authenticated');

create policy "Users can delete their media"
  on storage.objects for delete
  using (bucket_id = 'media' and auth.role() = 'authenticated');