-- Create admin_users table if not exists
create table if not exists admin_users (
  id uuid primary key default uuid_generate_v4(),
  email text unique not null,
  created_at timestamp with time zone default now()
);

-- Create news table if not exists
create table if not exists news (
  id uuid primary key default uuid_generate_v4(),
  text text not null,
  url text,
  is_active boolean default true,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create statistics table if not exists
create table if not exists statistics (
  id uuid primary key default uuid_generate_v4(),
  total_children integer default 0,
  sponsored_children integer default 0,
  active_sponsors integer default 0,
  regions jsonb default '[]'::jsonb,
  updated_at timestamp with time zone default now()
);

-- Enable RLS on new tables
alter table admin_users enable row level security;
alter table news enable row level security;
alter table statistics enable row level security;

-- Create RLS policies for new tables
create policy "Public can view news"
  on news for select
  using (true);

create policy "Admins can manage news"
  on news for all
  using (exists (
    select 1 from admin_users
    where email = auth.email()
  ));

create policy "Public can view statistics"
  on statistics for select
  using (true);

create policy "Admins can manage statistics"
  on statistics for all
  using (exists (
    select 1 from admin_users
    where email = auth.email()
  ));

-- Create indexes for new tables
create index idx_admin_users_email on admin_users(email);
create index idx_news_is_active on news(is_active);

-- Insert initial admin user
insert into admin_users (email)
values ('renaudcanuel@me.com')
on conflict (email) do nothing;

-- Insert initial statistics
insert into statistics (total_children, sponsored_children, active_sponsors, regions)
select 0, 0, 0, '[]'::jsonb
where not exists (select 1 from statistics);

-- Create or replace schema initialization function
create or replace function init_schema()
returns void as $$
begin
  -- Create buckets if they don't exist
  insert into storage.buckets (id, name, public)
  values 
    ('media', 'media', true),
    ('memories', 'memories', true),
    ('avatars', 'avatars', true)
  on conflict (id) do nothing;

  -- Ensure RLS is enabled
  alter table sponsors enable row level security;
  alter table children enable row level security;
  alter table needs enable row level security;
  alter table memories enable row level security;
  alter table testimonials enable row level security;
  alter table sponsorship_requests enable row level security;
  alter table news enable row level security;
  alter table statistics enable row level security;
end;
$$ language plpgsql security definer;

-- Execute schema initialization
select init_schema();