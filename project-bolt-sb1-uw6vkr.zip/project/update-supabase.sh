#!/bin/bash

# Configuration Supabase
SUPABASE_URL="https://dgjksmnwhgiqtisionam.supabase.co"
SUPABASE_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRnamtzbW53aGdpcXRpc2lvbmFtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE1MTM5ODQsImV4cCI6MjA0NzA4OTk4NH0.VVKTb3v5g0PTUZ3uCg6kHjoc3-19c10royL3t8OKl30"

# Exécuter uniquement la nouvelle migration sécurisée
echo "Exécution de la migration sécurisée des besoins..."

curl -X POST "$SUPABASE_URL/rest/v1/rpc/exec" \
  -H "apikey: $SUPABASE_KEY" \
  -H "Authorization: Bearer $SUPABASE_KEY" \
  -H "Content-Type: application/json" \
  -d "{\"sql\": \"$(cat supabase/migrations/014_safe_needs_update.sql | tr '\n' ' ')\"}"

echo "Migration terminée avec succès!"